# Zino (Android)

Zino Game Space — a dark, Zino-red game space for Android phones and tablets (built on a Red Magic Astra).

- **Three tabs: Games · Boost · Me** – dark charcoal design with Zino red, smooth fades on every page, press springs on every button, sliding tab highlight.
- **Games** – search, a hero slideshow of your top games (auto cross-fade, swipe), Game Mode with live FPS / temp / battery / screen Hz, *Most Played* (your games, ranked) and *Popular games* with Download or Play. Rows pop in as you scroll.
- **Boost** – one card per game (Steam Mobile pinned first): one-tap Boost with a loading spinner, then a pulsing Play button while boosted; Server Region and Graphics & FPS rows. The Select Server sheet slides up from the bottom, Africa first (Côte d'Ivoire, Nigeria, South Africa, Ghana, Kenya and more), and picking a country shows "Connected to … — Optimized ✅" once the server really answers.
- **Me** – profile (guest, Sign in, Zino Pro), quick actions, and every tool and setting.
- **FPS arrow** – a small floating arrow over your game: green 60+ FPS, yellow 45–59, red under 45 or too hot, purple while Boost is on. Reads FPS from the game's own frames (Shizuku), appears when a game opens and goes away when it closes (Auto-hide, needs Usage access), or Always show / Off. Drag it anywhere; tap for FPS cap, Boost, Low latency, call blocking, Clear RAM, screenshot.
- **Image Boost** – DLSS-inspired modes per game: Ultra Quality, Balanced, Performance, Ultra Performance and Auto (picks by temperature at launch). Uses Android 13+ Game Mode resolution scaling — no AI, and it can't add detail the game doesn't draw.
- **✨ Clearest Graphics** – resets a game to native resolution and opens the Clarity panel: edge smoothing (4x MSAA, OpenGL games), colour vibrance, Image Boost, reset to default; saved per game.
- **Smart Auto Pilot** – while you play, switches Boost and Low latency from heat, battery and FPS stability, and picks a lighter Clarity mode for next launch when the device runs hot. Says why ("Device warming up — Boost off").
- **AI Graphics Engine** – explains Arm's NSS, NFRU and NSSD and shows whether this device supports them. They need games built with them and a Mali G2-Ultra NX GPU; no app can add them to other games, so Zino doesn't pretend to.
- **Per-game Tune** – Clearest Graphics, Clarity mode, FPS limit, brightness lock, ad blocker and low latency per game; save as the default profile for new games.
- **Game VPN · Server Region** – pick a country per game (Côte d'Ivoire, Ghana, Nigeria and 60 more across 10 regions) and only that game's traffic goes through a WireGuard server there, so the game matches you with that region. Connects on Boost & Play or when the game opens, disconnects when it closes. Ping shown for each server. **Zino ships with no servers**: add a WireGuard config per country (import a .conf or paste it) — set one up on your own VPS with `server/zino-server-setup.sh`.
- **Game Mode options** – block calls and pop-ups (game sound still plays), pause sync, Boost (fixed performance mode, switched off when hot), Low latency (top refresh rate), brightness lock; all put back afterwards.
- **Tools** – phone status, ad blocker (on-device DNS filter), ping test, graphics and FPS tips.
- **Settings** – game detection (auto, add games manually, exclude apps), alerts (heat, low battery, FPS drops), arrow size, opacity, drag lock, start after restart.
- **Account** – everything works without an account. Sign-in and Zino Pro are placeholders until a sync service exists.

Android 8.0+ (Image Boost Android 13+) · no root (Shizuku for advanced features) · no ads · no tracking. Logos are in `branding/`.

## Get the APK (free, no computer needed)

1. Create a free account at github.com and make a **new repository** (e.g. `FrameForgeMobile`).
2. Upload everything in this folder to it (**Add file › Upload files**). Keep the `.github` folder — it contains the build script.
3. Open the **Actions** tab. The *Build APK* job runs automatically (about 3–5 minutes).
4. Open the finished run and download **FrameForge-apk** at the bottom. Unzip it to get `app-debug.apk`.
5. Open the APK on your phone and allow "Install unknown apps" when asked.

Or open the folder in Android Studio and press Run.

## What it can't do

Android doesn't let one app change another game's internal graphics or force a higher FPS without root. "GFX tool" apps that claim to do this either edit game files (blocked on Android 11+, and can get you banned) or do nothing. Zino sticks to things that really work.
