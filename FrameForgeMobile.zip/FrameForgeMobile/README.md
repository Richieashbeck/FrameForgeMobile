# FrameForge Mobile (Android)

Gets your phone ready for smooth, low-lag gaming.

- **Phone status** – temperature/throttling, battery saver, battery heat, free memory, screen refresh rate, Wi‑Fi band and signal, with fixes when something is holding games back.
- **Ad blocker** – blocks game ad networks (AdMob, Unity Ads, AppLovin, ironSource, Vungle, Mintegral, Pangle and more) with an on-device DNS filter. Rewarded ads stop working too; turn it off for games that need them.
- **Ping test** – tests your router plus internet servers (add your game server IP) and tells you whether lag is your Wi‑Fi or your internet provider.
- **Game boost** – lists your games; *Boost & Play* clears background apps, can turn on Do Not Disturb, and launches the game.
- **Better graphics & FPS** – shows your screen's max refresh rate, shortcuts to Display settings and Developer options (Force 4x MSAA), and in‑game setting advice.

Android 8.0+ · no root · no ads · no tracking.

## Get the APK (free, no computer needed)

1. Create a free account at github.com and make a **new repository** (e.g. `FrameForgeMobile`).
2. Upload everything in this folder to it (**Add file › Upload files**). Keep the `.github` folder — it contains the build script.
3. Open the **Actions** tab. The *Build APK* job runs automatically (about 3–5 minutes).
4. Open the finished run and download **FrameForge-apk** at the bottom. Unzip it to get `app-debug.apk`.
5. Open the APK on your phone and allow "Install unknown apps" when asked.

Or open the folder in Android Studio and press Run.

## What it can't do

Android doesn't let one app change another game's internal graphics or force a higher FPS without root. "GFX tool" apps that claim to do this either edit game files (blocked on Android 11+, and can get you banned) or do nothing. FrameForge sticks to things that really work.
