package com.frameforge.mobile;

import java.util.Arrays;
import java.util.Locale;

/** Minimal IPv4/UDP/DNS packet handling for the ad blocker. Plain Java so it can be unit-tested. */
public final class Dns {

    /** The DNS payload of an IPv4 UDP packet to port 53, or null for anything else. */
    public static byte[] extractQuery(byte[] pkt) {
        if (pkt.length < 28 || (pkt[0] >> 4 & 0xF) != 4 || (pkt[9] & 0xFF) != 17) return null;
        int ihl = (pkt[0] & 0xF) * 4;
        if (pkt.length < ihl + 8 || u16(pkt, ihl + 2) != 53) return null;
        int end = Math.min(pkt.length, ihl + u16(pkt, ihl + 4));
        return end <= ihl + 8 ? null : Arrays.copyOfRange(pkt, ihl + 8, end);
    }

    /** The first question's name in lower case, or null if the query is malformed. */
    public static String queryName(byte[] dns) {
        if (dns == null || dns.length < 13 || u16(dns, 4) == 0) return null;
        StringBuilder sb = new StringBuilder();
        int pos = 12;
        while (pos < dns.length) {
            int len = dns[pos] & 0xFF;
            if (len == 0) return sb.toString().toLowerCase(Locale.ROOT);
            if ((len & 0xC0) != 0 || pos + 1 + len > dns.length) return null;
            if (sb.length() > 0) sb.append('.');
            sb.append(new String(dns, pos + 1, len, java.nio.charset.StandardCharsets.US_ASCII));
            pos += 1 + len;
        }
        return null;
    }

    /** An NXDOMAIN ("no such domain") answer to the query: header + original question only. */
    public static byte[] nxdomain(byte[] query) {
        int end = 12;
        while (end < query.length && query[end] != 0) end += 1 + (query[end] & 0xFF);
        end = Math.min(query.length, end + 5); // zero byte + QTYPE + QCLASS
        byte[] r = Arrays.copyOf(query, end);
        r[2] = (byte) (query[2] | 0x80);       // QR = response, keep opcode + RD
        r[3] = (byte) 0x83;                    // RA + RCODE 3 (NXDOMAIN)
        r[6] = r[7] = r[8] = r[9] = r[10] = r[11] = 0; // no answer/authority/additional records
        return r;
    }

    /** Wraps a DNS reply in an IPv4/UDP packet going back to whoever sent {@code request}. */
    public static byte[] wrapReply(byte[] request, byte[] dns) {
        int ihl = (request[0] & 0xF) * 4;
        int total = 28 + dns.length;
        byte[] r = new byte[total];
        r[0] = 0x45;
        put16(r, 2, total);
        r[6] = 0x40;                            // don't fragment
        r[8] = 64;                              // TTL
        r[9] = 17;                              // UDP
        System.arraycopy(request, 16, r, 12, 4); // src = original destination
        System.arraycopy(request, 12, r, 16, 4); // dst = original source
        put16(r, 10, checksum(r, 0, 20));
        put16(r, 20, u16(request, ihl + 2));     // src port = 53
        put16(r, 22, u16(request, ihl));         // dst port = client's port
        put16(r, 24, 8 + dns.length);            // UDP checksum left 0: optional for IPv4
        System.arraycopy(dns, 0, r, 28, dns.length);
        return r;
    }

    static int checksum(byte[] b, int off, int len) {
        int sum = 0;
        for (int i = off; i < off + len; i += 2) sum += u16(b, i);
        while ((sum >> 16) != 0) sum = (sum & 0xFFFF) + (sum >> 16);
        return ~sum & 0xFFFF;
    }

    static int u16(byte[] b, int i) { return (b[i] & 0xFF) << 8 | (b[i + 1] & 0xFF); }
    static void put16(byte[] b, int i, int v) { b[i] = (byte) (v >> 8); b[i + 1] = (byte) v; }
}
