package com.frameforge.mobile;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

/** Brings Game Mode back after a restart if it was on, so the FPS arrow keeps appearing in games. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        android.content.SharedPreferences p = ctx.getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE);
        boolean wasOn = p.getBoolean("gm_enabled", false) && p.getBoolean("boot_start", true);
        if (wasOn && Settings.canDrawOverlays(ctx)) ctx.startForegroundService(new Intent(ctx, OverlayService.class));
    }
}
