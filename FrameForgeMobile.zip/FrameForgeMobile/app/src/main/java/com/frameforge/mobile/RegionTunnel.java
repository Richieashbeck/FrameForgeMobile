package com.frameforge.mobile;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

/**
 * Game VPN: sends one game's traffic through a WireGuard server in the chosen country, so the game
 * sees you there and picks that region's servers. Uses the official WireGuard tunnel library.
 * Server configs are added by the owner in Tools › Game VPN servers (Zino ships with none).
 */
final class RegionTunnel {
    static volatile String activeGame, activeCountry;
    private static GoBackend backend;
    private static final Tunnel TUNNEL = new Tunnel() {
        @Override public String getName() { return "zino"; }
        @Override public void onStateChange(State newState) {
            if (newState == State.DOWN) { activeGame = null; activeCountry = null; }
        }
    };

    private RegionTunnel() { }

    static String serverConfig(SharedPreferences prefs, String country) { return prefs.getString("srv_" + country, null); }

    /** Connects the game to its chosen country. Blocking — call off the main thread. VPN consent must already be given. */
    static void connect(Context ctx, String pkg, String country) throws Exception {
        SharedPreferences prefs = ctx.getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE);
        String conf = serverConfig(prefs, country);
        if (pkg.equals(activeGame) && country.equals(activeCountry)) return; // already connected
        if (conf == null) throw new IllegalStateException("No server added for " + GameTuning.countryName(country));
        if (AdBlockService.running) { // Android runs one VPN at a time
            ctx.startService(new Intent(ctx, AdBlockService.class).setAction(AdBlockService.ACTION_STOP));
            Thread.sleep(500);
        }
        Config config = Config.parse(new ByteArrayInputStream(GameTuning.withIncludedApp(conf, pkg).getBytes(StandardCharsets.UTF_8)));
        backend(ctx).setState(TUNNEL, Tunnel.State.UP, config);
        activeGame = pkg;
        activeCountry = country;
    }

    /** Disconnects if connected. Blocking — call off the main thread. */
    static void disconnect(Context ctx) {
        if (activeGame == null) return;
        try { backend(ctx).setState(TUNNEL, Tunnel.State.DOWN, null); } catch (Exception ignored) { }
        activeGame = null;
        activeCountry = null;
    }

    private static synchronized GoBackend backend(Context ctx) {
        if (backend == null) backend = new GoBackend(ctx.getApplicationContext());
        return backend;
    }
}
