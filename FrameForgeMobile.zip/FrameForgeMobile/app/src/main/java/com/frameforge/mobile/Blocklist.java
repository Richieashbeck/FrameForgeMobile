package com.frameforge.mobile;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Ad-network domains used by mobile game ad SDKs. A domain also blocks all its subdomains.
 * Deliberately narrow: whole platforms like unity3d.com or facebook.com are not listed,
 * because games need them to log in and download content.
 */
public final class Blocklist {
    // shortcut: built-in list only; add a downloadable list if users report ads getting through
    static final Set<String> DOMAINS = new HashSet<>(Arrays.asList(
            // Google AdMob / Ad Manager
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "admob.com",
            "adservice.google.com", "googletagservices.com",
            // Unity Ads
            "unityads.unity3d.com", "ads.unity3d.com",
            // AppLovin / MAX
            "applovin.com", "applvn.com", "applovin-ad.com",
            // ironSource / LevelPlay
            "supersonicads.com", "ironsrc.com", "ironsrc.mobi", "ironbeast.io",
            // Vungle / Liftoff
            "vungle.com", "vungle.akadns.net", "liftoff.io", "liftoff-creatives.io",
            // Meta Audience Network
            "an.facebook.com", "audiencenetwork.facebook.com",
            // Mintegral
            "mintegral.com", "mintegral.net", "rayjump.com",
            // Pangle (TikTok)
            "pangle.io", "pangleglobal.com", "pangle-ads.com",
            // InMobi, Chartboost, AdColony, Tapjoy, Fyber, others
            "inmobi.com", "inmobicdn.net", "chartboost.com", "adcolony.com", "tapjoy.com", "tapjoyads.com",
            "fyber.com", "inner-active.mobi", "startappservice.com", "smaato.net", "mopub.com",
            "bidmachine.io", "yandexadexchange.net", "adsrvr.org",
            "moloco.com", "digitalturbine.com", "kidoz.net", "verve.com", "pubnative.net"));

    public static boolean isBlocked(String name) {
        while (true) {
            if (DOMAINS.contains(name)) return true;
            int dot = name.indexOf('.');
            if (dot < 0) return false;
            name = name.substring(dot + 1);
        }
    }
}
