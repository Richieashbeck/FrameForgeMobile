package com.frameforge.mobile;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Zino's game logic that doesn't need Android: Image Boost presets, Game Mode shell commands,
 * FPS reading and the FPS arrow colour. Plain Java so it can be unit-tested off-device.
 */
public final class GameTuning {
    private GameTuning() { }

    // ------------------------------------------------------------------ Image Boost presets

    public static final int AUTO = 4;
    public static final String[] BOOST_NAMES = {"✨ Ultra Quality", "⚡ Balanced", "🚀 Performance", "🔥 Ultra Performance", "🤖 Auto"};
    /** Render scale per preset; Auto has none of its own (it picks one of the others). */
    public static final float[] BOOST_SCALES = {1f, 0.8f, 0.7f, 0.5f, -1f};
    public static final String[] BOOST_INFO = {
            "Full resolution · Clarity: best · FPS: no change · Battery: normal",
            "80% resolution · Clarity: high · FPS: small gain · Battery: saves a little",
            "70% resolution · Clarity: medium · FPS: good gain · Battery: saves more",
            "50% resolution · Clarity: low · FPS: biggest gain · Battery: saves most",
            "Picks a mode each time the game starts: Ultra Quality when cool, down to Ultra Performance when hot"};
    public static final int[] FPS = {0, 30, 45, 60, 90, 120, 144, 165}; // 0 = no cap

    /** Auto mode: Android thermal status (0 none … 6 shutdown) → preset index. */
    public static int autoPreset(int thermalStatus) {
        return thermalStatus <= 0 ? 0 : thermalStatus == 1 ? 1 : thermalStatus == 2 ? 2 : 3;
    }

    public static int presetFor(float scale) {
        for (int i = 0; i < BOOST_SCALES.length; i++) if (Math.abs(BOOST_SCALES[i] - scale) < 0.01f) return i;
        return -1;
    }

    /** Package names go into shell commands, so only real package names are allowed. */
    public static boolean validPackage(String pkg) {
        return pkg != null && pkg.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+");
    }

    /** Shell commands that set render scale + FPS cap; the last one stops the game so it restarts with them. */
    public static String[] commands(String pkg, float scale, int fps) {
        if (!validPackage(pkg)) throw new IllegalArgumentException("Not a package name: " + pkg);
        if (scale >= 1f && fps <= 0) return new String[]{"cmd game reset " + pkg, "am force-stop " + pkg};
        // `cmd game set` (Android 13+) is allowed for the shell user; `device_config put game_overlay` is blocked on newer Android
        String set = "cmd game set --mode 2 --downscale " + (scale >= 1f ? "disable" : fmt(scale))
                + " --fps " + (fps > 0 ? String.valueOf(fps) : "disable") + " " + pkg;
        return new String[]{set, "cmd game mode 2 " + pkg, "am force-stop " + pkg};
    }

    /** Same as commands() but leaves a running game alone; it picks the change up next launch. */
    public static String[] commandsNoRestart(String pkg, float scale, int fps) {
        String[] all = commands(pkg, scale, fps);
        String[] out = new String[all.length - 1];
        System.arraycopy(all, 0, out, 0, out.length);
        return out;
    }

    public static String save(float scale, int fps) { return fmt(scale) + "," + fps; }
    public static float savedScale(String saved) { return saved == null ? 1f : Float.parseFloat(saved.split(",")[0]); }
    public static int savedFps(String saved) { return saved == null ? 0 : Integer.parseInt(saved.split(",")[1]); }

    /** Human label for a saved profile, or "Default" when none is saved. */
    public static String describe(String saved) {
        if (saved == null) return "Default";
        float s = savedScale(saved);
        int fps = savedFps(saved);
        int p = presetFor(s);
        String name = p >= 0 ? BOOST_NAMES[p] : Math.round(s * 100) + "% resolution";
        return name + (fps > 0 ? " · " + fps + " FPS cap" : "");
    }

    static String fmt(float s) { return String.format(Locale.US, "%.1f", s); }

    // ------------------------------------------------------------------ clarity

    /** Edge smoothing (forced 4x MSAA, OpenGL games, next launch) and colour vibrance (screen saturation). */
    public static String[] clarityCommands(boolean edgeSmoothing, float vibrance) {
        float v = Math.max(1f, Math.min(1.6f, vibrance));
        return new String[]{"setprop debug.egl.force_msaa " + edgeSmoothing,
                "service call SurfaceFlinger 1022 f " + String.format(Locale.US, "%.2f", v)};
    }

    public static String saveClarity(boolean edgeSmoothing, float vibrance) {
        return edgeSmoothing + "," + String.format(Locale.US, "%.2f", vibrance);
    }

    // ------------------------------------------------------------------ FPS reading

    /** Which SurfaceFlinger layer holds the game's frames, from `dumpsys SurfaceFlinger --list`, or null. */
    public static String pickLayer(String list, String pkg) {
        if (list == null || pkg == null) return null;
        String best = null;
        int bestScore = -1;
        for (String raw : list.split("\n")) {
            String l = raw.trim();
            if (!l.contains(pkg) || l.contains("'") || l.startsWith("Background")) continue;
            int score = (l.startsWith("SurfaceView") ? 2 : 0) + (l.contains("(BLAST)") ? 1 : 0);
            if (score > bestScore) { best = l; bestScore = score; }
        }
        return best;
    }

    /** "Actual present" times (ns) from `dumpsys SurfaceFlinger --latency <layer>`, oldest first. */
    public static long[] presentTimes(String latency) {
        List<Long> out = new ArrayList<>();
        if (latency != null) {
            for (String line : latency.split("\n")) {
                String[] p = line.trim().split("\\s+");
                if (p.length != 3) continue;
                try {
                    long t = Long.parseLong(p[1]);
                    if (t > 0 && t != Long.MAX_VALUE) out.add(t);
                } catch (NumberFormatException ignored) { }
            }
        }
        long[] a = new long[out.size()];
        for (int i = 0; i < a.length; i++) a[i] = out.get(i);
        java.util.Arrays.sort(a);
        return a;
    }

    /** Frames per second over the newest second of present times (works above 128 FPS too), or -1. */
    public static int fpsFromPresentTimes(long[] t) {
        if (t.length < 2) return -1;
        long newest = t[t.length - 1];
        int first = t.length - 1;
        while (first > 0 && newest - t[first - 1] <= 1_000_000_000L) first--;
        int frames = t.length - 1 - first;
        long span = newest - t[first];
        return frames <= 0 || span <= 0 ? -1 : Math.round(frames * 1e9f / span);
    }

    /** Fallback: SurfaceFlinger's whole-screen frame counter (counts every screen update, not just the game's). */
    public static final String FRAME_COUNTER_CMD = "service call SurfaceFlinger 1013";

    /** Frame counter from a reply like "Result: Parcel(0004b3a2    '....')", or -1 if the phone doesn't answer it. */
    public static long parseFrameCounter(String reply) {
        if (reply == null) return -1;
        int i = reply.indexOf("Parcel(");
        if (i < 0) return -1;
        String hex = reply.substring(i + 7).trim().split("\\s+")[0];
        try { return Long.parseLong(hex, 16); } catch (NumberFormatException e) { return -1; }
    }

    /** Frames per second between two counter readings taken ms apart. */
    public static int fps(long before, long after, long ms) {
        if (before < 0 || after < before || ms <= 0) return -1;
        return Math.round((after - before) * 1000f / ms);
    }

    /** ▲ rising, ▼ falling, ▲ steady — the arrow's direction. */
    public static String trend(int previous, int now) {
        if (previous < 0 || now < 0 || Math.abs(now - previous) <= 2) return "▲";
        return now > previous ? "▲" : "▼";
    }

    public static final int GREEN = 0, YELLOW = 1, RED = 2, PURPLE = 3;

    /** Arrow colour: red for stutter or heat first, then purple for Boost or 144+ FPS, then green/yellow by FPS. */
    public static int arrowColor(int fps, boolean hot, boolean boost) {
        if (hot || (fps >= 0 && fps < 45)) return RED;
        if (boost || fps >= 144) return PURPLE;
        return fps >= 60 || fps < 0 ? GREEN : YELLOW;
    }

    /** ▲ for green and purple, ▼ for yellow and red. */
    public static String arrowGlyph(int color) { return color == GREEN || color == PURPLE ? "▲" : "▼"; }

    /** Mean and spread (standard deviation) of recent FPS readings; negatives are skipped. */
    public static double[] meanAndSpread(int[] fps) {
        double sum = 0, sq = 0;
        int n = 0;
        for (int f : fps) if (f >= 0) { sum += f; sq += (double) f * f; n++; }
        if (n == 0) return new double[]{-1, 0};
        double mean = sum / n;
        return new double[]{mean, Math.sqrt(Math.max(0, sq / n - mean * mean))};
    }

    // ------------------------------------------------------------------ Smart Auto Pilot

    /** What Auto Pilot wants right now, and the one-line reason shown to the player. */
    public static final class Pilot {
        public final boolean boost, latency, stepDown;
        public final String reason;
        Pilot(boolean boost, boolean latency, boolean stepDown, String reason) {
            this.boost = boost; this.latency = latency; this.stepDown = stepDown; this.reason = reason;
        }
    }

    /**
     * Rules, most urgent first: heat, low battery, warming, unstable FPS, all good.
     * stepDown = use a lighter Image Boost mode next time the game opens (resolution can't change mid-game).
     */
    public static Pilot autoPilot(int thermal, float batteryC, int batteryPct, boolean charging, double fpsMean, double fpsSpread) {
        if (thermal >= 3 || batteryC >= 43) return new Pilot(false, false, true, "Device hot — Boost and Low latency off, lighter mode next launch");
        if (batteryPct <= 20 && !charging) return new Pilot(false, false, false, "Battery low — saving power");
        if (thermal == 2 || batteryC >= 40) return new Pilot(false, true, false, "Device warming up — Boost off");
        if (fpsMean > 0 && fpsSpread > fpsMean * 0.15) return new Pilot(true, true, false, "FPS unstable — Boost on");
        return new Pilot(true, true, false, "All good — full performance");
    }

    /** One step lighter Image Boost mode (Ultra Quality → Balanced → Performance → Ultra Performance). */
    public static float lighter(float scale) {
        int p = presetFor(scale);
        if (p < 0 || p == AUTO) p = 0;
        return BOOST_SCALES[Math.min(p + 1, 3)];
    }

    // ------------------------------------------------------------------ game VPN regions

    /** Africa first, then the rest of the world. */
    public static final String[] REGIONS = {"Africa", "Middle East & North Africa", "Southeast Asia", "East Asia", "South Asia",
            "Oceania", "Europe", "North America", "Latin America", "Hong Kong, Taiwan & Macau"};
    /** Countries per region as {ISO code, name}, same order as REGIONS. */
    public static final String[][][] COUNTRIES = {
            {{"CI", "Côte d'Ivoire"}, {"NG", "Nigeria"}, {"ZA", "South Africa"}, {"GH", "Ghana"}, {"KE", "Kenya"},
                    {"SN", "Senegal"}, {"CM", "Cameroon"}, {"BJ", "Benin"}, {"TG", "Togo"}, {"BF", "Burkina Faso"}, {"ML", "Mali"},
                    {"CD", "DR Congo"}, {"ET", "Ethiopia"}, {"TZ", "Tanzania"}, {"UG", "Uganda"}, {"AO", "Angola"}},
            {{"EG", "Egypt"}, {"MA", "Morocco"}, {"DZ", "Algeria"}, {"TN", "Tunisia"}, {"AE", "United Arab Emirates"},
                    {"SA", "Saudi Arabia"}, {"QA", "Qatar"}, {"KW", "Kuwait"}, {"BH", "Bahrain"}, {"JO", "Jordan"}},
            {{"SG", "Singapore"}, {"MY", "Malaysia"}, {"ID", "Indonesia"}, {"TH", "Thailand"}, {"VN", "Vietnam"}, {"PH", "Philippines"}},
            {{"JP", "Japan"}, {"KR", "South Korea"}},
            {{"IN", "India"}, {"PK", "Pakistan"}, {"BD", "Bangladesh"}, {"LK", "Sri Lanka"}},
            {{"AU", "Australia"}, {"NZ", "New Zealand"}},
            {{"GB", "United Kingdom"}, {"FR", "France"}, {"DE", "Germany"}, {"IT", "Italy"}, {"ES", "Spain"}, {"PT", "Portugal"},
                    {"NL", "Netherlands"}, {"BE", "Belgium"}, {"IE", "Ireland"}, {"SE", "Sweden"}, {"PL", "Poland"},
                    {"CH", "Switzerland"}, {"TR", "Turkey"}},
            {{"US", "United States"}, {"CA", "Canada"}, {"MX", "Mexico"}},
            {{"BR", "Brazil"}, {"AR", "Argentina"}, {"CL", "Chile"}, {"CO", "Colombia"}, {"PE", "Peru"}},
            {{"HK", "Hong Kong"}, {"TW", "Taiwan"}, {"MO", "Macau"}}};

    /** Popular games for the Games tab: {package, name, genre}. Shown with Download or Play. */
    public static final String[][] POPULAR = {
            {"com.tencent.ig", "PUBG Mobile", "Battle Royale · Shooter"},
            {"com.dts.freefireth", "Free Fire", "Battle Royale · Shooter"},
            {"com.activision.callofduty.shooter", "Call of Duty: Mobile", "Shooter · Action"},
            {"com.supercell.brawlstars", "Brawl Stars", "MOBA · Casual"},
            {"com.mobile.legends", "Mobile Legends: Bang Bang", "MOBA"},
            {"com.firsttouchgames.dls7", "Dream League Soccer", "Football"},
            {"com.ea.gp.fifamobile", "EA SPORTS FC Mobile", "Football"},
            {"jp.konami.pesam", "eFootball", "Football"},
            {"com.miraclegames.farlight84", "Farlight 84", "Battle Royale · Shooter"},
            {"com.netease.newspike", "Blood Strike", "Shooter"},
            {"com.roblox.client", "Roblox", "Adventure · Social"},
            {"com.supercell.clashroyale", "Clash Royale", "Strategy"}};
    public static final String STEAM = "com.valvesoftware.android.steam.community";

    public static String countryName(String code) {
        if (code == null) return "None";
        for (String[][] region : COUNTRIES) for (String[] c : region) if (c[0].equals(code)) return c[1];
        return code;
    }

    /** Flag emoji from a two-letter country code. */
    public static String flag(String code) {
        if (code == null || code.length() != 2) return "🌍";
        int a = 0x1F1E6 + Character.toUpperCase(code.charAt(0)) - 'A', b = 0x1F1E6 + Character.toUpperCase(code.charAt(1)) - 'A';
        return new String(Character.toChars(a)) + new String(Character.toChars(b));
    }

    /** A WireGuard config that only carries this game's traffic (everything else on the device stays direct). */
    public static String withIncludedApp(String conf, String pkg) {
        if (!validPackage(pkg)) throw new IllegalArgumentException("Not a package name: " + pkg);
        StringBuilder out = new StringBuilder();
        boolean added = false;
        for (String line : conf.split("\\r?\\n")) {
            String key = line.trim().toLowerCase(Locale.ROOT);
            if (key.startsWith("includedapplications") || key.startsWith("excludedapplications")) continue;
            out.append(line).append('\n');
            if (!added && key.equals("[interface]")) { out.append("IncludedApplications = ").append(pkg).append('\n'); added = true; }
        }
        if (!added) throw new IllegalArgumentException("No [Interface] section");
        return out.toString();
    }

    /** Server host from the config's "Endpoint = host:port" line, for the ping test; null if missing or odd. */
    public static String endpointHost(String conf) {
        if (conf == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?im)^\\s*Endpoint\\s*=\\s*(\\S+)\\s*$").matcher(conf);
        if (!m.find()) return null;
        String v = m.group(1), host;
        if (v.startsWith("[")) {
            int end = v.indexOf(']');
            host = end > 1 ? v.substring(1, end) : null;
        } else {
            int colon = v.lastIndexOf(':');
            host = colon > 0 ? v.substring(0, colon) : v;
        }
        return host != null && host.matches("[A-Za-z0-9.:-]+") ? host : null;
    }

    // ------------------------------------------------------------------ small labels

    /** Minutes of battery left from Android's charge counter (µAh) and current (µA); -1 if unknown or charging. */
    public static int minutesLeft(long chargeCounterUah, long currentNowUa, boolean charging) {
        long draw = Math.abs(currentNowUa);
        if (charging || chargeCounterUah <= 0 || draw < 10_000) return -1; // < 10 mA = no useful reading
        return (int) (chargeCounterUah * 60L / draw);
    }

    public static String duration(int minutes) {
        if (minutes < 0) return "—";
        return minutes >= 60 ? (minutes / 60) + " h " + (minutes % 60) + " min" : minutes + " min";
    }

    /** "just now", "5 min ago", "3 h ago", "2 d ago", or "Never". */
    public static String ago(long thenMs, long nowMs) {
        if (thenMs <= 0) return "Never played";
        long m = Math.max(0, (nowMs - thenMs) / 60_000);
        if (m < 1) return "Played just now";
        if (m < 60) return "Played " + m + " min ago";
        if (m < 60 * 24) return "Played " + (m / 60) + " h ago";
        return "Played " + (m / (60 * 24)) + " d ago";
    }
}
