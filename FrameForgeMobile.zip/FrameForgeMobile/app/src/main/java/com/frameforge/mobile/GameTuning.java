package com.frameforge.mobile;

import java.util.Locale;

/**
 * NeuralFrame v0.1: per-game render scale + FPS cap through Android Game Mode interventions (Android 13+).
 * Plain Java so it can be unit-tested off-device.
 */
public final class GameTuning {
    public static final float[] SCALES = {1f, 0.9f, 0.8f, 0.7f, 0.6f, 0.5f};
    public static final String[] SCALE_NAMES = {"Native (100%)", "Ultra Quality (90%)", "Quality (80%)",
            "Balanced (70%)", "Performance (60%)", "Ultra Performance (50%)"};
    public static final int[] FPS = {0, 30, 45, 60, 90, 120}; // 0 = no cap

    private GameTuning() { }

    /** Package names go into a shell command, so only real package names are allowed. */
    public static boolean validPackage(String pkg) {
        return pkg != null && pkg.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+");
    }

    /** Shell commands (run as the shell user) that apply the setting; the game is stopped so it restarts with it. */
    public static String[] commands(String pkg, float scale, int fps) {
        if (!validPackage(pkg)) throw new IllegalArgumentException("Not a package name: " + pkg);
        if (scale >= 1f && fps <= 0) return new String[]{"cmd game reset " + pkg, "am force-stop " + pkg};
        // `cmd game set` (Android 13+) is allowed for the shell user; `device_config put game_overlay` is blocked on newer Android
        String set = "cmd game set --mode 2 --downscale " + (scale >= 1f ? "disable" : fmt(scale))
                + " --fps " + (fps > 0 ? String.valueOf(fps) : "disable") + " " + pkg;
        return new String[]{set, "cmd game mode 2 " + pkg, "am force-stop " + pkg};
    }

    public static String save(float scale, int fps) { return fmt(scale) + "," + fps; }

    /** Human label for a saved profile, or "Default" when none is saved. */
    public static String describe(String saved) {
        if (saved == null) return "Default";
        String[] p = saved.split(",");
        float s = Float.parseFloat(p[0]);
        int fps = Integer.parseInt(p[1]);
        String name = fmt(s) + "x";
        for (int i = 0; i < SCALES.length; i++) if (Math.abs(SCALES[i] - s) < 0.01f) name = SCALE_NAMES[i];
        return name + (fps > 0 ? " · " + fps + " FPS cap" : "");
    }

    static String fmt(float s) { return String.format(Locale.US, "%.1f", s); }

    /** Shell command whose reply carries SurfaceFlinger's frame counter (frames drawn to the screen so far). */
    public static final String FRAME_COUNTER_CMD = "service call SurfaceFlinger 1013";

    /** Frame counter from a reply like "Result: Parcel(0004b3a2    '....')", or -1 if the phone doesn't answer it. */
    public static long parseFrameCounter(String reply) {
        if (reply == null) return -1;
        int i = reply.indexOf("Parcel(");
        if (i < 0) return -1;
        String hex = reply.substring(i + 7).trim().split("\\s+")[0];
        try { return Long.parseLong(hex, 16); } catch (NumberFormatException e) { return -1; }
    }

    /** Frames per second between two counter readings taken ms apart. */
    public static int fps(long before, long after, long ms) {
        if (before < 0 || after < before || ms <= 0) return -1;
        return Math.round((after - before) * 1000f / ms);
    }

    /** ▲ rising, ▼ falling, • steady — the overlay's FPS trend arrow. */
    public static String trend(int previous, int now) {
        if (previous < 0 || now < 0 || Math.abs(now - previous) <= 2) return "•";
        return now > previous ? "▲" : "▼";
    }
}
