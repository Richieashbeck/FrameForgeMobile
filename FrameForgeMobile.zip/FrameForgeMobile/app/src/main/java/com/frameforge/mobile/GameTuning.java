package com.frameforge.mobile;

import java.util.Locale;

/**
 * NeuralFrame v0.1: per-game render scale + FPS cap through Android Game Mode interventions (Android 13+).
 * Plain Java so it can be unit-tested off-device.
 */
public final class GameTuning {
    public static final float[] SCALES = {1f, 0.9f, 0.8f, 0.7f, 0.6f, 0.5f};
    public static final String[] SCALE_NAMES = {"Native (100%)", "Ultra Quality (90%)", "Quality (80%)",
            "Balanced (70%)", "Performance (60%)", "Ultra Performance (50%)"};
    public static final int[] FPS = {0, 30, 45, 60, 90, 120}; // 0 = no cap

    private GameTuning() { }

    /** Package names go into a shell command, so only real package names are allowed. */
    public static boolean validPackage(String pkg) {
        return pkg != null && pkg.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+");
    }

    /** Shell commands (run as the shell user) that apply the setting; the game is stopped so it restarts with it. */
    public static String[] commands(String pkg, float scale, int fps) {
        if (!validPackage(pkg)) throw new IllegalArgumentException("Not a package name: " + pkg);
        if (scale >= 1f && fps <= 0) {
            return new String[]{"device_config delete game_overlay " + pkg, "cmd game mode standard " + pkg, "am force-stop " + pkg};
        }
        String one = "downscaleFactor=" + fmt(scale) + (fps > 0 ? ",fps=" + fps : "");
        // same values for performance (2) and battery (3) mode, so it holds whichever mode is picked later
        return new String[]{"device_config put game_overlay " + pkg + " mode=2," + one + ":mode=3," + one,
                "cmd game mode performance " + pkg, "am force-stop " + pkg};
    }

    public static String save(float scale, int fps) { return fmt(scale) + "," + fps; }

    /** Human label for a saved profile, or "Default" when none is saved. */
    public static String describe(String saved) {
        if (saved == null) return "Default";
        String[] p = saved.split(",");
        float s = Float.parseFloat(p[0]);
        int fps = Integer.parseInt(p[1]);
        String name = fmt(s) + "x";
        for (int i = 0; i < SCALES.length; i++) if (Math.abs(SCALES[i] - s) < 0.01f) name = SCALE_NAMES[i];
        return name + (fps > 0 ? " · " + fps + " FPS cap" : "");
    }

    static String fmt(float s) { return String.format(Locale.US, "%.1f", s); }
}
