package com.frameforge.mobile;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Ping statistics and lag diagnosis. Plain Java so it can be unit-tested off-device. */
public final class Stats {
    public static final int HEALTHY = 0, HOME_NETWORK = 1, ISP = 2, NO_REPLY = 3;

    public final int sent, received;
    public final double loss;          // percent
    public final Double avg, min, max, jitter; // ms, null when nothing replied

    public Stats(List<Double> times, int sent) {
        this.sent = Math.max(sent, times.size());
        this.received = times.size();
        this.loss = this.sent == 0 ? 0 : 100.0 * (this.sent - received) / this.sent;
        Double a = null, lo = null, hi = null, j = null;
        if (received > 0) {
            double sum = 0, mn = Double.MAX_VALUE, mx = 0;
            for (double t : times) { sum += t; mn = Math.min(mn, t); mx = Math.max(mx, t); }
            a = round(sum / received); lo = round(mn); hi = round(mx);
        }
        if (received > 1) {
            double d = 0;
            for (int i = 1; i < received; i++) d += Math.abs(times.get(i) - times.get(i - 1));
            j = round(d / (received - 1));
        }
        avg = a; min = lo; max = hi; jitter = j;
    }

    private static final Pattern TIME = Pattern.compile("time[=<]\\s*([0-9.]+)");
    private static final Pattern SENT = Pattern.compile("(\\d+) packets transmitted");

    public static List<Double> parseTimes(String pingOutput) {
        List<Double> out = new ArrayList<>();
        Matcher m = TIME.matcher(pingOutput);
        while (m.find()) out.add(Double.parseDouble(m.group(1)));
        return out;
    }

    /** Packets sent according to ping's summary line, or -1 if there is none. */
    public static int parseSent(String pingOutput) {
        Matcher m = SENT.matcher(pingOutput);
        return m.find() ? Integer.parseInt(m.group(1)) : -1;
    }

    /**
     * Where does lag come from? Thresholds are looser than on a PC because phone
     * Wi-Fi power saving adds a few ms of router latency on its own.
     */
    public static int diagnose(Stats router, List<Stats> internet) {
        if (router != null && router.received > 0
                && (router.loss > 5 || nz(router.jitter) > 15 || router.avg > 30)) return HOME_NETWORK;
        boolean any = false;
        double worstLoss = 0, worstJitter = 0;
        for (Stats s : internet) {
            if (s.received == 0) continue;
            any = true;
            worstLoss = Math.max(worstLoss, s.loss);
            worstJitter = Math.max(worstJitter, nz(s.jitter));
        }
        if (!any) return NO_REPLY;
        return (worstLoss > 5 || worstJitter > 20) ? ISP : HEALTHY;
    }

    private static double nz(Double d) { return d == null ? 0 : d; }
    private static double round(double d) { return Math.round(d * 10) / 10.0; }
}
