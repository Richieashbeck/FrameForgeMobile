package com.frameforge.mobile;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** Zino's small, fast animations: press, staggered fade-in, pop-in on scroll, pulse. No libraries. */
final class Fx {
    static final DecelerateInterpolator EASE = new DecelerateInterpolator(2f);

    private Fx() { }

    /** Shrinks a touch while pressed and springs back — keeps the click working. */
    @SuppressLint("ClickableViewAccessibility")
    static <T extends View> T press(T v) {
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).setInterpolator(EASE).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(new OvershootInterpolator(3f)).start();
                    break;
            }
            return false;
        });
        return v;
    }

    /** Children slide up and fade in one after another (first eight staggered, the rest together). */
    static void staggerIn(ViewGroup parent) {
        for (int i = 0; i < parent.getChildCount(); i++) {
            View c = parent.getChildAt(i);
            if (c.getVisibility() != View.VISIBLE) continue;
            c.animate().cancel();
            c.setAlpha(0f);
            c.setTranslationY(c.getResources().getDisplayMetrics().density * 18);
            c.animate().alpha(1f).translationY(0).setStartDelay(Math.min(i, 8) * 45L).setDuration(320).setInterpolator(EASE).start();
        }
    }

    /** Hidden until scrolled into view; reveal() pops it in. */
    static void hideForPopIn(View v) {
        v.setAlpha(0f);
        v.setScaleX(0.92f);
        v.setScaleY(0.92f);
    }

    /** Pops in the view if any of it is on screen; returns true if it did. */
    static boolean revealIfVisible(View v, int delayMs) {
        Rect r = new Rect();
        if (!v.isShown() || !v.getGlobalVisibleRect(r) || r.height() <= 0) return false;
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(delayMs).setDuration(280)
                .setInterpolator(new OvershootInterpolator(1.4f)).start();
        return true;
    }

    /** A ring behind a button that breathes outwards while active. Cancel the returned animator to stop. */
    static Animator pulse(View ring) {
        ring.setVisibility(View.VISIBLE);
        ObjectAnimator sx = ObjectAnimator.ofFloat(ring, View.SCALE_X, 1f, 1.18f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(ring, View.SCALE_Y, 1f, 1.35f);
        ObjectAnimator a = ObjectAnimator.ofFloat(ring, View.ALPHA, 0.7f, 0f);
        for (ObjectAnimator o : new ObjectAnimator[]{sx, sy, a}) {
            o.setRepeatCount(ValueAnimator.INFINITE);
            o.setDuration(1300);
        }
        AnimatorSet set = new AnimatorSet();
        set.playTogether(sx, sy, a);
        set.setInterpolator(EASE);
        set.start();
        return set;
    }

    static void stopPulse(Animator anim, View ring) {
        if (anim != null) anim.cancel();
        ring.setVisibility(View.INVISIBLE);
    }

    /** Small spring for a confirmation tick. */
    static void bounceIn(View v) {
        v.setScaleX(0.3f);
        v.setScaleY(0.3f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(new OvershootInterpolator(3f)).start();
    }
}
