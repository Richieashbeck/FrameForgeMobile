package com.frameforge.mobile;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.VpnService;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    // Zino theme: near-black surfaces, Zino red with a soft glow, green/yellow/red for status
    static final int BG = 0xFF0A0B0D, CARD = 0xFF17191D, SHEET = 0xFF1C1E23, NAV = 0xFF0E0F12, BORDER = 0xFF262930,
            TEXT = 0xFFF2F4F7, MUTED = 0xFF8A93A0, BRAND = 0xFFE60012, GLOW = 0x66E60012,
            GOOD = 0xFF22E39A, WARN = 0xFFFFC24B, BAD = 0xFFFF4D5E, GHOST = 0xFF24272D;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private LinearLayout root; // the page cards are added to while building
    private final LinearLayout[] pages = new LinearLayout[3];
    private final ImageView[] tabIcons = new ImageView[3];
    private final TextView[] tabLabels = new TextView[3];
    private View tabPill;
    private ScrollView scroll;
    private FrameLayout layer; // sheets and banners float here, above the pages
    private int page = -1;

    private LinearLayout statusBox, gameBox, recentBox, popularBox;
    private TextView pingOut, verdict, adStatus, nfStatus, gameModeNote, usageNote;
    private TextView fpsStat, tempStat, batteryStat, hzStat, pilotSub;
    private EditText hosts, search;
    private Button runPing, adToggle, nfConnect, gameMode, usageButton;
    private Button chipBoost, chipAds, chipLatency, chipPilot;
    private final Button[] arrowModes = new Button[3], sizeChips = new Button[3];
    private boolean onWifi;
    private TextView vpnStatus;
    private Button vpnDisconnect;
    private LinearLayout serverBox;
    private Runnable pendingPlay;
    private String pendingCountry;
    private final List<View> popIns = new ArrayList<>();
    private final java.util.Map<String, BoostButton> boostButtons = new java.util.HashMap<>();
    private Hero hero;
    private List<ApplicationInfo> installedGames = new ArrayList<>();

    private final Shizuku.OnRequestPermissionResultListener nfGranted = (code, result) -> ui.post(this::updateShizuku);
    private final Runnable liveTick = new Runnable() {
        @Override public void run() { updateLive(); updateBoostStates(); ui.postDelayed(this, 1000); }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(NAV);
        prefs = getPreferences(MODE_PRIVATE); // file "MainActivity", shared with OverlayService

        LinearLayout column = vertical();
        column.setBackgroundColor(BG);
        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = vertical();
        content.setPadding(dp(16), dp(18), dp(16), dp(28));
        scroll.addView(content);
        column.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        column.addView(navBar());
        layer = new FrameLayout(this);
        FrameLayout frame = new FrameLayout(this);
        frame.addView(column);
        frame.addView(layer);
        setContentView(frame);
        scroll.getViewTreeObserver().addOnScrollChangedListener(this::revealPopIns);

        for (int i = 0; i < pages.length; i++) { pages[i] = vertical(); content.addView(pages[i]); }
        root = pages[0]; buildGamesPage();
        root = pages[1]; buildBoostPage();
        root = pages[2]; buildMe();
        Shizuku.addRequestPermissionResultListener(nfGranted);
        showPage(Math.min(prefs.getInt("page", 0), 2));
    }

    @Override protected void onResume() {
        super.onResume();
        boostedPkg = null; // back from the game: show the real boost state
        refreshStatus();
        loadGames();
        updateShizuku();
        updateArrowModes();
        showServers();
        liveTick.run();
        if (hero != null) hero.start();
        ui.postDelayed(this::updateGameMode, 300); // the service flips its flag a moment after starting
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacks(liveTick);
        if (hero != null) hero.stop();
    }

    @Override public void onBackPressed() {
        if (layer.findViewWithTag("sheet") != null) { closeSheet(); return; }
        super.onBackPressed();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 1 && result == RESULT_OK) startService(new Intent(this, AdBlockService.class));
        if (request == 3) { // VPN permission for the game VPN
            Runnable play = pendingPlay;
            pendingPlay = null;
            if (result == RESULT_OK && play != null) play.run();
            else if (result != RESULT_OK) banner("Android needs VPN permission for Server Region", BAD);
        }
        if (request == 4 && result == RESULT_OK && data != null && data.getData() != null && pendingCountry != null) {
            String code = pendingCountry;
            try (java.io.InputStream in = getContentResolver().openInputStream(data.getData())) {
                byte[] buf = new byte[16384];
                int n = in.read(buf);
                saveServer(code, n <= 0 ? "" : new String(buf, 0, n, java.nio.charset.StandardCharsets.UTF_8));
            } catch (Exception e) {
                toast("Couldn't read that file");
            }
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeRequestPermissionResultListener(nfGranted);
        bg.shutdownNow();
    }

    // ------------------------------------------------------------------ navigation

    /** Games | Boost | Me — the active tab's pill slides under it and its colour fades in. */
    private View navBar() {
        FrameLayout wrap = new FrameLayout(this);
        wrap.setBackgroundColor(NAV);
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(dp(12), dp(8), dp(12), dp(12));
        tabPill = new View(this);
        tabPill.setBackground(round(0x26E60012, 18, 0));
        wrap.addView(tabPill, new FrameLayout.LayoutParams(dp(64), dp(32)));
        String[] names = {"Games", "Boost", "Me"};
        int[] icons = {R.drawable.ic_tab_games, R.drawable.ic_tab_boost, R.drawable.ic_tab_me};
        for (int i = 0; i < 3; i++) {
            int idx = i;
            LinearLayout tab = vertical();
            tab.setGravity(Gravity.CENTER_HORIZONTAL);
            tab.setPadding(0, dp(4), 0, dp(2));
            ImageView ic = new ImageView(this);
            ic.setImageResource(icons[i]);
            ic.setImageTintList(ColorStateList.valueOf(MUTED));
            tab.addView(ic, new LinearLayout.LayoutParams(dp(26), dp(26)));
            TextView label = text(names[i], 12, MUTED, true);
            label.setPadding(0, dp(4), 0, 0);
            tab.addView(label);
            tab.setContentDescription(names[i]);
            tab.setOnClickListener(v -> showPage(idx));
            tabIcons[i] = ic;
            tabLabels[i] = label;
            bar.addView(Fx.press(tab), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        }
        wrap.addView(bar);
        return wrap;
    }

    private void showPage(int p) {
        boolean changed = p != page;
        page = p;
        prefs.edit().putInt("page", p).apply();
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == p ? View.VISIBLE : View.GONE);
            tint(tabIcons[i], i == p ? BRAND : MUTED);
            tabLabels[i].setTextColor(i == p ? TEXT : MUTED);
        }
        View tab = (View) tabIcons[p].getParent();
        tab.post(() -> { // slide the pill under the active icon
            float x = tab.getLeft() + ((View) tab.getParent()).getLeft() + (tab.getWidth() - tabPill.getWidth()) / 2f;
            float y = tab.getTop() + ((View) tab.getParent()).getTop() + tabIcons[p].getTop() - dp(3);
            if (tabPill.getTranslationX() == 0 && tabPill.getTranslationY() == 0) { tabPill.setTranslationX(x); tabPill.setTranslationY(y); }
            else tabPill.animate().translationX(x).translationY(y).setDuration(260).setInterpolator(Fx.EASE).start();
        });
        if (!changed) return;
        scroll.scrollTo(0, 0);
        Fx.staggerIn(pages[p]);
        ui.postDelayed(this::revealPopIns, 120);
    }

    private void tint(ImageView v, int to) {
        ColorStateList cur = v.getImageTintList();
        int from = cur == null ? MUTED : cur.getDefaultColor();
        if (from == to) return;
        ValueAnimator a = ValueAnimator.ofObject(new ArgbEvaluator(), from, to);
        a.setDuration(220);
        a.addUpdateListener(an -> v.setImageTintList(ColorStateList.valueOf((int) an.getAnimatedValue())));
        a.start();
    }

    /** Items that pop in the first time they scroll into view. */
    private void popIn(View v) {
        Fx.hideForPopIn(v);
        popIns.add(v);
    }

    private void revealPopIns() {
        int n = 0;
        for (java.util.Iterator<View> it = popIns.iterator(); it.hasNext(); ) {
            View v = it.next();
            if (!v.isAttachedToWindow()) { it.remove(); continue; }
            if (Fx.revealIfVisible(v, Math.min(n, 6) * 50)) { it.remove(); n++; }
        }
    }

    // ------------------------------------------------------------------ Games tab

    private void buildGamesPage() {
        root.addView(logoBar());

        search = new EditText(this);
        search.setHint("🔍  Search game");
        search.setHintTextColor(MUTED);
        search.setTextColor(TEXT);
        search.setSingleLine();
        search.setGravity(Gravity.CENTER);
        search.setBackground(round(CARD, 26, 0));
        search.setPadding(dp(16), dp(12), dp(16), dp(12));
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) { filterGames(s.toString()); }
        });
        root.addView(search, spaced());

        hero = new Hero();
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(196));
        hp.topMargin = dp(14);
        root.addView(hero.view, hp);

        // Game Mode + live stats
        LinearLayout gm = card(null);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout words = vertical();
        words.addView(text("Game Mode", 18, TEXT, true));
        gameModeNote = text("", 12, MUTED, false);
        words.addView(gameModeNote);
        head.addView(words, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        gameMode = button("", true, v -> toggleGameMode());
        ((LinearLayout.LayoutParams) gameMode.getLayoutParams()).topMargin = 0;
        head.addView(gameMode);
        gm.addView(head);
        LinearLayout stats = new LinearLayout(this);
        stats.setPadding(0, dp(14), 0, 0);
        fpsStat = miniStat(stats, "FPS");
        tempStat = miniStat(stats, "Temp");
        batteryStat = miniStat(stats, "Battery");
        hzStat = miniStat(stats, "Screen");
        gm.addView(stats);
        pilotSub = text("", 12, 0xFFB36BFF, false);
        pilotSub.setPadding(0, dp(10), 0, 0);
        gm.addView(pilotSub);

        root.addView(sectionTitle("Most Played"));
        recentBox = vertical();
        recentBox.addView(loading());
        root.addView(recentBox);

        root.addView(sectionTitle("Popular games"));
        popularBox = vertical();
        root.addView(popularBox);
    }

    private TextView miniStat(LinearLayout row, String label) {
        LinearLayout box = vertical();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setBackground(round(GHOST, 14, 0));
        box.setPadding(0, dp(10), 0, dp(10));
        TextView v = text("—", 18, TEXT, true);
        box.addView(v);
        box.addView(text(label, 11, MUTED, false));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        p.rightMargin = dp(6);
        row.addView(box, p);
        return v;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 22, TEXT, true);
        t.setPadding(dp(2), dp(22), 0, dp(4));
        return t;
    }

    private View loading() {
        android.widget.ProgressBar p = new android.widget.ProgressBar(this);
        p.setIndeterminateTintList(ColorStateList.valueOf(BRAND));
        p.setPadding(0, dp(16), 0, dp(16));
        return p;
    }

    /** Z logo + ZINO GAME SPACE, top-left of every page. */
    private View logoBar() {
        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.zino_logo);
        logo.setBackground(round(0xFF0B0C0F, 14, GLOW));
        brand.addView(logo, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout words = vertical();
        words.setPadding(dp(12), 0, 0, 0);
        TextView z = text("ZINO", 20, TEXT, true);
        z.setLetterSpacing(0.22f);
        TextView gs = text("GAME SPACE", 10, BRAND, true);
        gs.setLetterSpacing(0.35f);
        words.addView(z);
        words.addView(gs);
        brand.addView(words);
        return brand;
    }

    private Button chip(String label, View.OnClickListener click) {
        Button b = button(label, false, click);
        b.setTextSize(12);
        b.setPadding(dp(6), 0, dp(6), 0);
        return b;
    }

    /** Live stats, Auto Pilot line, chip states — once a second while the app is open. */
    private void updateLive() {
        int fps = OverlayService.liveFps;
        fpsStat.setText(fps < 0 ? "—" : fps + "");
        fpsStat.setTextColor(fps < 0 ? MUTED : fps >= 60 ? GOOD : fps >= 45 ? WARN : BAD);
        int thermal = Build.VERSION.SDK_INT >= 29 ? getSystemService(PowerManager.class).getCurrentThermalStatus() : 0;
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            float c = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int lvl = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / Math.max(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
            boolean hot = c >= 42 || thermal >= 3, warm = hot || c >= 38 || thermal == 2;
            tempStat.setText(String.format(Locale.US, "%.0f°C", c));
            tempStat.setTextColor(hot ? BAD : warm ? WARN : GOOD);
            batteryStat.setText(lvl + "%");
            batteryStat.setTextColor(lvl <= 15 ? BAD : TEXT);
        }
        float[] hz = refreshRates();
        hzStat.setText(Math.round(hz[0]) + "Hz");
        hzStat.setTextColor(hz[0] >= hz[1] - 1 ? GOOD : TEXT);
        boolean pilot = prefs.getBoolean("autopilot", true);
        String note = OverlayService.pilotNote;
        pilotSub.setText(pilot ? "🤖 Auto Pilot · " + (note != null ? note : "starts when you play") : "");
        pilotSub.setVisibility(pilot ? View.VISIBLE : View.GONE);

        chipOn(chipBoost, prefs.getBoolean("gm_perf", true));
        chipOn(chipLatency, prefs.getBoolean("gm_latency", true));
        chipOn(chipAds, AdBlockService.running);
        chipOn(chipPilot, pilot);
        if (adStatus != null) {
            boolean ads = AdBlockService.running;
            adStatus.setText(ads ? "● On · " + AdBlockService.blocked.get() + " ad requests blocked" : "Off");
            adStatus.setTextColor(ads ? GOOD : MUTED);
            adToggle.setText(ads ? "Turn off ad blocker" : "Turn on ad blocker");
        }
    }

    private void chipOn(Button b, boolean on) {
        b.setBackground(ripple(round(on ? 0xFF2A070B : GHOST, 23, on ? BRAND : 0)));
        b.setTextColor(on ? TEXT : MUTED);
    }

    /** Boost / Low latency chips: saved for every Game Mode, and switched live if Game Mode is running. */
    private void setQuick(String key, String action) {
        boolean on = !prefs.getBoolean(key, true);
        prefs.edit().putBoolean(key, on).apply();
        if (OverlayService.running) startService(new Intent(this, OverlayService.class).setAction(action).putExtra("on", on));
        else if (on && !Shell.ready()) toast("Needs Shizuku — start it, then connect in Me › Shizuku");
        updateLive();
    }

    /** Most Played: your games, most played first. Popular: well-known games with Download or Play. */
    private void showGamesHome() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> sorted = new ArrayList<>(installedGames);
        sorted.sort((a, b) -> {
            int pc = Integer.compare(prefs.getInt("pc_" + b.packageName, 0), prefs.getInt("pc_" + a.packageName, 0));
            return pc != 0 ? pc : Long.compare(prefs.getLong("lp_" + b.packageName, 0), prefs.getLong("lp_" + a.packageName, 0));
        });
        recentBox.removeAllViews();
        int rank = 0;
        for (ApplicationInfo a : sorted) {
            if (rank >= 6) break;
            String label = pm.getApplicationLabel(a).toString();
            recentBox.addView(listRow(++rank, a.packageName, label, pm.getApplicationIcon(a),
                    GameTuning.ago(prefs.getLong("lp_" + a.packageName, 0), System.currentTimeMillis()), true));
        }
        if (rank == 0) recentBox.addView(text("No games found yet. Install a game, or add one in Me › Game detection.", 13, MUTED, false));

        popularBox.removeAllViews();
        for (String[] g : GameTuning.POPULAR) {
            boolean have = isInstalled(g[0]);
            Drawable icon = null;
            if (have) try { icon = pm.getApplicationIcon(g[0]); } catch (PackageManager.NameNotFoundException ignored) { }
            popularBox.addView(listRow(0, g[0], g[1], icon, g[2], have));
        }
        hero.setGames(sorted.subList(0, Math.min(5, sorted.size())));
        filterGames(search.getText().toString());
        ui.post(this::revealPopIns);
    }

    /** A Games-tab row: rank badge, icon, name, small line, and Play or Download. */
    private View listRow(int rank, String pkg, String label, Drawable icon, String line, boolean installed) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));
        row.setTag(label.toLowerCase(Locale.ROOT));
        row.addView(iconView(icon, label, 56), new LinearLayout.LayoutParams(dp(56), dp(56)));
        if (rank > 0) {
            TextView badge = text(String.valueOf(rank), 12, rank == 1 ? 0xFF2B1B00 : TEXT, true);
            badge.setGravity(Gravity.CENTER);
            badge.setBackground(round(rank == 1 ? 0xFFFFC24B : rank == 2 ? 0xFF8EA2C8 : rank == 3 ? 0xFFC9864A : GHOST, 6, 0));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(22), dp(22));
            bp.leftMargin = dp(12);
            row.addView(badge, bp);
        }
        LinearLayout names = vertical();
        names.setPadding(dp(12), 0, dp(8), 0);
        TextView n = text(label, 16, TEXT, true);
        n.setSingleLine();
        n.setEllipsize(android.text.TextUtils.TruncateAt.END);
        names.addView(n);
        names.addView(text(line, 12, MUTED, false));
        row.addView(names, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        Button act = installed ? button("Play", true, v -> boostAndPlay(pkg, label)) : button("Download", false, v -> download(pkg));
        if (!installed) act.setTextColor(BRAND);
        ((LinearLayout.LayoutParams) act.getLayoutParams()).topMargin = 0;
        row.addView(act);
        popIn(row);
        return row;
    }

    /** App icon, or a coloured monogram tile for games that aren't installed (no borrowed artwork). */
    private View iconView(Drawable icon, String label, int sizeDp) {
        if (icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(icon);
            iv.setClipToOutline(true);
            iv.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(14)); }
            });
            return iv;
        }
        int[] palette = {0xFF3A1F8C, 0xFF0E5E6F, 0xFF7A1B2B, 0xFF1F5130, 0xFF6B4A12, 0xFF243B7A};
        TextView t = text(label.substring(0, 1), sizeDp * 0.42f, TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(palette[Math.abs(label.hashCode()) % palette.length], 14, 0));
        return t;
    }

    private void filterGames(String q) {
        String needle = q.trim().toLowerCase(Locale.ROOT);
        for (LinearLayout box : new LinearLayout[]{recentBox, popularBox, gameBox}) {
            if (box == null) continue;
            for (int i = 0; i < box.getChildCount(); i++) {
                View v = box.getChildAt(i);
                if (v.getTag() instanceof String) v.setVisibility(needle.isEmpty() || ((String) v.getTag()).contains(needle) ? View.VISIBLE : View.GONE);
            }
        }
    }

    private boolean isInstalled(String pkg) {
        try { getPackageManager().getApplicationInfo(pkg, 0); return true; }
        catch (PackageManager.NameNotFoundException e) { return false; }
    }

    private void download(String pkg) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg))); }
        catch (ActivityNotFoundException e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg))); }
    }

    /** Hero banner: your top games as slides that cross-fade every few seconds. Swipe or tap a dot to move. */
    private class Hero {
        final FrameLayout view = new FrameLayout(MainActivity.this);
        private final LinearLayout dots = new LinearLayout(MainActivity.this);
        private final List<View> slides = new ArrayList<>();
        private int current;
        private final Runnable next = new Runnable() {
            @Override public void run() { if (slides.size() > 1) go((current + 1) % slides.size()); ui.postDelayed(this, 4500); }
        };

        Hero() {
            view.setBackground(round(CARD, 22, 0));
            view.setClipToOutline(true);
            view.setClickable(true); // so a swipe on the banner reaches the touch listener
            dots.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams dp0 = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(20), Gravity.BOTTOM);
            dp0.bottomMargin = dp(8);
            view.addView(dots, dp0);
            float[] downX = {0};
            view.setOnTouchListener((v, e) -> {
                if (e.getActionMasked() == android.view.MotionEvent.ACTION_DOWN) downX[0] = e.getX();
                if (e.getActionMasked() == android.view.MotionEvent.ACTION_UP && slides.size() > 1) {
                    float dx = e.getX() - downX[0];
                    if (Math.abs(dx) > dp(40)) { go((current + (dx < 0 ? 1 : slides.size() - 1)) % slides.size()); restart(); return true; }
                }
                return false;
            });
            setGames(new ArrayList<>());
        }

        void setGames(List<ApplicationInfo> games) {
            for (View s : slides) view.removeView(s);
            slides.clear();
            dots.removeAllViews();
            if (games.isEmpty()) slides.add(slide(null, "Welcome to Zino", "Boost a game to see it here", null));
            PackageManager pm = getPackageManager();
            for (ApplicationInfo a : games) {
                String cc = prefs.getString("rg_" + a.packageName, null);
                String line = GameTuning.ago(prefs.getLong("lp_" + a.packageName, 0), System.currentTimeMillis())
                        + (cc != null ? "  ·  " + GameTuning.flag(cc) + " " + GameTuning.countryName(cc) : "");
                slides.add(slide(pm.getApplicationIcon(a), pm.getApplicationLabel(a).toString(), line, a.packageName));
            }
            for (int i = 0; i < slides.size(); i++) {
                view.addView(slides.get(i), 0, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                slides.get(i).setAlpha(i == 0 ? 1f : 0f);
                if (slides.size() > 1) {
                    int idx = i;
                    View dot = new View(MainActivity.this);
                    dot.setBackground(round(i == 0 ? TEXT : 0x66FFFFFF, 3, 0));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(i == 0 ? 18 : 6), dp(6));
                    lp.setMargins(dp(3), 0, dp(3), 0);
                    dot.setOnClickListener(v -> { go(idx); restart(); });
                    dots.addView(dot, lp);
                }
            }
            current = 0;
        }

        private View slide(Drawable icon, String title, String line, String pkg) {
            FrameLayout s = new FrameLayout(MainActivity.this);
            int tone = icon == null ? 0xFF4A0A12 : averageColor(icon);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{darken(tone, 0.55f), darken(tone, 0.22f), CARD});
            s.setBackground(g);
            if (icon != null) {
                ImageView big = new ImageView(MainActivity.this);
                big.setImageDrawable(icon);
                big.setRotation(-8);
                big.setAlpha(0.95f);
                FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(120), dp(120), Gravity.END | Gravity.CENTER_VERTICAL);
                bp.rightMargin = dp(18);
                s.addView(big, bp);
            } else {
                ImageView z = new ImageView(MainActivity.this);
                z.setImageResource(R.drawable.zino_logo);
                s.addView(z, new FrameLayout.LayoutParams(dp(110), dp(110), Gravity.END | Gravity.CENTER_VERTICAL));
            }
            LinearLayout words = vertical();
            words.setPadding(dp(20), 0, dp(150), 0);
            TextView t = text(title, 22, TEXT, true);
            t.setMaxLines(2);
            words.addView(t);
            words.addView(text(line, 13, 0xFFD5D9E0, false));
            if (pkg != null) {
                Button b = button("⚡ Boost", true, v -> boostAndPlay(pkg, title));
                ((LinearLayout.LayoutParams) b.getLayoutParams()).topMargin = dp(12);
                words.addView(b);
            }
            s.addView(words, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL));
            return s;
        }

        private void go(int to) {
            if (to == current || to >= slides.size()) return;
            View out = slides.get(current), in = slides.get(to);
            out.animate().alpha(0f).translationX(-dp(16)).setDuration(420).setInterpolator(Fx.EASE).start();
            in.setTranslationX(dp(16));
            in.animate().alpha(1f).translationX(0).setDuration(420).setInterpolator(Fx.EASE).start();
            in.bringToFront();
            dots.bringToFront();
            for (int i = 0; i < dots.getChildCount(); i++) {
                View d = dots.getChildAt(i);
                d.setBackground(round(i == to ? TEXT : 0x66FFFFFF, 3, 0));
                d.getLayoutParams().width = dp(i == to ? 18 : 6);
                d.requestLayout();
            }
            current = to;
        }

        void start() { ui.removeCallbacks(next); ui.postDelayed(next, 4500); }
        void stop() { ui.removeCallbacks(next); }
        private void restart() { start(); }
    }

    /** Average colour of an icon, for the hero's background tint. */
    private int averageColor(Drawable d) {
        try {
            android.graphics.Bitmap b = android.graphics.Bitmap.createBitmap(8, 8, android.graphics.Bitmap.Config.ARGB_8888);
            d.setBounds(0, 0, 8, 8);
            d.draw(new android.graphics.Canvas(b));
            long r = 0, g = 0, bl = 0;
            int n = 0;
            for (int x = 0; x < 8; x++) for (int y = 0; y < 8; y++) {
                int c = b.getPixel(x, y);
                if ((c >>> 24) < 128) continue;
                r += (c >> 16) & 0xFF; g += (c >> 8) & 0xFF; bl += c & 0xFF; n++;
            }
            return n == 0 ? 0xFF4A0A12 : 0xFF000000 | (int) (r / n) << 16 | (int) (g / n) << 8 | (int) (bl / n);
        } catch (Exception e) {
            return 0xFF4A0A12;
        }
    }

    private static int darken(int c, float f) {
        return 0xFF000000 | (int) (((c >> 16) & 0xFF) * f) << 16 | (int) (((c >> 8) & 0xFF) * f) << 8 | (int) ((c & 0xFF) * f);
    }

    // ------------------------------------------------------------------ Boost tab

    private void buildBoostPage() {
        root.addView(logoBar());
        TextView title = text("Boost", 26, TEXT, true);
        title.setPadding(dp(2), dp(18), 0, 0);
        root.addView(title);
        root.addView(text("One tap optimizes your device and connects the game's server region.", 13, MUTED, false));
        gameBox = vertical();
        gameBox.addView(loading());
        root.addView(gameBox, spaced());
        CheckBox autoStart = check("Start Game Mode (FPS arrow) when I boost a game", prefs.getBoolean("bubble", true));
        autoStart.setOnCheckedChangeListener((box, on) -> prefs.edit().putBoolean("bubble", on).apply());
        root.addView(autoStart, spaced());
        root.addView(text("Missing a game? Add it in Me › Game detection.", 12, MUTED, false));
    }

    private void loadGames() {
        bg.execute(() -> {
            PackageManager pm = getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            TreeMap<String, ApplicationInfo> games = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            String added = "," + prefs.getString("games_add", "") + ",", excluded = "," + prefs.getString("exclude", "") + ",";
            for (ResolveInfo r : pm.queryIntentActivities(launcher, 0)) {
                ApplicationInfo a = r.activityInfo.applicationInfo;
                String p = a.packageName;
                if (p.equals(getPackageName()) || p.equals(GameTuning.STEAM) || excluded.contains("," + p + ",")) continue;
                @SuppressWarnings("deprecation")
                boolean game = a.category == ApplicationInfo.CATEGORY_GAME || (a.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                if (game || added.contains("," + p + ",") || prefs.contains("rg_" + p)) games.put(r.loadLabel(pm).toString(), a);
            }
            List<ApplicationInfo> list = new ArrayList<>(games.values());
            ui.post(() -> {
                installedGames = list;
                showBoostList();
                showGamesHome();
            });
        });
    }

    private void showBoostList() {
        gameBox.removeAllViews();
        boostButtons.clear();
        PackageManager pm = getPackageManager();
        // Steam Mobile quick-boost, pinned first
        Drawable steamIcon = null;
        try { steamIcon = pm.getApplicationIcon(GameTuning.STEAM); } catch (PackageManager.NameNotFoundException ignored) { }
        gameBox.addView(boostCard(GameTuning.STEAM, "Steam Mobile", steamIcon, steamIcon != null));
        for (ApplicationInfo a : installedGames) gameBox.addView(boostCard(a.packageName, pm.getApplicationLabel(a).toString(), pm.getApplicationIcon(a), true));
        if (installedGames.isEmpty()) gameBox.addView(text("No games found. Install a game, or add one in Me › Game detection.", 13, MUTED, false));
        updateBoostStates();
        if (search != null) filterGames(search.getText().toString());
        ui.post(this::revealPopIns);
    }

    /** A game's Boost card: icon, name, Boost button with pulse, then Server Region and Graphics rows. */
    private View boostCard(String pkg, String label, Drawable icon, boolean installed) {
        LinearLayout c = vertical();
        c.setTag(label.toLowerCase(Locale.ROOT));
        c.setBackground(round(CARD, 20, 0));
        c.setPadding(dp(14), dp(14), dp(14), dp(6));
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(iconView(icon, label, 58), new LinearLayout.LayoutParams(dp(58), dp(58)));
        TextView name = text(label, 17, TEXT, true);
        name.setPadding(dp(14), 0, dp(8), 0);
        name.setMaxLines(2);
        top.addView(name, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        if (installed) {
            BoostButton b = new BoostButton(pkg, label);
            boostButtons.put(pkg, b);
            top.addView(b.view);
        } else {
            Button dl = button("Download", false, v -> download(pkg));
            dl.setTextColor(BRAND);
            ((LinearLayout.LayoutParams) dl.getLayoutParams()).topMargin = 0;
            top.addView(dl);
        }
        c.addView(top);
        if (installed) {
            c.addView(divider());
            String cc = prefs.getString("rg_" + pkg, null);
            c.addView(settingRow("Server Region", cc == null ? "None" : GameTuning.flag(cc) + "  " + GameTuning.countryName(cc),
                    cc != null ? TEXT : MUTED, v -> openRegionSheet(pkg, label, icon)));
            if (!pkg.equals(GameTuning.STEAM)) {
                c.addView(divider());
                String saved = prefs.getString("nf_" + pkg, null);
                c.addView(settingRow("Graphics & FPS", saved == null ? "Default" : GameTuning.describe(saved), MUTED, v -> tune(pkg, label)));
            }
        }
        LinearLayout.LayoutParams lp = spaced();
        lp.topMargin = dp(12);
        c.setLayoutParams(lp);
        popIn(c);
        return c;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(BORDER);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1);
        p.topMargin = dp(12);
        d.setLayoutParams(p);
        return d;
    }

    private View settingRow(String label, String value, int valueColor, View.OnClickListener click) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(2), dp(12), dp(2), dp(8));
        r.addView(text(label, 15, MUTED, false), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        TextView v = text(value + "   ›", 15, valueColor, true);
        v.setMaxLines(1);
        r.addView(v);
        r.setBackground(ripple(null));
        r.setOnClickListener(click);
        return r;
    }

    /** Boost button with three looks: Boost, a spinner while connecting, and Play with a pulsing ring while boosted. */
    private class BoostButton {
        final FrameLayout view = new FrameLayout(MainActivity.this);
        final View ring = new View(MainActivity.this);
        final Button button;
        final android.widget.ProgressBar spin = new android.widget.ProgressBar(MainActivity.this);
        final String pkg, label;
        android.animation.Animator pulse;
        boolean active, busy;

        BoostButton(String pkg, String label) {
            this.pkg = pkg;
            this.label = label;
            view.setClipChildren(false);
            ring.setBackground(round(0, 24, BRAND));
            ring.setVisibility(View.INVISIBLE);
            view.addView(ring, new FrameLayout.LayoutParams(dp(112), dp(46), Gravity.CENTER));
            button = button("Boost", true, v -> tap());
            button.setMinWidth(dp(112));
            view.addView(button, new FrameLayout.LayoutParams(dp(112), dp(46), Gravity.CENTER));
            spin.setIndeterminateTintList(ColorStateList.valueOf(TEXT));
            spin.setVisibility(View.GONE);
            view.addView(spin, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
            view.setPadding(dp(6), dp(6), 0, dp(6));
        }

        void tap() {
            if (busy) return;
            if (active) { launch(pkg, label); return; }
            setBusy(true);
            boostAndPlay(pkg, label);
        }

        void setBusy(boolean b) {
            busy = b;
            spin.setVisibility(b ? View.VISIBLE : View.GONE);
            button.setText(b ? "" : active ? "▶ Play" : "Boost");
        }

        void setActive(boolean a) {
            if (a == active && !busy) return;
            active = a;
            setBusy(false);
            button.setBackground(ripple(round(a ? 0xFF2A070B : BRAND, 26, a ? BRAND : GLOW)));
            if (a && pulse == null) pulse = Fx.pulse(ring);
            if (!a && pulse != null) { Fx.stopPulse(pulse, ring); pulse = null; }
        }
    }

    /** Boosted = this game is connected to its region, or Game Mode is running for it. */
    private void updateBoostStates() {
        for (BoostButton b : boostButtons.values()) {
            boolean on = b.pkg.equals(RegionTunnel.activeGame) || (OverlayService.running && b.pkg.equals(OverlayService.liveGame))
                    || b.pkg.equals(boostedPkg);
            if (!b.busy) b.setActive(on);
        }
    }

    private String boostedPkg; // boosted from this screen and not yet stopped

    private void launch(String pkg, String label) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) startActivity(launch);
        else toast("Couldn't start " + label);
    }

    // ------------------------------------------------------------------ region sheet

    /** GearUP-style Select Server sheet that slides up from the bottom. Remembers the choice per game. */
    private void openRegionSheet(String pkg, String label, Drawable icon) {
        String current = prefs.getString("rg_" + pkg, null);
        LinearLayout sheet = vertical();
        sheet.setBackground(topRound(SHEET));
        sheet.setClickable(true);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(18), dp(16), dp(10), dp(14));
        head.addView(iconView(icon, label, 40), new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView t = text(label, 17, TEXT, true);
        t.setPadding(dp(12), 0, 0, 0);
        head.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        TextView close = text("✕", 22, MUTED, false);
        close.setPadding(dp(12), dp(4), dp(12), dp(4));
        close.setOnClickListener(v -> closeSheet());
        head.addView(close);
        sheet.addView(head);
        View line = new View(this);
        line.setBackgroundColor(BORDER);
        sheet.addView(line, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));

        LinearLayout list = vertical();
        list.setPadding(dp(16), dp(14), dp(16), dp(24));
        list.setLayoutTransition(new android.animation.LayoutTransition()); // smooth expand / collapse
        list.addView(text("Select Server", 20, TEXT, true));
        list.addView(text("Choose the region/country you are closest to. Only this game uses it.", 13, MUTED, false));

        LinearLayout none = new LinearLayout(this);
        none.setGravity(Gravity.CENTER_VERTICAL);
        none.setPadding(dp(16), dp(16), dp(16), dp(16));
        none.setBackground(ripple(round(GHOST, 16, 0)));
        none.addView(text("None — no VPN", 16, TEXT, true), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        none.addView(radio(current == null));
        none.setOnClickListener(v -> {
            prefs.edit().remove("rg_" + pkg).apply();
            if (pkg.equals(RegionTunnel.activeGame)) bg.execute(() -> RegionTunnel.disconnect(this));
            closeSheet();
            banner("Server Region off for " + label, MUTED);
            showBoostList();
        });
        list.addView(none, spaced());

        List<TextView> pingViews = new ArrayList<>();
        List<String> pingHosts = new ArrayList<>();
        for (int r = 0; r < GameTuning.REGIONS.length; r++) {
            LinearLayout group = vertical();
            group.setBackground(round(GHOST, 16, 0));
            LinearLayout countries = vertical();
            boolean hasCurrent = false;
            int servers = 0;
            for (String[] c : GameTuning.COUNTRIES[r]) {
                String code = c[0], conf = RegionTunnel.serverConfig(prefs, code);
                if (code.equals(current)) hasCurrent = true;
                if (conf != null) servers++;
                View sep = new View(this);
                sep.setBackgroundColor(BORDER);
                LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1);
                sp.leftMargin = dp(40);
                countries.addView(sep, sp);
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(40), dp(15), dp(16), dp(15));
                row.setBackground(ripple(null));
                row.addView(text(GameTuning.flag(code) + "   " + c[1], 16, conf != null ? TEXT : MUTED, conf != null),
                        new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
                TextView ping = text(conf == null ? "No server  " : "", 12, MUTED, false);
                row.addView(ping);
                row.addView(radio(code.equals(current)));
                if (conf != null) {
                    String host = GameTuning.endpointHost(conf);
                    if (host != null) { pingViews.add(ping); pingHosts.add(host); }
                }
                row.setOnClickListener(v -> {
                    closeSheet();
                    if (conf == null) { noServer(code); return; }
                    prefs.edit().putString("rg_" + pkg, code).apply();
                    showBoostList();
                    connectRegion(pkg, label, code); // connect now so the tick means it really works
                });
                countries.addView(row);
            }
            LinearLayout regionHead = new LinearLayout(this);
            regionHead.setGravity(Gravity.CENTER_VERTICAL);
            regionHead.setPadding(dp(16), dp(17), dp(16), dp(17));
            regionHead.setBackground(ripple(null));
            regionHead.addView(text(GameTuning.REGIONS[r], 17, TEXT, true), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            if (servers > 0) regionHead.addView(text(servers + " server" + (servers > 1 ? "s" : "") + "   ", 12, GOOD, false));
            boolean open = hasCurrent || (current == null && r == 0); // Africa opens first
            TextView chev = text("›", 22, MUTED, false);
            chev.setRotation(open ? 90 : 0);
            regionHead.addView(chev);
            countries.setVisibility(open ? View.VISIBLE : View.GONE);
            regionHead.setOnClickListener(v -> {
                boolean show = countries.getVisibility() != View.VISIBLE;
                countries.setVisibility(show ? View.VISIBLE : View.GONE);
                chev.animate().rotation(show ? 90 : 0).setDuration(200).start();
            });
            group.addView(regionHead);
            group.addView(countries);
            group.setLayoutTransition(new android.animation.LayoutTransition());
            list.addView(group, spaced());
        }
        Button manage = button("Manage servers", false, v -> { closeSheet(); showPage(2); ui.postDelayed(() -> scroll.smoothScrollTo(0, pages[2].getTop() + ((View) vpnStatus.getParent()).getTop()), 400); });
        list.addView(manage);

        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        sheet.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        openSheet(sheet);

        bg.execute(() -> { // ping each added server so the fastest stands out
            for (int i = 0; i < pingHosts.size(); i++) {
                Stats s = measure(pingHosts.get(i), 3);
                TextView pv = pingViews.get(i);
                String ms = s.avg == null ? "no reply  " : Math.round(s.avg) + " ms  ";
                int color = s.avg == null ? BAD : s.avg < 60 ? GOOD : s.avg < 120 ? WARN : BAD;
                ui.post(() -> { pv.setText(ms); pv.setTextColor(color); });
            }
        });
    }

    private View radio(boolean on) {
        View r = new View(this);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setStroke(dp(2), on ? BRAND : 0xFF4A90E2);
        if (on) d.setColor(BRAND);
        r.setBackground(d);
        r.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
        return r;
    }

    private void noServer(String code) {
        new AlertDialog.Builder(this).setTitle(GameTuning.flag(code) + " " + GameTuning.countryName(code))
                .setMessage("No server added for " + GameTuning.countryName(code) + " yet. Add a WireGuard server for this country, then pick it again.")
                .setPositiveButton("Add server", (d, w) -> addServer(code))
                .setNegativeButton("Cancel", null).show();
    }

    private void connectRegion(String pkg, String label, String code) {
        Intent consent = VpnService.prepare(this);
        if (consent != null) { pendingPlay = () -> connectRegion(pkg, label, code); startActivityForResult(consent, 3); return; }
        BoostButton b = boostButtons.get(pkg);
        if (b != null) b.setBusy(true);
        banner("Connecting to " + GameTuning.flag(code) + " " + GameTuning.countryName(code) + "…", MUTED);
        bg.execute(() -> {
            try {
                RegionTunnel.connect(this, pkg, code);
                ui.post(() -> {
                    if (b != null) b.setActive(true);
                    banner("Connected to " + GameTuning.countryName(code) + " — Optimized ✅", GOOD);
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (b != null) b.setBusy(false);
                    banner("Couldn't reach the " + GameTuning.countryName(code) + " server", BAD);
                });
            }
        });
    }

    private void openSheet(View sheet) {
        layer.removeAllViews();
        View scrim = new View(this);
        scrim.setBackgroundColor(0x99000000);
        scrim.setAlpha(0f);
        scrim.setOnClickListener(v -> closeSheet());
        FrameLayout holder = new FrameLayout(this);
        holder.setTag("sheet");
        holder.addView(scrim);
        int h = (int) (getResources().getDisplayMetrics().heightPixels * 0.82f);
        holder.addView(sheet, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, h, Gravity.BOTTOM));
        layer.addView(holder);
        sheet.setTranslationY(h);
        scrim.animate().alpha(1f).setDuration(220).start();
        sheet.animate().translationY(0).setDuration(320).setInterpolator(Fx.EASE).start();
    }

    private void closeSheet() {
        View found = layer.findViewWithTag("sheet");
        if (!(found instanceof FrameLayout)) return;
        FrameLayout holder = (FrameLayout) found;
        holder.setTag(null); // closing: back press shouldn't close it twice
        if (holder.getChildCount() < 2) { layer.removeView(holder); return; }
        View scrim = holder.getChildAt(0), sheet = holder.getChildAt(1);
        scrim.animate().alpha(0f).setDuration(200).start();
        sheet.animate().translationY(sheet.getHeight()).setDuration(240).setInterpolator(Fx.EASE)
                .withEndAction(() -> layer.removeView(holder)).start();
    }

    /** A pill that drops in from the top, then slides away. */
    private void banner(String message, int color) {
        View old = layer.findViewWithTag("banner");
        if (old != null) layer.removeView(old);
        LinearLayout b = new LinearLayout(this);
        b.setTag("banner");
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setBackground(round(0xF0181A1F, 26, color == MUTED ? BORDER : color));
        b.setPadding(dp(18), dp(12), dp(18), dp(12));
        TextView t = text(message, 14, TEXT, true);
        b.addView(t);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = dp(24);
        layer.addView(b, lp);
        b.setTranslationY(-dp(80));
        b.setAlpha(0f);
        b.animate().translationY(0).alpha(1f).setDuration(320).setInterpolator(new android.view.animation.OvershootInterpolator(1.2f)).start();
        if (color == GOOD) Fx.bounceIn(t);
        ui.postDelayed(() -> b.animate().translationY(-dp(80)).alpha(0f).setDuration(260)
                .withEndAction(() -> layer.removeView(b)).start(), color == MUTED ? 4000 : 2600);
    }

    private GradientDrawable topRound(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        float r = dp(26);
        d.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        return d;
    }

    /** Touch glow over any background. */
    private Drawable ripple(Drawable content) {
        return new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x33E60012), content,
                content == null ? new android.graphics.drawable.ColorDrawable(0xFFFFFFFF) : null);
    }

    private void boostAndPlay(String pkg, String label) {
        connectThen(pkg, label, () -> boostAndPlayNow(pkg, label));
    }

    private void boostAndPlayNow(String pkg, String label) {
        bg.execute(() -> {
            long freed = OverlayService.clearBackground(this, pkg);
            String saved = prefs.getString("nf_" + pkg, null);
            boolean canTune = Shell.ready() && Build.VERSION.SDK_INT >= 33 && GameTuning.validPackage(pkg);
            if (saved == null && prefs.contains("def_nf") && canTune) {
                // no profile yet: use the profile saved as default
                String def = prefs.getString("def_nf", null);
                float s = GameTuning.savedScale(def);
                if (s > 0) try { for (String c : GameTuning.commands(pkg, s, GameTuning.savedFps(def))) Shell.run(c); } catch (Exception ignored) { }
                else saved = def; // default is Auto: handled below
            }
            if (saved != null && GameTuning.savedScale(saved) < 0 && canTune) {
                // Auto: pick the mode from how hot the tablet is right now (the game isn't running yet)
                int preset = GameTuning.autoPreset(Build.VERSION.SDK_INT >= 29 ? getSystemService(PowerManager.class).getCurrentThermalStatus() : 0);
                try { for (String c : GameTuning.commands(pkg, GameTuning.BOOST_SCALES[preset], GameTuning.savedFps(saved))) Shell.run(c); }
                catch (Exception ignored) { }
                String name = GameTuning.BOOST_NAMES[preset];
                ui.post(() -> toast("Auto picked " + name));
            }
            if (Shell.ready()) try { Shell.run(GameTuning.clarityCommands(prefs.getBoolean("msaa", false), 1f)[0]); } catch (Exception ignored) { }
            OverlayService.addRecent(this, pkg);
            prefs.edit().putInt("pc_" + pkg, prefs.getInt("pc_" + pkg, 0) + 1).apply();
            ui.post(() -> {
                if (prefs.getBoolean("bubble", true) && !OverlayService.running && Settings.canDrawOverlays(this)) startGameMode();
                boostedPkg = pkg;
                BoostButton b = boostButtons.get(pkg);
                if (b != null) b.setActive(true);
                if (freed > 50L << 20) toast("Freed " + mb(freed) + " · Starting " + label);
                ui.postDelayed(() -> launch(pkg, label), 450); // let the pulse show first
            });
        });
    }

    /** Tune: the full per-game panel. */
    private void tune(String pkg, String label) {
        String saved = prefs.getString("nf_" + pkg, prefs.getString("def_nf", null));
        int p0 = saved == null ? 0 : GameTuning.presetFor(GameTuning.savedScale(saved));
        int[] mode = {p0 < 0 ? 0 : p0};
        int[] cap = {GameTuning.savedFps(saved)};
        AlertDialog[] dlg = new AlertDialog[1];

        LinearLayout p = vertical();
        p.setPadding(dp(20), dp(4), dp(20), dp(8));
        Button clear = button("⭐ Clearest Graphics", true, v -> { dlg[0].dismiss(); clearestGraphics(pkg, label); });
        clear.setLayoutParams(spaced());
        p.addView(clear);
        p.addView(text("Full resolution plus the Clarity panel (edge smoothing, colour vibrance).", 12, MUTED, false));

        p.addView(section("Clarity mode"));
        TextView info = text(GameTuning.BOOST_INFO[mode[0]], 12, MUTED, false);
        GridLayout modes = new GridLayout(this);
        modes.setColumnCount(2);
        Button[] modeChips = new Button[GameTuning.BOOST_NAMES.length];
        for (int i = 0; i < modeChips.length; i++) {
            int idx = i;
            modeChips[i] = chip(GameTuning.BOOST_NAMES[i], v -> {
                mode[0] = idx;
                for (int j = 0; j < modeChips.length; j++) chipOn(modeChips[j], j == idx);
                info.setText(GameTuning.BOOST_INFO[idx]);
            });
            chipOn(modeChips[i], i == mode[0]);
            modes.addView(modeChips[i], gridCell());
        }
        p.addView(modes);
        p.addView(info);

        p.addView(section("NSS · NFRU · NSSD"));
        p.addView(text("Arm neural graphics — not available here. Games must be built with them, on a GPU with Arm "
                + "neural accelerators. See Tools › AI Graphics Engine.", 12, WARN, false));

        p.addView(section("FPS limit"));
        GridLayout caps = new GridLayout(this);
        caps.setColumnCount(4);
        int max = Math.round(refreshRates()[1]);
        List<Integer> options = new ArrayList<>();
        for (int f : GameTuning.FPS) if (f > 0 && f <= max + 1) options.add(f);
        options.add(0); // Max = no limit
        Button[] capChips = new Button[options.size()];
        for (int i = 0; i < capChips.length; i++) {
            int f = options.get(i), idx = i;
            capChips[i] = chip(f == 0 ? "Max" : String.valueOf(f), v -> {
                cap[0] = f;
                for (int j = 0; j < capChips.length; j++) chipOn(capChips[j], j == idx);
            });
            chipOn(capChips[i], f == cap[0]);
            caps.addView(capChips[i], gridCell());
        }
        p.addView(caps);

        p.addView(section("While playing this game"));
        CheckBox bright = check("Lock brightness", prefs.getBoolean("gm_bright_" + pkg, prefs.getBoolean("gm_bright", true)));
        CheckBox ads = check("Ad blocker on", prefs.getBoolean("ads_" + pkg, false));
        CheckBox latency = check("Low latency (top refresh rate)", prefs.getBoolean("gm_latency_" + pkg, prefs.getBoolean("gm_latency", true)));
        p.addView(bright);
        p.addView(ads);
        p.addView(latency);
        ScrollView sv = new ScrollView(this);
        sv.addView(p);

        dlg[0] = new AlertDialog.Builder(this)
                .setTitle("Tune · " + label)
                .setView(sv)
                .setPositiveButton("Save", (d, w) -> saveTune(pkg, label, mode[0], cap[0], bright.isChecked(), ads.isChecked(), latency.isChecked(), false))
                .setNeutralButton("Save as default", (d, w) -> saveTune(pkg, label, mode[0], cap[0], bright.isChecked(), ads.isChecked(), latency.isChecked(), true))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveTune(String pkg, String label, int mode, int fps, boolean bright, boolean ads, boolean latency, boolean asDefault) {
        SharedPreferences.Editor ed = prefs.edit().putBoolean("gm_bright_" + pkg, bright).putBoolean("ads_" + pkg, ads)
                .putBoolean("gm_latency_" + pkg, latency);
        if (asDefault) ed.putString("def_nf", GameTuning.save(GameTuning.BOOST_SCALES[mode], fps))
                .putBoolean("gm_bright", bright).putBoolean("gm_latency", latency);
        ed.apply();
        if (ads && VpnService.prepare(this) != null) toast("Turn the ad blocker on once in Tools so Android allows it for games");
        if (Build.VERSION.SDK_INT < 33) { toast("Saved. Clarity mode and FPS limit need Android 13 or newer."); loadGames(); return; }
        applyTuning(pkg, label, GameTuning.BOOST_SCALES[mode], fps);
        if (asDefault) toast("Saved as the default for games without their own profile");
    }

    private TextView section(String title) {
        TextView t = text(title.toUpperCase(Locale.ROOT), 11, BRAND, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(0, dp(18), 0, dp(4));
        return t;
    }

    private GridLayout.LayoutParams gridCell() {
        GridLayout.LayoutParams p = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        p.width = 0;
        p.height = dp(42);
        p.setMargins(0, dp(3), dp(6), dp(3));
        return p;
    }

    private CheckBox check(String label, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(TEXT);
        c.setButtonTintList(ColorStateList.valueOf(BRAND));
        c.setChecked(on);
        return c;
    }

    private void applyTuning(String pkg, String label, float scale, int fps) {
        if (scale < 0) { // Auto is applied each time you tap Play
            prefs.edit().putString("nf_" + pkg, GameTuning.save(scale, fps)).apply();
            toast(label + ": Auto — Zino picks the mode each time you tap Play");
            loadGames();
            return;
        }
        String[] cmds;
        try { cmds = GameTuning.commands(pkg, scale, fps); }
        catch (IllegalArgumentException e) { toast("Can't tune " + label); return; }
        if (!Shell.ready()) {
            StringBuilder adb = new StringBuilder();
            for (String c : cmds) adb.append("adb shell ").append(c).append('\n');
            getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("Zino", adb.toString()));
            toast("Shizuku isn't connected, so nothing changed. The ADB commands are copied — run them from a PC, or connect Shizuku.");
            return;
        }
        bg.execute(() -> {
            try {
                for (String c : cmds) Shell.run(c);
                prefs.edit().putString("nf_" + pkg, GameTuning.save(scale, fps)).apply();
                ui.post(() -> { toast(label + ": " + GameTuning.describe(GameTuning.save(scale, fps)) + ". Start the game to use it."); loadGames(); });
            } catch (Exception e) {
                ui.post(() -> toast("Couldn't apply: " + e.getMessage()));
            }
        });
    }

    /** ✨ Clearest Graphics: back to native resolution, then the Clarity panel. */
    private void clearestGraphics(String pkg, String label) {
        int fps = GameTuning.savedFps(prefs.getString("nf_" + pkg, null));
        if (Shell.ready() && Build.VERSION.SDK_INT >= 33) applyTuning(pkg, label, 1f, fps);
        else prefs.edit().putString("nf_" + pkg, GameTuning.save(1f, fps)).apply();
        clarityPanel(pkg, label);
    }

    private void clarityPanel(String pkg, String label) {
        String saved = prefs.getString("cl_" + pkg, null);
        float vib0 = saved == null ? 1f + prefs.getInt("vib_default", 0) / 100f : Float.parseFloat(saved.split(",")[1]);
        LinearLayout p = vertical();
        p.setPadding(dp(22), dp(8), dp(22), 0);
        p.addView(text("✓ Native resolution — the game draws every pixel", 14, GOOD, true));

        CheckBox edge = new CheckBox(this);
        edge.setText("Edge smoothing (4x MSAA) — smoother edges in OpenGL games, from the next launch. Applies to all games.");
        edge.setTextColor(TEXT);
        edge.setButtonTintList(ColorStateList.valueOf(BRAND));
        edge.setChecked(prefs.getBoolean("msaa", false));
        p.addView(edge, spaced());

        TextView vibLabel = text("", 14, TEXT, true);
        vibLabel.setPadding(0, dp(14), 0, 0);
        p.addView(vibLabel);
        SeekBar vib = new SeekBar(this);
        vib.setMax(60); // 1.00 – 1.60
        vib.setProgress(Math.round((vib0 - 1f) * 100));
        vib.setProgressTintList(ColorStateList.valueOf(BRAND));
        vib.setThumbTintList(ColorStateList.valueOf(BRAND));
        vibLabel.setText("Colour vibrance: +" + vib.getProgress() + "%");
        vib.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) { vibLabel.setText("Colour vibrance: +" + v + "%"); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        p.addView(vib, spaced());
        p.addView(text("Richer colours while this game is open (whole screen, Shizuku).", 12, MUTED, false));

        Button upscale = button("Image Boost: " + GameTuning.describe(prefs.getString("nf_" + pkg, null)) + " — change", false, v -> tune(pkg, label));
        upscale.setTextSize(12);
        p.addView(upscale);
        p.addView(text("\nOn your Red Magic: press the Magic Key › GameSpace › this game, and turn on Frame Rate Boost "
                + "if it's offered — it upscales supported games on the tablet's own chips.\n\n"
                + "Sharpness and texture detail come from the game's own Graphics settings — set them to the highest "
                + "there. Android doesn't let other apps sharpen a game's picture.", 12, MUTED, false));
        ScrollView sv = new ScrollView(this);
        sv.addView(p);

        new AlertDialog.Builder(this)
                .setTitle("✨ " + label + " · Clarity")
                .setView(sv)
                .setPositiveButton("Save", (d, w) -> saveClarity(pkg, edge.isChecked(), 1f + vib.getProgress() / 100f))
                .setNeutralButton("Reset to default", (d, w) -> saveClarity(pkg, false, 1f))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveClarity(String pkg, boolean edge, float vibrance) {
        prefs.edit().putBoolean("msaa", edge).putString("cl_" + pkg, GameTuning.saveClarity(edge, vibrance)).apply();
        if (!Shell.ready()) { toast("Saved. Start Shizuku so Zino can apply it."); return; }
        bg.execute(() -> {
            try { Shell.run(GameTuning.clarityCommands(edge, 1f)[0]); } catch (Exception ignored) { }
            ui.post(() -> toast("Clarity saved — it applies when you play this game"));
        });
    }

    // ------------------------------------------------------------------ Game VPN (server region)

    /** Connects the game's VPN (if it has a region) and then runs next. Asks Android for VPN permission the first time. */
    private void connectThen(String pkg, String label, Runnable next) {
        String cc = prefs.getString("rg_" + pkg, null);
        if (cc == null || RegionTunnel.serverConfig(prefs, cc) == null) { next.run(); return; }
        Intent consent = VpnService.prepare(this);
        if (consent != null) {
            pendingPlay = () -> boostAndPlay(pkg, label);
            BoostButton b = boostButtons.get(pkg);
            if (b != null) b.setBusy(false);
            startActivityForResult(consent, 3);
            return;
        }
        if (!pkg.equals(RegionTunnel.activeGame)) banner("Connecting to " + GameTuning.flag(cc) + " " + GameTuning.countryName(cc) + "…", MUTED);
        bg.execute(() -> {
            try {
                boolean already = pkg.equals(RegionTunnel.activeGame) && cc.equals(RegionTunnel.activeCountry);
                RegionTunnel.connect(this, pkg, cc);
                ui.post(() -> {
                    if (!already) banner("Connected to " + GameTuning.countryName(cc) + " — Optimized ✅", GOOD);
                    next.run();
                });
            } catch (Exception e) {
                ui.post(() -> {
                    BoostButton b = boostButtons.get(pkg);
                    if (b != null) b.setBusy(false);
                });
                ui.post(() -> new AlertDialog.Builder(this).setTitle("Couldn't connect to " + GameTuning.countryName(cc))
                        .setMessage("Check the server is running and its config is right.\n\n" + e)
                        .setPositiveButton("Play without VPN", (d, w) -> next.run())
                        .setNegativeButton("Cancel", null).show());
            }
        });
    }

    private void buildVpnCard() {
        LinearLayout c = card("🌍 Game VPN servers");
        c.addView(text("Play through a server in another country — for example Côte d'Ivoire, Ghana or Nigeria — so the game "
                + "matches you with players and servers there. Only the chosen game uses it. Pick a country per game under "
                + "Games › Server Region.", 13, MUTED, false));
        vpnStatus = text("", 15, TEXT, true);
        vpnStatus.setPadding(0, dp(10), 0, 0);
        c.addView(vpnStatus);
        vpnDisconnect = button("Disconnect", false, v -> bg.execute(() -> { RegionTunnel.disconnect(this); ui.post(this::showServers); }));
        c.addView(vpnDisconnect);
        serverBox = vertical();
        c.addView(serverBox);
        c.addView(button("+ Add server", true, v -> pickCountry()));
        c.addView(text("Zino comes with no servers. Each country needs a WireGuard server — your own small server (VPS) in that "
                + "country, set up with the script in the project's server folder, or a WireGuard file from a VPN service "
                + "you pay for (for your own use). Some games don't allow changing region with a VPN.", 12, WARN, false));
    }

    /** Lists added servers with Remove buttons and the connection status. */
    private void showServers() {
        String g = RegionTunnel.activeGame, cc = RegionTunnel.activeCountry;
        vpnStatus.setText(g == null ? "Not connected" : "● Connected · " + GameTuning.flag(cc) + " " + GameTuning.countryName(cc));
        vpnStatus.setTextColor(g == null ? MUTED : GOOD);
        vpnDisconnect.setVisibility(g == null ? View.GONE : View.VISIBLE);
        serverBox.removeAllViews();
        for (String[][] region : GameTuning.COUNTRIES) for (String[] c : region) {
            if (RegionTunnel.serverConfig(prefs, c[0]) == null) continue;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(8), 0, 0);
            row.addView(text(GameTuning.flag(c[0]) + "  " + c[1], 15, TEXT, true), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            Button rm = button("Remove", false, v -> new AlertDialog.Builder(this).setTitle("Remove " + c[1] + " server?")
                    .setPositiveButton("Remove", (d, w) -> { prefs.edit().remove("srv_" + c[0]).apply(); showServers(); loadGames(); })
                    .setNegativeButton("Cancel", null).show());
            rm.setTextSize(12);
            ((LinearLayout.LayoutParams) rm.getLayoutParams()).topMargin = 0;
            row.addView(rm);
            serverBox.addView(row);
        }
        if (serverBox.getChildCount() == 0) serverBox.addView(text("No servers added yet.", 13, MUTED, false));
    }

    private void pickCountry() {
        List<String> names = new ArrayList<>(), codes = new ArrayList<>();
        for (int r = 0; r < GameTuning.REGIONS.length; r++) for (String[] c : GameTuning.COUNTRIES[r]) {
            codes.add(c[0]);
            names.add(GameTuning.flag(c[0]) + "  " + c[1] + "  ·  " + GameTuning.REGIONS[r]);
        }
        new AlertDialog.Builder(this).setTitle("Server country")
                .setItems(names.toArray(new String[0]), (d, i) -> addServer(codes.get(i))).show();
    }

    /** Add the WireGuard config for a country: import a .conf file or paste the text. */
    private void addServer(String code) {
        new AlertDialog.Builder(this).setTitle(GameTuning.flag(code) + " " + GameTuning.countryName(code) + " server")
                .setMessage("Add the WireGuard config for this country's server (a .conf file, or its text).")
                .setPositiveButton("Import .conf file", (d, w) -> {
                    pendingCountry = code;
                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                    try { startActivityForResult(pick, 4); } catch (ActivityNotFoundException e) { toast("No file picker on this device — paste the text instead"); }
                })
                .setNeutralButton("Paste text", (d, w) -> pasteServer(code))
                .setNegativeButton("Cancel", null).show();
    }

    private void pasteServer(String code) {
        EditText box = new EditText(this);
        box.setHint("[Interface]\nPrivateKey = …\nAddress = …\n\n[Peer]\nPublicKey = …\nEndpoint = …:51820\nAllowedIPs = 0.0.0.0/0");
        box.setMinLines(8);
        box.setTextColor(TEXT);
        box.setTypeface(Typeface.MONOSPACE);
        box.setTextSize(12);
        new AlertDialog.Builder(this).setTitle(GameTuning.countryName(code) + " · WireGuard config").setView(box)
                .setPositiveButton("Save", (d, w) -> saveServer(code, box.getText().toString()))
                .setNegativeButton("Cancel", null).show();
    }

    /** Checks the config with the WireGuard parser before saving, so a bad file fails here, not mid-game. */
    private void saveServer(String code, String conf) {
        try {
            String test = GameTuning.withIncludedApp(conf, getPackageName());
            com.wireguard.config.Config.parse(new java.io.ByteArrayInputStream(test.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            if (GameTuning.endpointHost(conf) == null) throw new IllegalArgumentException("No Endpoint line");
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("That config doesn't look right")
                    .setMessage("It must be a WireGuard config with [Interface] and [Peer] sections and an Endpoint.\n\n" + e.getMessage())
                    .setPositiveButton("OK", null).show();
            return;
        }
        prefs.edit().putString("srv_" + code, conf.trim()).apply();
        toast(GameTuning.flag(code) + " " + GameTuning.countryName(code) + " server added");
        showServers();
        loadGames();
    }

    // ------------------------------------------------------------------ Game Mode

    private void toggleGameMode() {
        if (OverlayService.running) OverlayService.stop(this);
        else startGameMode();
        ui.postDelayed(this::updateGameMode, 300);
    }

    private void startGameMode() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 2); // for the Stop button in notifications
        }
        if (OverlayService.arrowMode(this).equals("auto") && !OverlayService.hasUsageAccess(this)) {
            toast("Tip: allow Usage access in Settings so the arrow appears only in games");
        }
        OverlayService.start(this);
    }

    private void updateGameMode() {
        boolean on = OverlayService.running;
        gameMode.setText(on ? "■  Stop" : "▶  Start");
        gameMode.setBackground(ripple(round(on ? 0xFF2A070B : BRAND, 26, on ? BRAND : GLOW)));
        String mode = OverlayService.arrowMode(this);
        gameModeNote.setText(!on ? "FPS arrow and game optimizations while you play"
                : mode.equals("auto") && OverlayService.hasUsageAccess(this) ? "On · the FPS arrow appears in your games"
                : mode.equals("off") ? "On · FPS arrow is off (Me › FPS arrow)"
                : "On · the FPS arrow is on screen");
        gameModeNote.setTextColor(on ? GOOD : MUTED);
    }

    // ------------------------------------------------------------------ Tools

    // ------------------------------------------------------------------ Me tab

    private void buildMe() {
        root.addView(logoBar());
        LinearLayout profile = card(null);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.ic_tab_me);
        avatar.setImageTintList(ColorStateList.valueOf(TEXT));
        avatar.setPadding(dp(12), dp(12), dp(12), dp(12));
        avatar.setBackground(round(0xFF2A070B, 30, BRAND));
        row.addView(avatar, new LinearLayout.LayoutParams(dp(60), dp(60)));
        LinearLayout who = vertical();
        who.setPadding(dp(14), 0, 0, 0);
        who.addView(text("Guest player", 19, TEXT, true));
        who.addView(text("Playing without account · everything works", 12, MUTED, false));
        row.addView(who, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        profile.addView(row);
        LinearLayout acts = new LinearLayout(this);
        Button sign = button("Sign in", false, v -> comingSoon("Sign in",
                "Cloud saves and synced game profiles need Zino's online account service, which isn't live yet. "
                        + "Until then everything is saved on this device."));
        Button pro = button("✦ Zino Pro", true, v -> comingSoon("Zino Pro", "Zino Pro isn't available yet. Everything in this version is free."));
        acts.addView(sign, new LinearLayout.LayoutParams(0, dp(46), 1));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, dp(46), 1);
        pp.leftMargin = dp(8);
        acts.addView(pro, pp);
        acts.setPadding(0, dp(14), 0, 0);
        profile.addView(acts);

        LinearLayout quick = card("Quick actions");
        GridLayout chips = new GridLayout(this);
        chips.setColumnCount(2);
        chipBoost = chip("🟣 Boost", v -> setQuick("gm_perf", OverlayService.ACTION_BOOST));
        chipAds = chip("🛡 Ad blocker", v -> toggleAdBlock());
        chipLatency = chip("⏱ Low latency", v -> setQuick("gm_latency", OverlayService.ACTION_LATENCY));
        chipPilot = chip("🤖 Auto Pilot", v -> { prefs.edit().putBoolean("autopilot", !prefs.getBoolean("autopilot", true)).apply(); updateLive(); });
        for (Button b : new Button[]{chipBoost, chipAds, chipLatency, chipPilot}) {
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            gp.width = 0;
            gp.height = dp(46);
            gp.setMargins(0, dp(4), dp(8), dp(4));
            chips.addView(b, gp);
        }
        quick.addView(chips);
        quick.addView(text("Boost holds CPU/GPU speed steady. Low latency keeps the screen at its top refresh rate. "
                + "Auto Pilot switches them for you from heat, battery and FPS. Boost and Low latency need Shizuku.", 12, MUTED, false));

        root.addView(sectionTitle("Tools"));
        buildTools();
        root.addView(sectionTitle("Settings"));
        buildSettings();
    }

    private void buildTools() {
        LinearLayout ib = card("Clarity modes · Image Boost");
        ib.addView(text("Lower modes make the game draw fewer pixels for more FPS, less heat and longer battery. "
                + "Ultra Quality keeps full resolution. Set per game in Boost › Graphics & FPS (Android 13+, Shizuku).", 13, MUTED, false));
        for (int i = 0; i < GameTuning.BOOST_NAMES.length; i++) {
            LinearLayout r = vertical();
            r.setPadding(0, dp(10), 0, 0);
            r.addView(text(GameTuning.BOOST_NAMES[i], 15, TEXT, true));
            r.addView(text(GameTuning.BOOST_INFO[i], 12, MUTED, false));
            ib.addView(r);
        }

        buildVpnCard();

        // AI Graphics Engine: honest explainer
        LinearLayout ai = card("✨ AI Graphics Engine");
        ai.addView(text("Arm's neural graphics bring DLSS-style AI to phones and tablets. They run only in games built "
                + "with them, on GPUs that have Arm neural accelerators (Mali G2-Ultra NX, announced September 2026). "
                + "No app can switch them on for other games.", 13, MUTED, false));
        aiTech(ai, "🖼 Neural Super Sampling (NSS)", "Rebuilds a sharp, smooth-edged picture from a lower-resolution render.",
                "Best for: any game · FPS: higher · Battery: lower use");
        aiTech(ai, "⚡ Neural Frame Rate Upscaling (NFRU)", "Adds AI frames between real ones, so 60 rendered FPS looks much smoother.",
                "Best for: fast action · FPS shown: up to 2x · Battery: lower use, slight extra delay");
        aiTech(ai, "🌟 NSS + Denoising (NSSD)", "Upscaling plus clean-up of grainy ray-traced shadows, reflections and lighting.",
                "Best for: open worlds, night scenes · FPS: higher than plain ray tracing");
        TextView dev = text("This device: " + gpuName() + " — not supported", 14, WARN, true);
        dev.setPadding(0, dp(12), 0, dp(4));
        ai.addView(dev);
        ai.addView(text("What works on your device instead: Clarity modes (Image Boost) per game, ⭐ Clearest Graphics, "
                + "Smart Auto Pilot, and on Red Magic, Frame Rate Boost in GameSpace (Magic Key) — real frame insertion on the tablet's own chips.", 12, MUTED, false));

        // Clearest Graphics defaults
        LinearLayout cg = card("⭐ Clearest Graphics defaults");
        cg.addView(text("Used for every game that has no Clarity settings of its own.", 13, MUTED, false));
        CheckBox edge = check("Edge smoothing (4x MSAA) — smoother edges in OpenGL games, from the next launch", prefs.getBoolean("msaa", false));
        edge.setOnCheckedChangeListener((b, on) -> {
            prefs.edit().putBoolean("msaa", on).apply();
            if (Shell.ready()) bg.execute(() -> { try { Shell.run(GameTuning.clarityCommands(on, 1f)[0]); } catch (Exception ignored) { } });
        });
        cg.addView(edge, spaced());
        TextView vibLabel = text("", 14, TEXT, true);
        vibLabel.setPadding(0, dp(12), 0, 0);
        cg.addView(vibLabel);
        SeekBar vib = new SeekBar(this);
        vib.setMax(60);
        vib.setProgress(prefs.getInt("vib_default", 0));
        vib.setProgressTintList(ColorStateList.valueOf(BRAND));
        vib.setThumbTintList(ColorStateList.valueOf(BRAND));
        vibLabel.setText("Default colour vibrance: +" + vib.getProgress() + "%");
        vib.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                vibLabel.setText("Default colour vibrance: +" + v + "%");
                prefs.edit().putInt("vib_default", v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        cg.addView(vib, spaced());

        // Performance, display and battery
        LinearLayout perf = card("Performance · Display · Battery");
        CheckBox pilot = check("🤖 Smart Auto Pilot — watches heat, battery and FPS while you play and switches Boost, "
                + "Low latency and the next launch's Clarity mode for you", prefs.getBoolean("autopilot", true));
        pilot.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("autopilot", on).apply());
        perf.addView(pilot);
        perf.addView(text("\n• Boost: steady CPU/GPU speed — more FPS, more heat. Turned off automatically when hot.\n"
                + "• Low latency: locks the screen at its top refresh rate — quicker response, a little more battery.\n"
                + "• Clarity modes: Ultra Quality uses the most battery, Ultra Performance the least.\n"
                + "• Battery saver slows games down — keep it off while playing.", 13, TEXT, false));
        perf.addView(button("Battery settings", false, v -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        perf.addView(button("Display & refresh rate", false, v -> open(Settings.ACTION_DISPLAY_SETTINGS)));

        LinearLayout status = card("Phone status");
        statusBox = vertical();
        status.addView(statusBox);
        status.addView(button("Refresh", false, v -> refreshStatus()));

        LinearLayout ads = card("Ad blocker");
        ads.addView(text("Blocks the ad networks games use (AdMob, Unity Ads, AppLovin, ironSource and more) "
                + "for every app on your phone. Android shows it as a VPN, but it all runs on your phone and "
                + "only filters ad addresses.", 13, MUTED, false));
        adStatus = text("", 15, TEXT, true);
        adStatus.setPadding(0, dp(10), 0, 0);
        ads.addView(adStatus);
        adToggle = button("", true, v -> toggleAdBlock());
        ads.addView(adToggle);
        ads.addView(text("Note: \"watch an ad for a reward\" won't work while it's on. If a game won't load, "
                + "turn the blocker off for that game. Set Private DNS to Off or Automatic in Settings, "
                + "or it can bypass the blocker.", 12, WARN, false));

        LinearLayout ping = card("Ping test");
        ping.addView(text("Tests your router and internet servers, then tells you where lag comes from. "
                + "Add your game server's IP if you know it.", 13, MUTED, false));
        hosts = new EditText(this);
        hosts.setText(prefs.getString("hosts", "1.1.1.1, 8.8.8.8"));
        hosts.setTextColor(TEXT);
        hosts.setSingleLine();
        hosts.setBackground(round(BG, 12, BORDER));
        hosts.setPadding(dp(12), dp(10), dp(12), dp(10));
        ping.addView(hosts, spaced());
        runPing = button("Run ping test", true, v -> runPingTest());
        ping.addView(runPing);
        pingOut = text("", 13, TEXT, false);
        pingOut.setTypeface(Typeface.MONOSPACE);
        ping.addView(pingOut);
        verdict = text("", 14, TEXT, true);
        verdict.setPadding(0, dp(8), 0, 0);
        ping.addView(verdict);

        buildGraphicsCard();
    }

    private void aiTech(LinearLayout parent, String name, String what, String facts) {
        LinearLayout r = vertical();
        r.setPadding(0, dp(12), 0, 0);
        r.addView(text(name, 15, TEXT, true));
        r.addView(text(what, 13, TEXT, false));
        r.addView(text(facts, 12, MUTED, false));
        parent.addView(r);
    }

    /** Best guess at the GPU family from the chip maker. */
    private String gpuName() {
        String maker = Build.VERSION.SDK_INT >= 31 ? Build.SOC_MANUFACTURER : Build.HARDWARE;
        String m = maker == null ? "" : maker.toLowerCase(Locale.ROOT);
        if (m.contains("qti") || m.contains("qualcomm") || m.contains("qcom")) return "Qualcomm Snapdragon (Adreno GPU)";
        if (m.contains("mediatek") || m.startsWith("mt")) return "MediaTek (Arm Mali / Immortalis GPU)";
        if (m.contains("google")) return "Google Tensor";
        if (m.contains("samsung") || m.contains("exynos")) return "Samsung Exynos";
        return maker == null || maker.isEmpty() ? "unknown chip" : maker;
    }

    private void refreshStatus() {
        statusBox.removeAllViews();
        PowerManager pm = getSystemService(PowerManager.class);
        if (Build.VERSION.SDK_INT >= 29) {
            int t = pm.getCurrentThermalStatus();
            String[] names = {"Cool", "Slightly warm", "Warm — games may start slowing down",
                    "Hot — performance is being throttled", "Very hot — heavily throttled", "Critical", "Shutting down"};
            line("Temperature", names[Math.min(t, 6)], t == 0 ? GOOD : t == 1 ? TEXT : t == 2 ? WARN : BAD);
        }
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            float celsius = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int scale = Math.max(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
            int level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / scale;
            line("Battery", level + "% · " + celsius + "°C", celsius >= 42 ? BAD : celsius >= 38 ? WARN : TEXT);
        }
        if (pm.isPowerSaveMode()) {
            line("Battery saver", "ON — this slows games down", BAD);
            statusBox.addView(button("Turn off battery saver", true, v -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        } else {
            line("Battery saver", "Off", GOOD);
        }
        ActivityManager.MemoryInfo mem = memInfo();
        line("Free memory", mb(mem.availMem) + " of " + mb(mem.totalMem), mem.lowMemory ? BAD : TEXT);
        float[] hz = refreshRates();
        line("Screen", "Up to " + Math.round(hz[1]) + " Hz (now " + Math.round(hz[0]) + " Hz)", hz[1] > 61 ? GOOD : TEXT);

        ConnectivityManager cm = getSystemService(ConnectivityManager.class);
        NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
        onWifi = nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        if (onWifi) {
            WifiInfo wi = wifi().getConnectionInfo();
            int rssi = wi.getRssi(), f = wi.getFrequency();
            String band = f > 5900 ? "6 GHz" : f > 4900 ? "5 GHz" : "2.4 GHz";
            String quality = rssi >= -60 ? "strong" : rssi >= -70 ? "OK" : "weak";
            line("Wi-Fi", band + " · signal " + quality + " (" + rssi + " dBm) · " + wi.getLinkSpeed() + " Mbps",
                    rssi >= -60 ? GOOD : rssi >= -70 ? WARN : BAD);
            if (band.equals("2.4 GHz")) tip("2.4 GHz Wi-Fi is crowded and slow. Join your router's 5 GHz network for steadier ping.");
            if (rssi < -70) tip("Weak Wi-Fi signal causes lag spikes. Move closer to the router or remove walls in between.");
        } else if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            line("Network", "Mobile data — usually higher, less stable ping than good Wi-Fi", WARN);
        } else {
            line("Network", "Offline", BAD);
        }
        int filter = nm().getCurrentInterruptionFilter();
        if (filter != NotificationManager.INTERRUPTION_FILTER_ALL && filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN) {
            line("Do Not Disturb", "On", GOOD);
            if (nm().isNotificationPolicyAccessGranted()) {
                statusBox.addView(button("Turn off Do Not Disturb", false, v -> {
                    nm().setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
                    refreshStatus();
                }));
            }
        }
    }

    private void toggleAdBlock() {
        if (AdBlockService.running) {
            startService(new Intent(this, AdBlockService.class).setAction(AdBlockService.ACTION_STOP));
            return;
        }
        Intent consent = VpnService.prepare(this); // Android asks once before a VPN can start
        if (consent != null) startActivityForResult(consent, 1);
        else startService(new Intent(this, AdBlockService.class));
    }

    private void runPingTest() {
        String raw = hosts.getText().toString();
        prefs.edit().putString("hosts", raw).apply();
        List<String[]> targets = new ArrayList<>(); // {host, label}
        String gw = onWifi ? gateway() : null;
        if (gw != null) targets.add(new String[]{gw, "Router"});
        for (String h : raw.trim().split("[,;\\s]+")) if (!h.isEmpty()) targets.add(new String[]{h, h});
        if (targets.isEmpty()) { toast("Add a server to test"); return; }

        runPing.setEnabled(false);
        verdict.setText("");
        pingOut.setText("Testing…");
        bg.execute(() -> {
            StringBuilder sb = new StringBuilder(String.format(Locale.US, "%-15s %7s %7s %5s%n", "", "avg", "jitter", "loss"));
            Stats router = null;
            List<Stats> internet = new ArrayList<>();
            for (String[] t : targets) {
                String label = t[1].length() > 15 ? t[1].substring(0, 14) + "…" : t[1];
                String head = sb.toString();
                ui.post(() -> pingOut.setText(head + "Testing " + label + "…"));
                Stats s = measure(t[0], 20);
                if (t[1].equals("Router")) router = s; else internet.add(s);
                sb.append(String.format(Locale.US, "%-15s %7s %7s %4.0f%%%n", label, ms(s.avg), ms(s.jitter), s.loss));
            }
            int d = Stats.diagnose(router, internet);
            String table = sb.toString();
            ui.post(() -> {
                pingOut.setText(table);
                verdict.setText(verdictText(d));
                verdict.setTextColor(d == Stats.HEALTHY ? GOOD : BAD);
                runPing.setEnabled(true);
            });
        });
    }

    private String verdictText(int d) {
        switch (d) {
            case Stats.HOME_NETWORK:
                return "Your Wi-Fi is the problem — even your own router is unstable. Move closer to it, "
                        + "use the 5 GHz network, restart the router, or stop other downloads on your network.";
            case Stats.ISP:
                return "Your Wi-Fi is fine, but the connection is unstable after your router — that's your internet "
                        + "provider. Try a quieter time of day, or contact them with these results.";
            case Stats.NO_REPLY:
                return "None of the servers replied. Check your connection, or try different server addresses.";
            default:
                return "Connection looks healthy for gaming: stable with no real packet loss.";
        }
    }

    /** ICMP ping via the system ping tool; falls back to TCP connect time where that isn't allowed. */
    private Stats measure(String host, int count) {
        try {
            java.lang.Process p = new ProcessBuilder("/system/bin/ping", "-c", String.valueOf(count), "-i", "0.2",
                    "-W", "1", "-w", "30", host).redirectErrorStream(true).start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                for (String l; (l = r.readLine()) != null; ) out.append(l).append('\n');
            }
            p.waitFor();
            int sent = Stats.parseSent(out.toString());
            if (sent > 0) return new Stats(Stats.parseTimes(out.toString()), sent);
        } catch (Exception ignored) { }
        // shortcut: TCP connect time reads a little higher than real ping; only used on ROMs that block ICMP
        List<Double> times = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            long start = System.nanoTime();
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, 443), 1000);
                times.add((System.nanoTime() - start) / 1e6);
            } catch (Exception ignored) { }
            try { Thread.sleep(200); } catch (InterruptedException e) { break; }
        }
        return new Stats(times, count);
    }

    private String gateway() {
        DhcpInfo d = wifi().getDhcpInfo();
        int ip = d == null ? 0 : d.gateway;
        if (ip == 0) return null;
        return (ip & 0xff) + "." + (ip >> 8 & 0xff) + "." + (ip >> 16 & 0xff) + "." + (ip >> 24 & 0xff);
    }

    private void buildGraphicsCard() {
        LinearLayout g = card("Better graphics & FPS");
        int max = Math.round(refreshRates()[1]);
        StringBuilder tips = new StringBuilder();
        if (max > 61) {
            tips.append("• Your screen can run at ").append(max).append(" Hz. Set it to the highest option in Display settings, ")
                .append("then pick the matching frame rate in your game (e.g. 90 or 120 FPS).\n\n");
        }
        tips.append("• Clearest picture: tap ✨ Clearest Graphics on the game, and set the game's own Graphics to the highest it allows.\n\n")
            .append("• In the game's own settings, pick the highest frame rate first, then raise graphics only while it stays smooth. ")
            .append("Steady FPS looks better than high detail that stutters.\n\n")
            .append("• If Temperature says Warm or Hot, drop graphics one step — a hot device throttles and loses FPS. ")
            .append("Remove thick cases and avoid playing while charging.\n\n")
            .append("• Red Magic: press the Magic Key for GameSpace — Rise Mode for full power, and Frame Rate Boost where offered.\n\n")
            .append("• Other phones: turn on the built-in game mode — Game Booster (Samsung), Game Dashboard (Pixel), Game Turbo (Xiaomi).");
        g.addView(text(tips.toString(), 13.5f, TEXT, false));
        g.addView(button("Open Display settings", true, v -> open(Settings.ACTION_DISPLAY_SETTINGS)));
        g.addView(button("Open Developer options", false, v -> {
            if (Settings.Global.getInt(getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 0) {
                toast("Turn on Developer options first: Settings › About phone › tap Build number 7 times");
            } else {
                open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
            }
        }));
    }

    // ------------------------------------------------------------------ Settings

    private void buildSettings() {

        LinearLayout general = card("General");
        option(general, "Start Game Mode automatically after the tablet restarts", "boot_start", true);
        general.addView(text("Theme: Zino dark · Language: English (more coming)", 12, MUTED, false));

        LinearLayout detect = card("Game detection");
        detect.addView(text("The FPS arrow shows in every game Zino knows about. Add any game it misses, "
                + "or exclude apps that aren't games.", 13, MUTED, false));
        option(detect, "Detect games automatically (apps marked as games)", "auto_detect", true);
        detect.addView(button("Add games manually", false, v -> pickApps("Add games", "games_add")));
        detect.addView(button("Excluded apps", false, v -> pickApps("Never show the arrow in", "exclude")));

        LinearLayout notes = card("Notifications");
        option(notes, "Temperature warnings when the device gets hot", "n_temp", true);
        option(notes, "Battery low alert (15%) while playing", "n_batt", true);
        option(notes, "FPS drop alerts (under 30 FPS)", "n_fps", false);

        LinearLayout arrow = card("FPS arrow & overlay");
        arrow.addView(text("Green ▲ 60+ FPS · Yellow ▼ 45–59 · Red ▼ under 45 or too hot · Purple ▲ Boost on or 144+ FPS. "
                + "Tap it for FPS limit, Boost, Clarity mode and Low latency.", 13, MUTED, false));
        arrow.addView(row(new String[]{"Auto", "Always show", "Off"}, arrowModes, i -> setArrowMode(new String[]{"auto", "always", "off"}[i])));
        usageNote = text("", 12, WARN, false);
        usageNote.setPadding(0, dp(8), 0, 0);
        arrow.addView(usageNote);
        usageButton = button("Allow Usage access", false, v -> {
            open(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            toast("Find Zino in the list and turn it on");
        });
        arrow.addView(usageButton);
        arrow.addView(section("Arrow size"));
        arrow.addView(row(new String[]{"Small", "Medium", "Large"}, sizeChips, i -> {
            prefs.edit().putFloat("ov_size", new float[]{0.8f, 1f, 1.3f}[i]).apply();
            updateArrowModes();
            restartOverlay();
        }));
        TextView alphaLabel = section("Opacity");
        arrow.addView(alphaLabel);
        SeekBar alpha = new SeekBar(this);
        alpha.setMax(60); // 40–100 %
        alpha.setProgress(prefs.getInt("ov_alpha", 90) - 40);
        alpha.setProgressTintList(ColorStateList.valueOf(BRAND));
        alpha.setThumbTintList(ColorStateList.valueOf(BRAND));
        alpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) { prefs.edit().putInt("ov_alpha", v + 40).apply(); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { restartOverlay(); }
        });
        arrow.addView(alpha, spaced());
        CheckBox lock = check("Drag lock — keep the arrow where it is", prefs.getBoolean("ov_lock", false));
        lock.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("ov_lock", on).apply());
        arrow.addView(lock, spaced());
        arrow.addView(button("Reset arrow position", false, v -> {
            SharedPreferences.Editor ed = prefs.edit().remove("bubble_x").remove("bubble_y");
            for (String k : prefs.getAll().keySet()) if (k.startsWith("bx_") || k.startsWith("by_")) ed.remove(k);
            ed.apply();
            restartOverlay();
            toast("The arrow goes back to the top-left");
        }));

        LinearLayout gm = card("Game Mode options");
        gm.addView(text("Turned on while you play and put back afterwards. Per-game choices in Tune win over these.", 13, MUTED, false));
        option(gm, "Block calls, messages and pop-up notifications (game sound and alarms still play)", "gm_quiet", true);
        option(gm, "Pause account syncing in the background", "gm_sync", true);
        option(gm, "Boost — steady CPU and GPU speed, switched off automatically if it gets hot (Shizuku)", "gm_perf", true);
        option(gm, "Low latency — keep the screen at its top refresh rate (Shizuku)", "gm_latency", true);
        option(gm, "Lock brightness so the screen doesn't dim mid-game (Shizuku)", "gm_bright", true);
        gm.addView(text("Clear RAM in the arrow menu closes every background app when Shizuku is running. "
                + "Android doesn't let apps block navigation gestures or the pull-down shade without root.", 12, MUTED, false));

        LinearLayout sz = card("Shizuku connection");
        sz.addView(text("Shizuku gives Zino ADB-level access without root — needed for live FPS, Clarity modes, Boost, "
                + "Low latency and screenshots. Start it with Wireless debugging after every restart.", 13, MUTED, false));
        nfStatus = text("", 15, TEXT, true);
        nfStatus.setPadding(0, dp(10), 0, 0);
        sz.addView(nfStatus);
        nfConnect = button("Connect Shizuku", true, v -> connectShizuku());
        sz.addView(nfConnect);

        LinearLayout about = card("About");
        about.addView(text("Zino Game Space " + versionName() + "\nNo root · no ads · no tracking\n"
                + "Uses Shizuku by RikkaApps for no-root access.", 13, TEXT, false));
        about.addView(button("Privacy policy", false, v -> comingSoon("Privacy policy",
                "Zino doesn't collect, send or sell any data. There's no account, analytics or tracking. "
                        + "Game profiles and settings stay on this device. The ad blocker checks ad addresses on the device "
                        + "itself; your traffic isn't sent anywhere else. The ping test contacts only the servers you list.")));
    }

    private interface Pick { void at(int i); }

    /** A row of equal chips; tapping one calls pick with its index. */
    private View row(String[] names, Button[] keep, Pick pick) {
        LinearLayout r = new LinearLayout(this);
        for (int i = 0; i < names.length; i++) {
            int idx = i;
            Button b = chip(names[i], v -> pick.at(idx));
            keep[i] = b;
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1);
            p.rightMargin = dp(6);
            p.topMargin = dp(10);
            r.addView(b, p);
        }
        return r;
    }

    /** Pick apps for a comma-separated list in preferences (manual games, exclusions). */
    private void pickApps(String title, String key) {
        bg.execute(() -> {
            PackageManager pm = getPackageManager();
            TreeMap<String, String> apps = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo r : pm.queryIntentActivities(launcher, 0)) {
                String pkg = r.activityInfo.packageName;
                if (!pkg.equals(getPackageName())) apps.put(r.loadLabel(pm).toString(), pkg);
            }
            String[] labels = apps.keySet().toArray(new String[0]);
            String[] pkgs = apps.values().toArray(new String[0]);
            String current = "," + prefs.getString(key, "") + ",";
            boolean[] checked = new boolean[pkgs.length];
            for (int i = 0; i < pkgs.length; i++) checked[i] = current.contains("," + pkgs[i] + ",");
            ui.post(() -> new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMultiChoiceItems(labels, checked, (d, i, on) -> checked[i] = on)
                    .setPositiveButton("Save", (d, w) -> {
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < pkgs.length; i++) if (checked[i]) sb.append(sb.length() > 0 ? "," : "").append(pkgs[i]);
                        prefs.edit().putString(key, sb.toString()).apply();
                        restartOverlay(); // so the arrow picks up the new list
                        loadGames();
                    })
                    .setNegativeButton("Cancel", null)
                    .show());
        });
    }

    /** Applies overlay changes by restarting Game Mode if it's running. */
    private void restartOverlay() {
        if (!OverlayService.running) return;
        stopService(new Intent(this, OverlayService.class));
        ui.postDelayed(() -> OverlayService.start(this), 300);
    }

    private void setArrowMode(String key) {
        prefs.edit().putString("arrow", key).apply();
        if (key.equals("auto") && !OverlayService.hasUsageAccess(this)) {
            open(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            toast("Find Zino and allow Usage access — that's how it knows a game is open");
        }
        if (OverlayService.running) { // restart so the new mode takes effect
            stopService(new Intent(this, OverlayService.class));
            ui.postDelayed(() -> OverlayService.start(this), 300);
        }
        updateArrowModes();
        ui.postDelayed(this::updateGameMode, 600);
    }

    private void updateArrowModes() {
        String mode = OverlayService.arrowMode(this);
        String[] keys = {"auto", "always", "off"};
        for (int i = 0; i < 3; i++) chipOn(arrowModes[i], keys[i].equals(mode));
        float size = prefs.getFloat("ov_size", 1f);
        for (int i = 0; i < 3; i++) chipOn(sizeChips[i], Math.abs(new float[]{0.8f, 1f, 1.3f}[i] - size) < 0.01f);
        boolean usage = OverlayService.hasUsageAccess(this);
        usageNote.setText(usage ? "" : mode.equals("auto")
                ? "Auto-hide needs Usage access to see when a game opens. Until then the arrow always shows."
                : "Allow Usage access so the arrow can read FPS from the game itself.");
        usageNote.setVisibility(usage ? View.GONE : View.VISIBLE);
        usageButton.setVisibility(usage ? View.GONE : View.VISIBLE);
    }

    private void updateShizuku() {
        boolean ready = Shell.ready();
        if (ready) {
            nfStatus.setText("● Connected");
            nfStatus.setTextColor(GOOD);
        } else if (Shell.running()) {
            nfStatus.setText("Shizuku is running — tap Connect to allow Zino");
            nfStatus.setTextColor(WARN);
        } else {
            nfStatus.setText("Shizuku not running — install and start it first");
            nfStatus.setTextColor(WARN);
        }
        nfConnect.setVisibility(ready ? View.GONE : View.VISIBLE);
    }

    private void connectShizuku() {
        if (Shell.running()) { Shizuku.requestPermission(7); return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api"))); }
        catch (ActivityNotFoundException e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))); }
        toast("Install Shizuku, start it (Wireless debugging works without a PC), then come back and tap Connect");
    }

    private void comingSoon(String title, String body) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("OK", null).show();
    }

    private String versionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (PackageManager.NameNotFoundException e) { return ""; }
    }

    // ------------------------------------------------------------------ helpers

    private float[] refreshRates() {
        @SuppressWarnings("deprecation")
        Display d = getWindowManager().getDefaultDisplay();
        float max = d.getRefreshRate();
        for (Display.Mode m : d.getSupportedModes()) max = Math.max(max, m.getRefreshRate());
        return new float[]{d.getRefreshRate(), max};
    }

    private ActivityManager.MemoryInfo memInfo() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        getSystemService(ActivityManager.class).getMemoryInfo(mi);
        return mi;
    }

    private NotificationManager nm() { return getSystemService(NotificationManager.class); }
    private WifiManager wifi() { return (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE); }

    private void open(String action) {
        try { startActivity(new Intent(action)); }
        catch (ActivityNotFoundException e) { toast("This device doesn't have that settings screen"); }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private static String mb(long bytes) { return (bytes >> 20) + " MB"; }
    private static String ms(Double v) { return v == null ? "—" : String.format(Locale.US, "%.0fms", v); }
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    /** Rounded fill with an optional 1.5dp stroke (stroke 0 = none). */
    private GradientDrawable round(int color, float radiusDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (stroke != 0) d.setStroke(dp(1.5f), stroke);
        return d;
    }

    private void option(LinearLayout parent, String label, String key) { option(parent, label, key, true); }

    private void option(LinearLayout parent, String label, String key, boolean byDefault) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(TEXT);
        c.setButtonTintList(ColorStateList.valueOf(BRAND));
        c.setChecked(prefs.getBoolean(key, byDefault));
        c.setOnCheckedChangeListener((box, on) -> {
            prefs.edit().putBoolean(key, on).apply();
            if (key.equals("auto_detect")) restartOverlay();
            if (on && key.equals("gm_quiet") && !nm().isNotificationPolicyAccessGranted()) {
                toast("Allow Zino in this list so Game Mode can block calls and pop-ups");
                open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
            }
        });
        parent.addView(c, spaced());
    }

    private LinearLayout.LayoutParams spaced() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        return lp;
    }

    private LinearLayout card(String title) {
        LinearLayout c = vertical();
        c.setBackground(round(CARD, 20, 0));
        c.setPadding(dp(18), dp(16), dp(18), dp(18));
        LinearLayout.LayoutParams lp = spaced();
        lp.topMargin = dp(12);
        root.addView(c, lp);
        if (title == null) return c;
        TextView t = text(title.toUpperCase(Locale.ROOT), 12, BRAND, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(0, 0, 0, dp(8));
        c.addView(t);
        return c;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String label, boolean primary, View.OnClickListener onClick) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(ripple(round(primary ? BRAND : GHOST, 26, primary ? GLOW : 0)));
        b.setPadding(dp(18), 0, dp(18), 0);
        b.setMinHeight(dp(44));
        b.setMinimumHeight(dp(44));
        b.setStateListAnimator(null);
        b.setOnClickListener(onClick);
        Fx.press(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private void line(String label, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(5), 0, dp(5));
        TextView l = text(label, 14, MUTED, false);
        row.addView(l, new LinearLayout.LayoutParams(dp(112), LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(text(value, 14, color, true), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        statusBox.addView(row);
    }

    private void tip(String s) {
        TextView t = text(s, 13, WARN, false);
        t.setPadding(0, dp(2), 0, dp(6));
        statusBox.addView(t);
    }
}
