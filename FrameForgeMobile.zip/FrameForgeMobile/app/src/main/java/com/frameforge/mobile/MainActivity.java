package com.frameforge.mobile;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.VpnService;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    static final int BG = 0xFF0E1116, CARD = 0xFF161B22, TEXT = 0xFFE6EDF3, MUTED = 0xFF8B949E,
            ACCENT = 0xFF00E0A4, WARN = 0xFFF2C063, BAD = 0xFFFF6B6B, GHOST = 0xFF262D36;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final List<String> launcherPackages = new ArrayList<>();
    private SharedPreferences prefs;
    private LinearLayout root, statusBox, gameBox;
    private TextView pingOut, verdict;
    private EditText hosts;
    private Button runPing;
    private CheckBox dnd;
    private boolean onWifi;
    private TextView adStatus;
    private Button adToggle;
    private TextView nfStatus;
    private Button nfConnect;
    private final Shizuku.OnRequestPermissionResultListener nfGranted = (code, result) -> ui.post(this::updateNeuralFrame);
    private final Runnable adTick = new Runnable() {
        @Override public void run() { updateAdBlock(); ui.postDelayed(this, 1000); }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getPreferences(MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(28), dp(16), dp(28));
        scroll.addView(root);
        setContentView(scroll);

        root.addView(text("GbagboPR-Forge", 28, TEXT, true));
        TextView sub = text("Get your phone ready for smooth, lag-free games.", 14, MUTED, false);
        sub.setPadding(0, dp(4), 0, dp(18));
        root.addView(sub);

        // ---- phone status
        LinearLayout status = card("Phone status");
        statusBox = vertical();
        status.addView(statusBox);
        status.addView(button("Refresh", false, v -> refreshStatus()));

        // ---- ad blocker
        LinearLayout ads = card("Ad blocker");
        ads.addView(text("Blocks the ad networks games use (AdMob, Unity Ads, AppLovin, ironSource and more) "
                + "for every app on your phone. Android shows it as a VPN, but it all runs on your phone and "
                + "only filters ad addresses.", 13, MUTED, false));
        adStatus = text("", 15, TEXT, true);
        adStatus.setPadding(0, dp(10), 0, 0);
        ads.addView(adStatus);
        adToggle = button("", true, v -> toggleAdBlock());
        ads.addView(adToggle);
        ads.addView(text("Note: \"watch an ad for a reward\" won't work while it's on. If a game won't load, "
                + "turn the blocker off for that game. Set Private DNS to Off or Automatic in Settings, "
                + "or it can bypass the blocker.", 12, WARN, false));

        // ---- ping test
        LinearLayout ping = card("Ping test");
        ping.addView(text("Tests your router and internet servers, then tells you where lag comes from. "
                + "Add your game server's IP if you know it.", 13, MUTED, false));
        hosts = new EditText(this);
        hosts.setText(prefs.getString("hosts", "1.1.1.1, 8.8.8.8"));
        hosts.setTextColor(TEXT);
        hosts.setSingleLine();
        hosts.setBackground(rounded(BG));
        hosts.setPadding(dp(12), dp(10), dp(12), dp(10));
        ping.addView(hosts, spaced());
        runPing = button("Run ping test", true, v -> runPingTest());
        ping.addView(runPing);
        pingOut = text("", 13, TEXT, false);
        pingOut.setTypeface(Typeface.MONOSPACE);
        ping.addView(pingOut);
        verdict = text("", 14, TEXT, true);
        verdict.setPadding(0, dp(8), 0, 0);
        ping.addView(verdict);

        // ---- NeuralFrame render scale
        LinearLayout nf = card("NeuralFrame · render scale & FPS cap");
        nf.addView(text("Makes a game draw fewer pixels and Android stretches them back to full screen — "
                + "the same idea as DLSS Super Resolution. Lower scale = more FPS, cooler phone, longer battery, "
                + "slightly softer image. An FPS cap keeps frame times steady and saves battery. "
                + "Set it per game with Tune below. Needs Android 13+ and the free Shizuku app (no root).", 13, MUTED, false));
        nfStatus = text("", 15, TEXT, true);
        nfStatus.setPadding(0, dp(10), 0, 0);
        nf.addView(nfStatus);
        nfConnect = button("Connect Shizuku", true, v -> connectShizuku());
        nf.addView(nfConnect);
        nf.addView(text("Some games opt out, and phone makers' own game tools can override it. "
                + "It doesn't touch the game's files. The game restarts when you change its setting.", 12, WARN, false));
        Shizuku.addRequestPermissionResultListener(nfGranted);

        // ---- game boost
        LinearLayout games = card("Game boost");
        games.addView(text("Boost & Play clears apps Android has parked in the background, "
                + "then starts your game. Tune sets its render scale and FPS cap.", 13, MUTED, false));
        dnd = new CheckBox(this);
        dnd.setText("Silence notifications while playing (Do Not Disturb)");
        dnd.setTextColor(TEXT);
        dnd.setChecked(prefs.getBoolean("dnd", false) && nm().isNotificationPolicyAccessGranted());
        dnd.setOnCheckedChangeListener((box, on) -> {
            if (on && !nm().isNotificationPolicyAccessGranted()) {
                box.setChecked(false);
                toast("Allow GbagboPR-Forge in this list, then tick the box again");
                open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
            }
            prefs.edit().putBoolean("dnd", box.isChecked()).apply();
        });
        games.addView(dnd, spaced());
        gameBox = vertical();
        games.addView(gameBox);

        // ---- graphics
        buildGraphicsCard();

        TextView foot = text("GbagboPR-Forge can't change a game's own graphics settings — Android doesn't allow that "
                + "without root. It shows what your phone can do and gets it into the best state to play.", 12, MUTED, false);
        foot.setPadding(dp(4), dp(4), dp(4), 0);
        root.addView(foot);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
        loadGames();
        updateNeuralFrame();
        adTick.run();
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacks(adTick);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 1 && result == RESULT_OK) startService(new Intent(this, AdBlockService.class));
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeRequestPermissionResultListener(nfGranted);
        bg.shutdownNow();
    }

    // ------------------------------------------------------------------ status

    private void refreshStatus() {
        statusBox.removeAllViews();
        PowerManager pm = getSystemService(PowerManager.class);

        if (Build.VERSION.SDK_INT >= 29) {
            int t = pm.getCurrentThermalStatus();
            String[] names = {"Cool", "Slightly warm", "Warm — games may start slowing down",
                    "Hot — performance is being throttled", "Very hot — heavily throttled", "Critical", "Shutting down"};
            line("Temperature", names[Math.min(t, 6)], t == 0 ? ACCENT : t == 1 ? TEXT : t == 2 ? WARN : BAD);
        }

        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            float celsius = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int scale = Math.max(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
            int level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / scale;
            line("Battery", level + "% · " + celsius + "°C", celsius >= 42 ? BAD : celsius >= 38 ? WARN : TEXT);
        }

        if (pm.isPowerSaveMode()) {
            line("Battery saver", "ON — this slows games down", BAD);
            statusBox.addView(button("Turn off battery saver", true, v -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        } else {
            line("Battery saver", "Off", ACCENT);
        }

        ActivityManager.MemoryInfo mem = memInfo();
        line("Free memory", mb(mem.availMem) + " of " + mb(mem.totalMem), mem.lowMemory ? BAD : TEXT);

        float[] hz = refreshRates();
        line("Screen", "Up to " + Math.round(hz[1]) + " Hz (now " + Math.round(hz[0]) + " Hz)", hz[1] > 61 ? ACCENT : TEXT);

        ConnectivityManager cm = getSystemService(ConnectivityManager.class);
        NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
        onWifi = nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        if (onWifi) {
            WifiInfo wi = wifi().getConnectionInfo();
            int rssi = wi.getRssi(), f = wi.getFrequency();
            String band = f > 5900 ? "6 GHz" : f > 4900 ? "5 GHz" : "2.4 GHz";
            String quality = rssi >= -60 ? "strong" : rssi >= -70 ? "OK" : "weak";
            line("Wi-Fi", band + " · signal " + quality + " (" + rssi + " dBm) · " + wi.getLinkSpeed() + " Mbps",
                    rssi >= -60 ? ACCENT : rssi >= -70 ? WARN : BAD);
            if (band.equals("2.4 GHz")) tip("2.4 GHz Wi-Fi is crowded and slow. Join your router's 5 GHz network for steadier ping.");
            if (rssi < -70) tip("Weak Wi-Fi signal causes lag spikes. Move closer to the router or remove walls in between.");
        } else if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            line("Network", "Mobile data — usually higher, less stable ping than good Wi-Fi", WARN);
        } else {
            line("Network", "Offline", BAD);
        }

        int filter = nm().getCurrentInterruptionFilter();
        if (filter != NotificationManager.INTERRUPTION_FILTER_ALL && filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN) {
            line("Do Not Disturb", "On", ACCENT);
            if (nm().isNotificationPolicyAccessGranted()) {
                statusBox.addView(button("Turn off Do Not Disturb", false, v -> {
                    nm().setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
                    refreshStatus();
                }));
            }
        }
    }

    // ------------------------------------------------------------------ ad blocker

    private void toggleAdBlock() {
        if (AdBlockService.running) {
            startService(new Intent(this, AdBlockService.class).setAction(AdBlockService.ACTION_STOP));
            return;
        }
        Intent consent = VpnService.prepare(this); // Android asks once before a VPN can start
        if (consent != null) startActivityForResult(consent, 1);
        else startService(new Intent(this, AdBlockService.class));
    }

    private void updateAdBlock() {
        boolean on = AdBlockService.running;
        adStatus.setText(on ? "● On · " + AdBlockService.blocked.get() + " ad requests blocked" : "Off");
        adStatus.setTextColor(on ? ACCENT : MUTED);
        adToggle.setText(on ? "Turn off ad blocker" : "Turn on ad blocker");
    }

    // ------------------------------------------------------------------ ping

    private void runPingTest() {
        String raw = hosts.getText().toString();
        prefs.edit().putString("hosts", raw).apply();
        List<String[]> targets = new ArrayList<>(); // {host, label}
        String gw = onWifi ? gateway() : null;
        if (gw != null) targets.add(new String[]{gw, "Router"});
        for (String h : raw.trim().split("[,;\\s]+")) if (!h.isEmpty()) targets.add(new String[]{h, h});
        if (targets.isEmpty()) { toast("Add a server to test"); return; }

        runPing.setEnabled(false);
        verdict.setText("");
        pingOut.setText("Testing…");
        bg.execute(() -> {
            StringBuilder sb = new StringBuilder(String.format(Locale.US, "%-15s %7s %7s %5s%n", "", "avg", "jitter", "loss"));
            Stats router = null;
            List<Stats> internet = new ArrayList<>();
            for (String[] t : targets) {
                String label = t[1].length() > 15 ? t[1].substring(0, 14) + "…" : t[1];
                String head = sb.toString();
                ui.post(() -> pingOut.setText(head + "Testing " + label + "…"));
                Stats s = measure(t[0], 20);
                if (t[1].equals("Router")) router = s; else internet.add(s);
                sb.append(String.format(Locale.US, "%-15s %7s %7s %4.0f%%%n", label, ms(s.avg), ms(s.jitter), s.loss));
            }
            int d = Stats.diagnose(router, internet);
            String table = sb.toString();
            ui.post(() -> {
                pingOut.setText(table);
                verdict.setText(verdictText(d));
                verdict.setTextColor(d == Stats.HEALTHY ? ACCENT : BAD);
                runPing.setEnabled(true);
            });
        });
    }

    private String verdictText(int d) {
        switch (d) {
            case Stats.HOME_NETWORK:
                return "Your Wi-Fi is the problem — even your own router is unstable. Move closer to it, "
                        + "use the 5 GHz network, restart the router, or stop other downloads on your network.";
            case Stats.ISP:
                return "Your Wi-Fi is fine, but the connection is unstable after your router — that's your internet "
                        + "provider. Try a quieter time of day, or contact them with these results.";
            case Stats.NO_REPLY:
                return "None of the servers replied. Check your connection, or try different server addresses.";
            default:
                return "Connection looks healthy for gaming: stable with no real packet loss.";
        }
    }

    /** ICMP ping via the system ping tool; falls back to TCP connect time where that isn't allowed. */
    private Stats measure(String host, int count) {
        try {
            Process p = new ProcessBuilder("/system/bin/ping", "-c", String.valueOf(count), "-i", "0.2",
                    "-W", "1", "-w", "30", host).redirectErrorStream(true).start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                for (String l; (l = r.readLine()) != null; ) out.append(l).append('\n');
            }
            p.waitFor();
            int sent = Stats.parseSent(out.toString());
            if (sent > 0) return new Stats(Stats.parseTimes(out.toString()), sent);
        } catch (Exception ignored) { }
        // shortcut: TCP connect time reads a little higher than real ping; only used on ROMs that block ICMP
        List<Double> times = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            long start = System.nanoTime();
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, 443), 1000);
                times.add((System.nanoTime() - start) / 1e6);
            } catch (Exception ignored) { }
            try { Thread.sleep(200); } catch (InterruptedException e) { break; }
        }
        return new Stats(times, count);
    }

    private String gateway() {
        DhcpInfo d = wifi().getDhcpInfo();
        int ip = d == null ? 0 : d.gateway;
        if (ip == 0) return null;
        return (ip & 0xff) + "." + (ip >> 8 & 0xff) + "." + (ip >> 16 & 0xff) + "." + (ip >> 24 & 0xff);
    }

    // ------------------------------------------------------------------ games

    private void loadGames() {
        bg.execute(() -> {
            PackageManager pm = getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            TreeMap<String, String> games = new TreeMap<>(String.CASE_INSENSITIVE_ORDER), apps = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            List<String> pkgs = new ArrayList<>();
            for (ResolveInfo r : pm.queryIntentActivities(launcher, 0)) {
                ApplicationInfo a = r.activityInfo.applicationInfo;
                if (a.packageName.equals(getPackageName()) || pkgs.contains(a.packageName)) continue;
                pkgs.add(a.packageName);
                @SuppressWarnings("deprecation")
                boolean game = a.category == ApplicationInfo.CATEGORY_GAME || (a.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                (game ? games : apps).put(r.loadLabel(pm).toString(), a.packageName);
            }
            ui.post(() -> {
                launcherPackages.clear();
                launcherPackages.addAll(pkgs);
                showGames(games.isEmpty() ? apps : games, games.isEmpty());
            });
        });
    }

    private void showGames(TreeMap<String, String> list, boolean noGamesFound) {
        gameBox.removeAllViews();
        if (noGamesFound) gameBox.addView(text("No games detected — showing all apps.", 13, WARN, false));
        for (String label : list.keySet()) {
            String pkg = list.get(label);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));
            LinearLayout names = vertical();
            names.addView(text(label, 15, TEXT, true));
            names.addView(text(GameTuning.describe(prefs.getString("nf_" + pkg, null)), 12, MUTED, false));
            row.addView(names, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            Button tune = button("Tune", false, v -> tune(pkg, label));
            ((LinearLayout.LayoutParams) tune.getLayoutParams()).topMargin = 0;
            ((LinearLayout.LayoutParams) tune.getLayoutParams()).rightMargin = dp(8);
            row.addView(tune);
            Button play = button("Boost & Play", true, v -> boostAndPlay(pkg, label));
            ((LinearLayout.LayoutParams) play.getLayoutParams()).topMargin = 0;
            row.addView(play);
            gameBox.addView(row);
        }
    }

    private void boostAndPlay(String pkg, String label) {
        boolean silence = dnd.isChecked() && nm().isNotificationPolicyAccessGranted();
        bg.execute(() -> {
            ActivityManager am = getSystemService(ActivityManager.class);
            long before = memInfo().availMem;
            for (String p : launcherPackages) if (!p.equals(pkg)) am.killBackgroundProcesses(p);
            long freed = Math.max(0, memInfo().availMem - before);
            ui.post(() -> {
                if (silence) nm().setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
                toast((freed > 50L << 20 ? "Freed " + mb(freed) + " · " : "") + "Starting " + label);
                Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch != null) startActivity(launch);
                else toast("Couldn't start " + label);
            });
        });
    }

    // ------------------------------------------------------------------ NeuralFrame

    private void updateNeuralFrame() {
        boolean ready = Shell.ready();
        if (Build.VERSION.SDK_INT < 33) {
            nfStatus.setText("Needs Android 13 or newer");
            nfStatus.setTextColor(BAD);
        } else if (ready) {
            nfStatus.setText("● Connected — tap Tune on a game");
            nfStatus.setTextColor(ACCENT);
        } else if (Shell.running()) {
            nfStatus.setText("Shizuku is running — tap Connect to allow GbagboPR-Forge");
            nfStatus.setTextColor(WARN);
        } else {
            nfStatus.setText("Shizuku not running — install and start it first");
            nfStatus.setTextColor(WARN);
        }
        nfConnect.setVisibility(ready || Build.VERSION.SDK_INT < 33 ? View.GONE : View.VISIBLE);
    }

    private void connectShizuku() {
        if (Shell.running()) { Shizuku.requestPermission(7); return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api"))); }
        catch (ActivityNotFoundException e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))); }
        toast("Install Shizuku, start it (Wireless debugging works without a PC), then come back and tap Connect");
    }

    private void tune(String pkg, String label) {
        if (Build.VERSION.SDK_INT < 33) { toast("Render scale and FPS cap need Android 13 or newer"); return; }
        new AlertDialog.Builder(this)
                .setTitle(label + " · render resolution")
                .setItems(GameTuning.SCALE_NAMES, (d, i) -> pickFps(pkg, label, GameTuning.SCALES[i]))
                .show();
    }

    private void pickFps(String pkg, String label, float scale) {
        int max = Math.round(refreshRates()[1]);
        List<Integer> fps = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for (int f : GameTuning.FPS) {
            if (f > max + 1) continue; // no point capping above what the screen shows
            fps.add(f);
            names.add(f == 0 ? "No FPS cap" : f + " FPS cap");
        }
        new AlertDialog.Builder(this)
                .setTitle(label + " · frame rate")
                .setItems(names.toArray(new String[0]), (d, i) -> applyTuning(pkg, label, scale, fps.get(i)))
                .show();
    }

    private void applyTuning(String pkg, String label, float scale, int fps) {
        String[] cmds;
        try { cmds = GameTuning.commands(pkg, scale, fps); }
        catch (IllegalArgumentException e) { toast("Can't tune " + label); return; }
        if (!Shell.ready()) {
            StringBuilder adb = new StringBuilder();
            for (String c : cmds) adb.append("adb shell ").append(c).append('\n');
            getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("GbagboPR-Forge", adb.toString()));
            toast("Shizuku isn't connected, so nothing changed. The ADB commands are copied — run them from a PC, or connect Shizuku.");
            return;
        }
        bg.execute(() -> {
            try {
                for (String c : cmds) Shell.run(c);
                prefs.edit().putString("nf_" + pkg, GameTuning.save(scale, fps)).apply();
                ui.post(() -> { toast(label + ": " + GameTuning.describe(GameTuning.save(scale, fps)) + ". Start the game to use it."); loadGames(); });
            } catch (Exception e) {
                ui.post(() -> toast("Couldn't apply: " + e.getMessage()));
            }
        });
    }

    // ------------------------------------------------------------------ graphics

    private void buildGraphicsCard() {
        LinearLayout g = card("Better graphics & FPS");
        int max = Math.round(refreshRates()[1]);
        StringBuilder tips = new StringBuilder();
        if (max > 61) {
            tips.append("• Your screen can run at ").append(max).append(" Hz. Set it to the highest option in Display settings, ")
                .append("then pick the matching frame rate in your game (e.g. 90 or 120 FPS).\n\n");
        }
        tips.append("• In the game's own settings, pick the highest frame rate first, then raise graphics only while it stays smooth. ")
            .append("Steady FPS looks better than high detail that stutters.\n\n")
            .append("• If Temperature above says Warm or Hot, drop graphics one step — a hot phone throttles and loses FPS. ")
            .append("Remove thick cases and avoid playing while charging.\n\n")
            .append("• Sharper edges in older games: Developer options › \"Force 4x MSAA\". Uses more battery and only affects ")
            .append("OpenGL games — turn it off if anything glitches.\n\n")
            .append("• Also turn on your phone's built-in game mode: Game Booster (Samsung), Game Dashboard (Pixel), Game Turbo (Xiaomi).");
        g.addView(text(tips.toString(), 13.5f, TEXT, false));
        g.addView(button("Open Display settings", true, v -> open(Settings.ACTION_DISPLAY_SETTINGS)));
        g.addView(button("Open Developer options", false, v -> {
            if (Settings.Global.getInt(getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 0) {
                toast("Turn on Developer options first: Settings › About phone › tap Build number 7 times");
            } else {
                open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
            }
        }));
    }

    // ------------------------------------------------------------------ helpers

    private float[] refreshRates() {
        @SuppressWarnings("deprecation")
        Display d = getWindowManager().getDefaultDisplay();
        float max = d.getRefreshRate();
        for (Display.Mode m : d.getSupportedModes()) max = Math.max(max, m.getRefreshRate());
        return new float[]{d.getRefreshRate(), max};
    }

    private ActivityManager.MemoryInfo memInfo() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        getSystemService(ActivityManager.class).getMemoryInfo(mi);
        return mi;
    }

    private NotificationManager nm() { return getSystemService(NotificationManager.class); }
    private WifiManager wifi() { return (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE); }

    private void open(String action) {
        try { startActivity(new Intent(action)); }
        catch (ActivityNotFoundException e) { toast("This phone doesn't have that settings screen"); }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private static String mb(long bytes) { return (bytes >> 20) + " MB"; }
    private static String ms(Double v) { return v == null ? "—" : String.format(Locale.US, "%.0fms", v); }
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private GradientDrawable rounded(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(12));
        return d;
    }

    private LinearLayout.LayoutParams spaced() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        return lp;
    }

    private LinearLayout card(String title) {
        LinearLayout c = vertical();
        c.setBackground(rounded(CARD));
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        LinearLayout.LayoutParams lp = spaced();
        lp.topMargin = 0;
        lp.bottomMargin = dp(12);
        root.addView(c, lp);
        TextView t = text(title.toUpperCase(Locale.ROOT), 12, MUTED, true);
        t.setLetterSpacing(0.08f);
        t.setPadding(0, 0, 0, dp(8));
        c.addView(t);
        return c;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String label, boolean primary, View.OnClickListener onClick) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(primary ? BG : TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(rounded(primary ? ACCENT : GHOST));
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setMinHeight(dp(44));
        b.setOnClickListener(onClick);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private void line(String label, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(5), 0, dp(5));
        TextView l = text(label, 14, MUTED, false);
        row.addView(l, new LinearLayout.LayoutParams(dp(112), LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(text(value, 14, color, true), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        statusBox.addView(row);
    }

    private void tip(String s) {
        TextView t = text(s, 13, WARN, false);
        t.setPadding(0, dp(2), 0, dp(6));
        statusBox.addView(t);
    }
}
