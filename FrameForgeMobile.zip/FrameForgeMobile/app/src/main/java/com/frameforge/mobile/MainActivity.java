package com.frameforge.mobile;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.VpnService;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    // Zino theme: near-black surfaces, Zino red with a soft glow, green/yellow/red for status
    static final int BG = 0xFF060708, CARD = 0xFF101215, BORDER = 0xFF22262D, TEXT = 0xFFF2F4F7, MUTED = 0xFF8A93A0,
            BRAND = 0xFFE60012, GLOW = 0x66E60012, GOOD = 0xFF22E39A, WARN = 0xFFFFC24B, BAD = 0xFFFF4D5E, GHOST = 0xFF1A1D22;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private LinearLayout root; // the page cards are added to while building
    private final LinearLayout[] pages = new LinearLayout[4];
    private final TextView[] tabs = new TextView[4];
    private ScrollView scroll;
    private int page;

    private LinearLayout statusBox, gameBox, recentBox;
    private TextView pingOut, verdict, adStatus, nfStatus, gameModeNote, usageNote;
    private TextView fpsStat, tempStat, batteryStat, hzStat, pilotStat, gmStat, greeting;
    private TextView fpsSub, tempSub, batterySub, hzSub, pilotSub, gmSub;
    private EditText hosts;
    private Button runPing, adToggle, nfConnect, gameMode, usageButton;
    private Button chipBoost, chipAds, chipLatency, chipPilot;
    private final Button[] arrowModes = new Button[3], sizeChips = new Button[3];
    private boolean onWifi;

    private final Shizuku.OnRequestPermissionResultListener nfGranted = (code, result) -> ui.post(this::updateShizuku);
    private final Runnable liveTick = new Runnable() {
        @Override public void run() { updateLive(); ui.postDelayed(this, 1000); }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getPreferences(MODE_PRIVATE); // file "MainActivity", shared with OverlayService

        LinearLayout frame = vertical();
        frame.setBackgroundColor(BG);
        scroll = new ScrollView(this);
        LinearLayout content = vertical();
        content.setPadding(dp(16), dp(20), dp(16), dp(24));
        scroll.addView(content);
        frame.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        frame.addView(navBar());
        setContentView(frame);

        for (int i = 0; i < pages.length; i++) { pages[i] = vertical(); content.addView(pages[i]); }
        root = pages[0]; buildHome();
        root = pages[1]; buildGames();
        root = pages[2]; buildTools();
        root = pages[3]; buildSettings();
        Shizuku.addRequestPermissionResultListener(nfGranted);
        showPage(prefs.getInt("page", 0));
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
        loadGames();
        showRecent();
        updateShizuku();
        updateArrowModes();
        liveTick.run();
        ui.postDelayed(this::updateGameMode, 300); // the service flips its flag a moment after starting
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacks(liveTick);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 1 && result == RESULT_OK) startService(new Intent(this, AdBlockService.class));
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeRequestPermissionResultListener(nfGranted);
        bg.shutdownNow();
    }

    // ------------------------------------------------------------------ navigation

    private LinearLayout navBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(0xFF0B0C0F);
        bar.setPadding(dp(8), dp(6), dp(8), dp(10));
        String[] names = {"⌂\nHome", "🎮\nGames", "🛠\nTools", "⚙\nSettings"};
        for (int i = 0; i < tabs.length; i++) {
            int idx = i;
            TextView t = text(names[i], 12, MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(6), 0, dp(6));
            t.setOnClickListener(v -> showPage(idx));
            tabs[i] = t;
            bar.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        }
        return bar;
    }

    private void showPage(int p) {
        page = p;
        prefs.edit().putInt("page", p).apply();
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == p ? View.VISIBLE : View.GONE);
            tabs[i].setTextColor(i == p ? BRAND : MUTED);
        }
        pages[p].setAlpha(0f);
        pages[p].animate().alpha(1f).setDuration(180).start();
        scroll.scrollTo(0, 0);
    }

    // ------------------------------------------------------------------ Home

    private void buildHome() {
        root.addView(logoBar());
        greeting = text("", 24, TEXT, true);
        greeting.setPadding(0, dp(16), 0, 0);
        root.addView(greeting);
        TextView acct = text("Playing without account · Sign in ›", 13, MUTED, false);
        acct.setPadding(0, dp(4), 0, dp(14));
        acct.setOnClickListener(v -> showPage(3));
        root.addView(acct);

        // hero: Game Mode
        LinearLayout hero = vertical();
        GradientDrawable heroBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF5C0008, 0xFF1A0306, CARD});
        heroBg.setCornerRadius(dp(22));
        heroBg.setStroke(dp(1.5f), GLOW);
        hero.setBackground(heroBg);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.addView(text("Game Mode", 20, TEXT, true));
        gameModeNote = text("", 13, 0xFFE8C4C8, false);
        gameModeNote.setPadding(0, dp(6), 0, 0);
        hero.addView(gameModeNote);
        gameMode = button("", true, v -> toggleGameMode());
        gameMode.setMinHeight(dp(56));
        gameMode.setTextSize(16);
        gameMode.setBackground(round(BRAND, 28, 0x99FF5A6A));
        gameMode.setLayoutParams(spaced());
        ((LinearLayout.LayoutParams) gameMode.getLayoutParams()).topMargin = dp(16);
        hero.addView(gameMode);
        LinearLayout.LayoutParams heroLp = spaced();
        heroLp.topMargin = 0;
        heroLp.bottomMargin = dp(14);
        root.addView(hero, heroLp);

        // live dashboard
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        fpsStat = statTile(grid, "Current FPS");
        fpsSub = sub(fpsStat);
        tempStat = statTile(grid, "Device temp");
        tempSub = sub(tempStat);
        batteryStat = statTile(grid, "Battery");
        batterySub = sub(batteryStat);
        hzStat = statTile(grid, "Refresh rate");
        hzSub = sub(hzStat);
        pilotStat = statTile(grid, "Smart Auto Pilot");
        pilotSub = sub(pilotStat);
        gmStat = statTile(grid, "Game Mode");
        gmSub = sub(gmStat);
        root.addView(grid, spaced());

        // quick actions
        LinearLayout quick = card("Quick actions");
        GridLayout chips = new GridLayout(this);
        chips.setColumnCount(2);
        chipBoost = chip("🟣 Boost", v -> setQuick("gm_perf", OverlayService.ACTION_BOOST));
        chipAds = chip("🛡 Ad blocker", v -> toggleAdBlock());
        chipLatency = chip("⏱ Low latency", v -> setQuick("gm_latency", OverlayService.ACTION_LATENCY));
        chipPilot = chip("🤖 Auto Pilot", v -> { prefs.edit().putBoolean("autopilot", !prefs.getBoolean("autopilot", true)).apply(); updateLive(); });
        for (Button b : new Button[]{chipBoost, chipAds, chipLatency, chipPilot}) {
            GridLayout.LayoutParams p = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            p.width = 0;
            p.height = dp(46);
            p.setMargins(0, dp(4), dp(8), dp(4));
            chips.addView(b, p);
        }
        quick.addView(chips);
        quick.addView(text("Boost holds CPU/GPU speed steady. Low latency keeps the screen at its top refresh rate. "
                + "Auto Pilot switches them for you from heat, battery and FPS. Boost and Low latency need Shizuku.", 12, MUTED, false));

        LinearLayout recent = card("Recently played");
        recentBox = vertical();
        recent.addView(recentBox);
    }

    /** Z logo + ZINO GAME SPACE, top-left of every page. */
    private View logoBar() {
        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.zino_logo);
        logo.setBackground(round(0xFF0B0C0F, 14, GLOW));
        brand.addView(logo, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout words = vertical();
        words.setPadding(dp(12), 0, 0, 0);
        TextView z = text("ZINO", 22, TEXT, true);
        z.setLetterSpacing(0.22f);
        TextView gs = text("GAME SPACE", 10, BRAND, true);
        gs.setLetterSpacing(0.35f);
        words.addView(z);
        words.addView(gs);
        brand.addView(words);
        return brand;
    }

    /** A small second line under a dashboard number. */
    private TextView sub(TextView value) {
        TextView t = text("", 12, MUTED, false);
        ((LinearLayout) value.getParent()).addView(t);
        return t;
    }

    private TextView statTile(GridLayout grid, String label) {
        LinearLayout tile = vertical();
        tile.setBackground(round(CARD, 16, BORDER));
        tile.setPadding(dp(14), dp(12), dp(14), dp(12));
        tile.addView(text(label, 12, MUTED, false));
        TextView value = text("—", 22, TEXT, true);
        tile.addView(value);
        GridLayout.LayoutParams p = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        p.width = 0;
        p.setMargins(0, 0, dp(8), dp(8));
        grid.addView(tile, p);
        return value;
    }

    private Button chip(String label, View.OnClickListener click) {
        Button b = button(label, false, click);
        b.setTextSize(12);
        b.setPadding(dp(6), 0, dp(6), 0);
        return b;
    }

    /** Live dashboard, greeting and chip states — once a second while the app is open. */
    private void updateLive() {
        int fps = OverlayService.liveFps;
        fpsStat.setText(fps < 0 ? "—" : fps + "");
        fpsStat.setTextColor(fps < 0 ? MUTED : fps >= 60 ? GOOD : fps >= 45 ? WARN : BAD);
        fpsSub.setText(fps < 0 ? "Shows while you play" : fps >= 60 ? "Smooth" : fps >= 45 ? "Moderate" : "Stuttering");

        int thermal = Build.VERSION.SDK_INT >= 29 ? getSystemService(PowerManager.class).getCurrentThermalStatus() : 0;
        boolean warm = false;
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            float c = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int lvl = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / Math.max(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
            boolean charging = bat.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
            boolean hot = c >= 42 || thermal >= 3;
            warm = hot || c >= 38 || thermal == 2;
            tempStat.setText(String.format(Locale.US, "%.1f°C", c));
            tempStat.setTextColor(hot ? BAD : warm ? WARN : GOOD);
            tempSub.setText(hot ? "🔴 Hot" : warm ? "🟡 Warm" : "🟢 Cool");
            batteryStat.setText(lvl + "%");
            batteryStat.setTextColor(lvl <= 15 ? BAD : TEXT);
            BatteryManager bm = getSystemService(BatteryManager.class);
            int left = GameTuning.minutesLeft(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER),
                    bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW), charging);
            batterySub.setText(charging ? "Charging" : left < 0 ? "Working out time left…" : "≈ " + GameTuning.duration(left) + " left");
        }
        float[] hz = refreshRates();
        hzStat.setText(Math.round(hz[0]) + " Hz");
        hzStat.setTextColor(hz[0] >= hz[1] - 1 ? GOOD : TEXT);
        hzSub.setText("Max " + Math.round(hz[1]) + " Hz");

        boolean pilot = prefs.getBoolean("autopilot", true);
        pilotStat.setText(pilot ? "On" : "Off");
        pilotStat.setTextColor(pilot ? 0xFFB36BFF : MUTED);
        String note = OverlayService.pilotNote;
        pilotSub.setText(!pilot ? "Turn on in Quick actions" : note != null ? note : "Starts when you play");

        boolean on = OverlayService.running;
        gmStat.setText(on ? "On" : "Off");
        gmStat.setTextColor(on ? GOOD : MUTED);
        gmSub.setText("FPS arrow: " + (OverlayService.arrowMode(this).equals("auto") ? "Auto" : OverlayService.arrowMode(this).equals("always") ? "Always" : "Off"));

        greeting.setText(warm ? "Device warm" : on && OverlayService.liveGame != null ? "Game Mode active" : "Ready to play");
        greeting.setTextColor(warm ? WARN : TEXT);

        chipOn(chipBoost, prefs.getBoolean("gm_perf", true));
        chipOn(chipLatency, prefs.getBoolean("gm_latency", true));
        chipOn(chipAds, AdBlockService.running);
        chipOn(chipPilot, pilot);
        if (adStatus != null) {
            boolean ads = AdBlockService.running;
            adStatus.setText(ads ? "● On · " + AdBlockService.blocked.get() + " ad requests blocked" : "Off");
            adStatus.setTextColor(ads ? GOOD : MUTED);
            adToggle.setText(ads ? "Turn off ad blocker" : "Turn on ad blocker");
        }
    }

    private void chipOn(Button b, boolean on) {
        b.setBackground(round(on ? 0xFF2A070B : GHOST, 23, on ? BRAND : 0));
        b.setTextColor(on ? TEXT : MUTED);
    }

    /** Boost / Low latency chips: saved for every Game Mode, and switched live if Game Mode is running. */
    private void setQuick(String key, String action) {
        boolean on = !prefs.getBoolean(key, true);
        prefs.edit().putBoolean(key, on).apply();
        if (OverlayService.running) startService(new Intent(this, OverlayService.class).setAction(action).putExtra("on", on));
        else if (on && !Shell.ready()) toast("Needs Shizuku — start it, then connect in Settings");
        updateLive();
    }

    private void showRecent() {
        recentBox.removeAllViews();
        PackageManager pm = getPackageManager();
        int shown = 0;
        for (String pkg : prefs.getString("recent", "").split(",")) {
            if (pkg.isEmpty() || shown >= 4) continue;
            try {
                ApplicationInfo a = pm.getApplicationInfo(pkg, 0);
                recentBox.addView(gameRow(pkg, pm.getApplicationLabel(a).toString(), pm.getApplicationIcon(a), false));
                shown++;
            } catch (PackageManager.NameNotFoundException ignored) { } // uninstalled since
        }
        if (shown == 0) recentBox.addView(text("Games you play show up here. Open the Games tab to start one.", 13, MUTED, false));
    }

    // ------------------------------------------------------------------ Games

    private void buildGames() {
        root.addView(pageTitle("Games", "Every game gets its own profile. Tune it once, then Boost & Play."));

        LinearLayout ib = card("Clarity modes · Image Boost");
        ib.addView(text("Lower modes make the game draw fewer pixels for more FPS, less heat and longer battery. "
                + "Ultra Quality keeps full resolution. Uses Android's Game Mode (Android 13+, Shizuku).", 13, MUTED, false));
        for (int i = 0; i < GameTuning.BOOST_NAMES.length; i++) {
            LinearLayout r = vertical();
            r.setPadding(0, dp(10), 0, 0);
            r.addView(text(GameTuning.BOOST_NAMES[i], 15, TEXT, true));
            r.addView(text(GameTuning.BOOST_INFO[i], 12, MUTED, false));
            ib.addView(r);
        }

        LinearLayout games = card("Your games");
        CheckBox autoStart = new CheckBox(this);
        autoStart.setText("Start Game Mode when I tap Boost & Play");
        autoStart.setTextColor(TEXT);
        autoStart.setButtonTintList(ColorStateList.valueOf(BRAND));
        autoStart.setChecked(prefs.getBoolean("bubble", true));
        autoStart.setOnCheckedChangeListener((box, on) -> prefs.edit().putBoolean("bubble", on).apply());
        games.addView(autoStart);
        games.addView(text("Missing a game? Add it in Settings › Game detection.", 12, MUTED, false));
        gameBox = vertical();
        games.addView(gameBox);
    }

    private void loadGames() {
        bg.execute(() -> {
            PackageManager pm = getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            TreeMap<String, ApplicationInfo> games = new TreeMap<>(String.CASE_INSENSITIVE_ORDER), apps = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            List<String> pkgs = new ArrayList<>();
            for (ResolveInfo r : pm.queryIntentActivities(launcher, 0)) {
                ApplicationInfo a = r.activityInfo.applicationInfo;
                if (a.packageName.equals(getPackageName()) || pkgs.contains(a.packageName)) continue;
                pkgs.add(a.packageName);
                @SuppressWarnings("deprecation")
                boolean game = a.category == ApplicationInfo.CATEGORY_GAME || (a.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
                (game ? games : apps).put(r.loadLabel(pm).toString(), a);
            }
            ui.post(() -> showGames(games.isEmpty() ? apps : games, games.isEmpty()));
        });
    }

    private void showGames(TreeMap<String, ApplicationInfo> list, boolean noGamesFound) {
        gameBox.removeAllViews();
        if (noGamesFound) gameBox.addView(text("No games detected — showing all apps.", 13, WARN, false));
        PackageManager pm = getPackageManager();
        for (String label : list.keySet()) {
            ApplicationInfo a = list.get(label);
            gameBox.addView(gameRow(a.packageName, label, pm.getApplicationIcon(a), true));
        }
    }

    /** One game card: icon, name, profile, last played, and its buttons. */
    private View gameRow(String pkg, String label, Drawable icon, boolean full) {
        LinearLayout box = vertical();
        box.setPadding(0, dp(10), 0, dp(10));
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(icon);
        top.addView(iv, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout names = vertical();
        names.setPadding(dp(12), 0, 0, 0);
        names.addView(text(label, 15, TEXT, true));
        String saved = prefs.getString("nf_" + pkg, null);
        names.addView(text(saved == null ? "Profile: Default" : "Profile: Custom · " + GameTuning.describe(saved), 12, MUTED, false));
        names.addView(text(GameTuning.ago(prefs.getLong("lp_" + pkg, 0), System.currentTimeMillis()), 12, MUTED, false));
        top.addView(names, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        if (!full) {
            Button play = button("▶ Boost & Play", true, v -> boostAndPlay(pkg, label));
            ((LinearLayout.LayoutParams) play.getLayoutParams()).topMargin = 0;
            top.addView(play);
        }
        box.addView(top);
        if (full) {
            LinearLayout actions = new LinearLayout(this);
            actions.setPadding(dp(56), 0, 0, 0);
            Button tune = button("Tune", false, v -> tune(pkg, label));
            ((LinearLayout.LayoutParams) tune.getLayoutParams()).rightMargin = dp(8);
            Button play = button("▶ Boost & Play", true, v -> boostAndPlay(pkg, label));
            actions.addView(tune);
            actions.addView(play);
            box.addView(actions);
        }
        return box;
    }

    private void boostAndPlay(String pkg, String label) {
        bg.execute(() -> {
            long freed = OverlayService.clearBackground(this, pkg);
            String saved = prefs.getString("nf_" + pkg, null);
            boolean canTune = Shell.ready() && Build.VERSION.SDK_INT >= 33 && GameTuning.validPackage(pkg);
            if (saved == null && prefs.contains("def_nf") && canTune) {
                // no profile yet: use the profile saved as default
                String def = prefs.getString("def_nf", null);
                float s = GameTuning.savedScale(def);
                if (s > 0) try { for (String c : GameTuning.commands(pkg, s, GameTuning.savedFps(def))) Shell.run(c); } catch (Exception ignored) { }
                else saved = def; // default is Auto: handled below
            }
            if (saved != null && GameTuning.savedScale(saved) < 0 && canTune) {
                // Auto: pick the mode from how hot the tablet is right now (the game isn't running yet)
                int preset = GameTuning.autoPreset(Build.VERSION.SDK_INT >= 29 ? getSystemService(PowerManager.class).getCurrentThermalStatus() : 0);
                try { for (String c : GameTuning.commands(pkg, GameTuning.BOOST_SCALES[preset], GameTuning.savedFps(saved))) Shell.run(c); }
                catch (Exception ignored) { }
                String name = GameTuning.BOOST_NAMES[preset];
                ui.post(() -> toast("Auto picked " + name));
            }
            if (Shell.ready()) try { Shell.run(GameTuning.clarityCommands(prefs.getBoolean("msaa", false), 1f)[0]); } catch (Exception ignored) { }
            OverlayService.addRecent(this, pkg);
            ui.post(() -> {
                if (prefs.getBoolean("bubble", true) && !OverlayService.running && Settings.canDrawOverlays(this)) startGameMode();
                toast((freed > 50L << 20 ? "Freed " + mb(freed) + " · " : "") + "Starting " + label);
                Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch != null) startActivity(launch);
                else toast("Couldn't start " + label);
            });
        });
    }

    /** Tune: the full per-game panel. */
    private void tune(String pkg, String label) {
        String saved = prefs.getString("nf_" + pkg, prefs.getString("def_nf", null));
        int p0 = saved == null ? 0 : GameTuning.presetFor(GameTuning.savedScale(saved));
        int[] mode = {p0 < 0 ? 0 : p0};
        int[] cap = {GameTuning.savedFps(saved)};
        AlertDialog[] dlg = new AlertDialog[1];

        LinearLayout p = vertical();
        p.setPadding(dp(20), dp(4), dp(20), dp(8));
        Button clear = button("⭐ Clearest Graphics", true, v -> { dlg[0].dismiss(); clearestGraphics(pkg, label); });
        clear.setLayoutParams(spaced());
        p.addView(clear);
        p.addView(text("Full resolution plus the Clarity panel (edge smoothing, colour vibrance).", 12, MUTED, false));

        p.addView(section("Clarity mode"));
        TextView info = text(GameTuning.BOOST_INFO[mode[0]], 12, MUTED, false);
        GridLayout modes = new GridLayout(this);
        modes.setColumnCount(2);
        Button[] modeChips = new Button[GameTuning.BOOST_NAMES.length];
        for (int i = 0; i < modeChips.length; i++) {
            int idx = i;
            modeChips[i] = chip(GameTuning.BOOST_NAMES[i], v -> {
                mode[0] = idx;
                for (int j = 0; j < modeChips.length; j++) chipOn(modeChips[j], j == idx);
                info.setText(GameTuning.BOOST_INFO[idx]);
            });
            chipOn(modeChips[i], i == mode[0]);
            modes.addView(modeChips[i], gridCell());
        }
        p.addView(modes);
        p.addView(info);

        p.addView(section("NSS · NFRU · NSSD"));
        p.addView(text("Arm neural graphics — not available here. Games must be built with them, on a GPU with Arm "
                + "neural accelerators. See Tools › AI Graphics Engine.", 12, WARN, false));

        p.addView(section("FPS limit"));
        GridLayout caps = new GridLayout(this);
        caps.setColumnCount(4);
        int max = Math.round(refreshRates()[1]);
        List<Integer> options = new ArrayList<>();
        for (int f : GameTuning.FPS) if (f > 0 && f <= max + 1) options.add(f);
        options.add(0); // Max = no limit
        Button[] capChips = new Button[options.size()];
        for (int i = 0; i < capChips.length; i++) {
            int f = options.get(i), idx = i;
            capChips[i] = chip(f == 0 ? "Max" : String.valueOf(f), v -> {
                cap[0] = f;
                for (int j = 0; j < capChips.length; j++) chipOn(capChips[j], j == idx);
            });
            chipOn(capChips[i], f == cap[0]);
            caps.addView(capChips[i], gridCell());
        }
        p.addView(caps);

        p.addView(section("While playing this game"));
        CheckBox bright = check("Lock brightness", prefs.getBoolean("gm_bright_" + pkg, prefs.getBoolean("gm_bright", true)));
        CheckBox ads = check("Ad blocker on", prefs.getBoolean("ads_" + pkg, false));
        CheckBox latency = check("Low latency (top refresh rate)", prefs.getBoolean("gm_latency_" + pkg, prefs.getBoolean("gm_latency", true)));
        p.addView(bright);
        p.addView(ads);
        p.addView(latency);
        ScrollView sv = new ScrollView(this);
        sv.addView(p);

        dlg[0] = new AlertDialog.Builder(this)
                .setTitle("Tune · " + label)
                .setView(sv)
                .setPositiveButton("Save", (d, w) -> saveTune(pkg, label, mode[0], cap[0], bright.isChecked(), ads.isChecked(), latency.isChecked(), false))
                .setNeutralButton("Save as default", (d, w) -> saveTune(pkg, label, mode[0], cap[0], bright.isChecked(), ads.isChecked(), latency.isChecked(), true))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveTune(String pkg, String label, int mode, int fps, boolean bright, boolean ads, boolean latency, boolean asDefault) {
        SharedPreferences.Editor ed = prefs.edit().putBoolean("gm_bright_" + pkg, bright).putBoolean("ads_" + pkg, ads)
                .putBoolean("gm_latency_" + pkg, latency);
        if (asDefault) ed.putString("def_nf", GameTuning.save(GameTuning.BOOST_SCALES[mode], fps))
                .putBoolean("gm_bright", bright).putBoolean("gm_latency", latency);
        ed.apply();
        if (ads && VpnService.prepare(this) != null) toast("Turn the ad blocker on once in Tools so Android allows it for games");
        if (Build.VERSION.SDK_INT < 33) { toast("Saved. Clarity mode and FPS limit need Android 13 or newer."); loadGames(); return; }
        applyTuning(pkg, label, GameTuning.BOOST_SCALES[mode], fps);
        if (asDefault) toast("Saved as the default for games without their own profile");
    }

    private TextView section(String title) {
        TextView t = text(title.toUpperCase(Locale.ROOT), 11, BRAND, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(0, dp(18), 0, dp(4));
        return t;
    }

    private GridLayout.LayoutParams gridCell() {
        GridLayout.LayoutParams p = new GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        p.width = 0;
        p.height = dp(42);
        p.setMargins(0, dp(3), dp(6), dp(3));
        return p;
    }

    private CheckBox check(String label, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(TEXT);
        c.setButtonTintList(ColorStateList.valueOf(BRAND));
        c.setChecked(on);
        return c;
    }

    private void applyTuning(String pkg, String label, float scale, int fps) {
        if (scale < 0) { // Auto is applied each time you tap Play
            prefs.edit().putString("nf_" + pkg, GameTuning.save(scale, fps)).apply();
            toast(label + ": Auto — Zino picks the mode each time you tap Play");
            loadGames();
            return;
        }
        String[] cmds;
        try { cmds = GameTuning.commands(pkg, scale, fps); }
        catch (IllegalArgumentException e) { toast("Can't tune " + label); return; }
        if (!Shell.ready()) {
            StringBuilder adb = new StringBuilder();
            for (String c : cmds) adb.append("adb shell ").append(c).append('\n');
            getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("Zino", adb.toString()));
            toast("Shizuku isn't connected, so nothing changed. The ADB commands are copied — run them from a PC, or connect Shizuku.");
            return;
        }
        bg.execute(() -> {
            try {
                for (String c : cmds) Shell.run(c);
                prefs.edit().putString("nf_" + pkg, GameTuning.save(scale, fps)).apply();
                ui.post(() -> { toast(label + ": " + GameTuning.describe(GameTuning.save(scale, fps)) + ". Start the game to use it."); loadGames(); });
            } catch (Exception e) {
                ui.post(() -> toast("Couldn't apply: " + e.getMessage()));
            }
        });
    }

    /** ✨ Clearest Graphics: back to native resolution, then the Clarity panel. */
    private void clearestGraphics(String pkg, String label) {
        int fps = GameTuning.savedFps(prefs.getString("nf_" + pkg, null));
        if (Shell.ready() && Build.VERSION.SDK_INT >= 33) applyTuning(pkg, label, 1f, fps);
        else prefs.edit().putString("nf_" + pkg, GameTuning.save(1f, fps)).apply();
        clarityPanel(pkg, label);
    }

    private void clarityPanel(String pkg, String label) {
        String saved = prefs.getString("cl_" + pkg, null);
        float vib0 = saved == null ? 1f + prefs.getInt("vib_default", 0) / 100f : Float.parseFloat(saved.split(",")[1]);
        LinearLayout p = vertical();
        p.setPadding(dp(22), dp(8), dp(22), 0);
        p.addView(text("✓ Native resolution — the game draws every pixel", 14, GOOD, true));

        CheckBox edge = new CheckBox(this);
        edge.setText("Edge smoothing (4x MSAA) — smoother edges in OpenGL games, from the next launch. Applies to all games.");
        edge.setTextColor(TEXT);
        edge.setButtonTintList(ColorStateList.valueOf(BRAND));
        edge.setChecked(prefs.getBoolean("msaa", false));
        p.addView(edge, spaced());

        TextView vibLabel = text("", 14, TEXT, true);
        vibLabel.setPadding(0, dp(14), 0, 0);
        p.addView(vibLabel);
        SeekBar vib = new SeekBar(this);
        vib.setMax(60); // 1.00 – 1.60
        vib.setProgress(Math.round((vib0 - 1f) * 100));
        vib.setProgressTintList(ColorStateList.valueOf(BRAND));
        vib.setThumbTintList(ColorStateList.valueOf(BRAND));
        vibLabel.setText("Colour vibrance: +" + vib.getProgress() + "%");
        vib.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) { vibLabel.setText("Colour vibrance: +" + v + "%"); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        p.addView(vib, spaced());
        p.addView(text("Richer colours while this game is open (whole screen, Shizuku).", 12, MUTED, false));

        Button upscale = button("Image Boost: " + GameTuning.describe(prefs.getString("nf_" + pkg, null)) + " — change", false, v -> tune(pkg, label));
        upscale.setTextSize(12);
        p.addView(upscale);
        p.addView(text("\nOn your Red Magic: press the Magic Key › GameSpace › this game, and turn on Frame Rate Boost "
                + "if it's offered — it upscales supported games on the tablet's own chips.\n\n"
                + "Sharpness and texture detail come from the game's own Graphics settings — set them to the highest "
                + "there. Android doesn't let other apps sharpen a game's picture.", 12, MUTED, false));
        ScrollView sv = new ScrollView(this);
        sv.addView(p);

        new AlertDialog.Builder(this)
                .setTitle("✨ " + label + " · Clarity")
                .setView(sv)
                .setPositiveButton("Save", (d, w) -> saveClarity(pkg, edge.isChecked(), 1f + vib.getProgress() / 100f))
                .setNeutralButton("Reset to default", (d, w) -> saveClarity(pkg, false, 1f))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveClarity(String pkg, boolean edge, float vibrance) {
        prefs.edit().putBoolean("msaa", edge).putString("cl_" + pkg, GameTuning.saveClarity(edge, vibrance)).apply();
        if (!Shell.ready()) { toast("Saved. Start Shizuku so Zino can apply it."); return; }
        bg.execute(() -> {
            try { Shell.run(GameTuning.clarityCommands(edge, 1f)[0]); } catch (Exception ignored) { }
            ui.post(() -> toast("Clarity saved — it applies when you play this game"));
        });
    }

    // ------------------------------------------------------------------ Game Mode

    private void toggleGameMode() {
        if (OverlayService.running) OverlayService.stop(this);
        else startGameMode();
        ui.postDelayed(this::updateGameMode, 300);
    }

    private void startGameMode() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 2); // for the Stop button in notifications
        }
        if (OverlayService.arrowMode(this).equals("auto") && !OverlayService.hasUsageAccess(this)) {
            toast("Tip: allow Usage access in Settings so the arrow appears only in games");
        }
        OverlayService.start(this);
    }

    private void updateGameMode() {
        boolean on = OverlayService.running;
        gameMode.setText(on ? "■  Stop Game Mode" : "▶  Start Game Mode");
        String mode = OverlayService.arrowMode(this);
        gameModeNote.setText(!on ? "Turn it on once — the FPS arrow appears in your games and the Game Mode options run while you play."
                : mode.equals("auto") && OverlayService.hasUsageAccess(this) ? "On · the FPS arrow appears when you open a game."
                : mode.equals("off") ? "On · FPS arrow is off (change it in Settings)."
                : "On · the FPS arrow is on screen. Drag it anywhere, tap it for the quick menu.");
        if (!Shell.ready() && !on) gameModeNote.append(" Start Shizuku for live FPS.");
    }

    // ------------------------------------------------------------------ Tools

    private void buildTools() {
        root.addView(pageTitle("Tools", "Graphics, performance, battery and network — each explained in one line."));

        // AI Graphics Engine: honest explainer
        LinearLayout ai = card("✨ AI Graphics Engine");
        ai.addView(text("Arm's neural graphics bring DLSS-style AI to phones and tablets. They run only in games built "
                + "with them, on GPUs that have Arm neural accelerators (Mali G2-Ultra NX, announced September 2026). "
                + "No app can switch them on for other games.", 13, MUTED, false));
        aiTech(ai, "🖼 Neural Super Sampling (NSS)", "Rebuilds a sharp, smooth-edged picture from a lower-resolution render.",
                "Best for: any game · FPS: higher · Battery: lower use");
        aiTech(ai, "⚡ Neural Frame Rate Upscaling (NFRU)", "Adds AI frames between real ones, so 60 rendered FPS looks much smoother.",
                "Best for: fast action · FPS shown: up to 2x · Battery: lower use, slight extra delay");
        aiTech(ai, "🌟 NSS + Denoising (NSSD)", "Upscaling plus clean-up of grainy ray-traced shadows, reflections and lighting.",
                "Best for: open worlds, night scenes · FPS: higher than plain ray tracing");
        TextView dev = text("This device: " + gpuName() + " — not supported", 14, WARN, true);
        dev.setPadding(0, dp(12), 0, dp(4));
        ai.addView(dev);
        ai.addView(text("What works on your device instead: Clarity modes (Image Boost) per game, ⭐ Clearest Graphics, "
                + "Smart Auto Pilot, and on Red Magic, Frame Rate Boost in GameSpace (Magic Key) — real frame insertion on the tablet's own chips.", 12, MUTED, false));

        // Clearest Graphics defaults
        LinearLayout cg = card("⭐ Clearest Graphics defaults");
        cg.addView(text("Used for every game that has no Clarity settings of its own.", 13, MUTED, false));
        CheckBox edge = check("Edge smoothing (4x MSAA) — smoother edges in OpenGL games, from the next launch", prefs.getBoolean("msaa", false));
        edge.setOnCheckedChangeListener((b, on) -> {
            prefs.edit().putBoolean("msaa", on).apply();
            if (Shell.ready()) bg.execute(() -> { try { Shell.run(GameTuning.clarityCommands(on, 1f)[0]); } catch (Exception ignored) { } });
        });
        cg.addView(edge, spaced());
        TextView vibLabel = text("", 14, TEXT, true);
        vibLabel.setPadding(0, dp(12), 0, 0);
        cg.addView(vibLabel);
        SeekBar vib = new SeekBar(this);
        vib.setMax(60);
        vib.setProgress(prefs.getInt("vib_default", 0));
        vib.setProgressTintList(ColorStateList.valueOf(BRAND));
        vib.setThumbTintList(ColorStateList.valueOf(BRAND));
        vibLabel.setText("Default colour vibrance: +" + vib.getProgress() + "%");
        vib.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) {
                vibLabel.setText("Default colour vibrance: +" + v + "%");
                prefs.edit().putInt("vib_default", v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        cg.addView(vib, spaced());

        // Performance, display and battery
        LinearLayout perf = card("Performance · Display · Battery");
        CheckBox pilot = check("🤖 Smart Auto Pilot — watches heat, battery and FPS while you play and switches Boost, "
                + "Low latency and the next launch's Clarity mode for you", prefs.getBoolean("autopilot", true));
        pilot.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("autopilot", on).apply());
        perf.addView(pilot);
        perf.addView(text("\n• Boost: steady CPU/GPU speed — more FPS, more heat. Turned off automatically when hot.\n"
                + "• Low latency: locks the screen at its top refresh rate — quicker response, a little more battery.\n"
                + "• Clarity modes: Ultra Quality uses the most battery, Ultra Performance the least.\n"
                + "• Battery saver slows games down — keep it off while playing.", 13, TEXT, false));
        perf.addView(button("Battery settings", false, v -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        perf.addView(button("Display & refresh rate", false, v -> open(Settings.ACTION_DISPLAY_SETTINGS)));

        LinearLayout status = card("Phone status");
        statusBox = vertical();
        status.addView(statusBox);
        status.addView(button("Refresh", false, v -> refreshStatus()));

        LinearLayout ads = card("Ad blocker");
        ads.addView(text("Blocks the ad networks games use (AdMob, Unity Ads, AppLovin, ironSource and more) "
                + "for every app on your phone. Android shows it as a VPN, but it all runs on your phone and "
                + "only filters ad addresses.", 13, MUTED, false));
        adStatus = text("", 15, TEXT, true);
        adStatus.setPadding(0, dp(10), 0, 0);
        ads.addView(adStatus);
        adToggle = button("", true, v -> toggleAdBlock());
        ads.addView(adToggle);
        ads.addView(text("Note: \"watch an ad for a reward\" won't work while it's on. If a game won't load, "
                + "turn the blocker off for that game. Set Private DNS to Off or Automatic in Settings, "
                + "or it can bypass the blocker.", 12, WARN, false));

        LinearLayout ping = card("Ping test");
        ping.addView(text("Tests your router and internet servers, then tells you where lag comes from. "
                + "Add your game server's IP if you know it.", 13, MUTED, false));
        hosts = new EditText(this);
        hosts.setText(prefs.getString("hosts", "1.1.1.1, 8.8.8.8"));
        hosts.setTextColor(TEXT);
        hosts.setSingleLine();
        hosts.setBackground(round(BG, 12, BORDER));
        hosts.setPadding(dp(12), dp(10), dp(12), dp(10));
        ping.addView(hosts, spaced());
        runPing = button("Run ping test", true, v -> runPingTest());
        ping.addView(runPing);
        pingOut = text("", 13, TEXT, false);
        pingOut.setTypeface(Typeface.MONOSPACE);
        ping.addView(pingOut);
        verdict = text("", 14, TEXT, true);
        verdict.setPadding(0, dp(8), 0, 0);
        ping.addView(verdict);

        buildGraphicsCard();
    }

    private void aiTech(LinearLayout parent, String name, String what, String facts) {
        LinearLayout r = vertical();
        r.setPadding(0, dp(12), 0, 0);
        r.addView(text(name, 15, TEXT, true));
        r.addView(text(what, 13, TEXT, false));
        r.addView(text(facts, 12, MUTED, false));
        parent.addView(r);
    }

    /** Best guess at the GPU family from the chip maker. */
    private String gpuName() {
        String maker = Build.VERSION.SDK_INT >= 31 ? Build.SOC_MANUFACTURER : Build.HARDWARE;
        String m = maker == null ? "" : maker.toLowerCase(Locale.ROOT);
        if (m.contains("qti") || m.contains("qualcomm") || m.contains("qcom")) return "Qualcomm Snapdragon (Adreno GPU)";
        if (m.contains("mediatek") || m.startsWith("mt")) return "MediaTek (Arm Mali / Immortalis GPU)";
        if (m.contains("google")) return "Google Tensor";
        if (m.contains("samsung") || m.contains("exynos")) return "Samsung Exynos";
        return maker == null || maker.isEmpty() ? "unknown chip" : maker;
    }

    private void refreshStatus() {
        statusBox.removeAllViews();
        PowerManager pm = getSystemService(PowerManager.class);
        if (Build.VERSION.SDK_INT >= 29) {
            int t = pm.getCurrentThermalStatus();
            String[] names = {"Cool", "Slightly warm", "Warm — games may start slowing down",
                    "Hot — performance is being throttled", "Very hot — heavily throttled", "Critical", "Shutting down"};
            line("Temperature", names[Math.min(t, 6)], t == 0 ? GOOD : t == 1 ? TEXT : t == 2 ? WARN : BAD);
        }
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            float celsius = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int scale = Math.max(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
            int level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / scale;
            line("Battery", level + "% · " + celsius + "°C", celsius >= 42 ? BAD : celsius >= 38 ? WARN : TEXT);
        }
        if (pm.isPowerSaveMode()) {
            line("Battery saver", "ON — this slows games down", BAD);
            statusBox.addView(button("Turn off battery saver", true, v -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        } else {
            line("Battery saver", "Off", GOOD);
        }
        ActivityManager.MemoryInfo mem = memInfo();
        line("Free memory", mb(mem.availMem) + " of " + mb(mem.totalMem), mem.lowMemory ? BAD : TEXT);
        float[] hz = refreshRates();
        line("Screen", "Up to " + Math.round(hz[1]) + " Hz (now " + Math.round(hz[0]) + " Hz)", hz[1] > 61 ? GOOD : TEXT);

        ConnectivityManager cm = getSystemService(ConnectivityManager.class);
        NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
        onWifi = nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        if (onWifi) {
            WifiInfo wi = wifi().getConnectionInfo();
            int rssi = wi.getRssi(), f = wi.getFrequency();
            String band = f > 5900 ? "6 GHz" : f > 4900 ? "5 GHz" : "2.4 GHz";
            String quality = rssi >= -60 ? "strong" : rssi >= -70 ? "OK" : "weak";
            line("Wi-Fi", band + " · signal " + quality + " (" + rssi + " dBm) · " + wi.getLinkSpeed() + " Mbps",
                    rssi >= -60 ? GOOD : rssi >= -70 ? WARN : BAD);
            if (band.equals("2.4 GHz")) tip("2.4 GHz Wi-Fi is crowded and slow. Join your router's 5 GHz network for steadier ping.");
            if (rssi < -70) tip("Weak Wi-Fi signal causes lag spikes. Move closer to the router or remove walls in between.");
        } else if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            line("Network", "Mobile data — usually higher, less stable ping than good Wi-Fi", WARN);
        } else {
            line("Network", "Offline", BAD);
        }
        int filter = nm().getCurrentInterruptionFilter();
        if (filter != NotificationManager.INTERRUPTION_FILTER_ALL && filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN) {
            line("Do Not Disturb", "On", GOOD);
            if (nm().isNotificationPolicyAccessGranted()) {
                statusBox.addView(button("Turn off Do Not Disturb", false, v -> {
                    nm().setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
                    refreshStatus();
                }));
            }
        }
    }

    private void toggleAdBlock() {
        if (AdBlockService.running) {
            startService(new Intent(this, AdBlockService.class).setAction(AdBlockService.ACTION_STOP));
            return;
        }
        Intent consent = VpnService.prepare(this); // Android asks once before a VPN can start
        if (consent != null) startActivityForResult(consent, 1);
        else startService(new Intent(this, AdBlockService.class));
    }

    private void runPingTest() {
        String raw = hosts.getText().toString();
        prefs.edit().putString("hosts", raw).apply();
        List<String[]> targets = new ArrayList<>(); // {host, label}
        String gw = onWifi ? gateway() : null;
        if (gw != null) targets.add(new String[]{gw, "Router"});
        for (String h : raw.trim().split("[,;\\s]+")) if (!h.isEmpty()) targets.add(new String[]{h, h});
        if (targets.isEmpty()) { toast("Add a server to test"); return; }

        runPing.setEnabled(false);
        verdict.setText("");
        pingOut.setText("Testing…");
        bg.execute(() -> {
            StringBuilder sb = new StringBuilder(String.format(Locale.US, "%-15s %7s %7s %5s%n", "", "avg", "jitter", "loss"));
            Stats router = null;
            List<Stats> internet = new ArrayList<>();
            for (String[] t : targets) {
                String label = t[1].length() > 15 ? t[1].substring(0, 14) + "…" : t[1];
                String head = sb.toString();
                ui.post(() -> pingOut.setText(head + "Testing " + label + "…"));
                Stats s = measure(t[0], 20);
                if (t[1].equals("Router")) router = s; else internet.add(s);
                sb.append(String.format(Locale.US, "%-15s %7s %7s %4.0f%%%n", label, ms(s.avg), ms(s.jitter), s.loss));
            }
            int d = Stats.diagnose(router, internet);
            String table = sb.toString();
            ui.post(() -> {
                pingOut.setText(table);
                verdict.setText(verdictText(d));
                verdict.setTextColor(d == Stats.HEALTHY ? GOOD : BAD);
                runPing.setEnabled(true);
            });
        });
    }

    private String verdictText(int d) {
        switch (d) {
            case Stats.HOME_NETWORK:
                return "Your Wi-Fi is the problem — even your own router is unstable. Move closer to it, "
                        + "use the 5 GHz network, restart the router, or stop other downloads on your network.";
            case Stats.ISP:
                return "Your Wi-Fi is fine, but the connection is unstable after your router — that's your internet "
                        + "provider. Try a quieter time of day, or contact them with these results.";
            case Stats.NO_REPLY:
                return "None of the servers replied. Check your connection, or try different server addresses.";
            default:
                return "Connection looks healthy for gaming: stable with no real packet loss.";
        }
    }

    /** ICMP ping via the system ping tool; falls back to TCP connect time where that isn't allowed. */
    private Stats measure(String host, int count) {
        try {
            java.lang.Process p = new ProcessBuilder("/system/bin/ping", "-c", String.valueOf(count), "-i", "0.2",
                    "-W", "1", "-w", "30", host).redirectErrorStream(true).start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                for (String l; (l = r.readLine()) != null; ) out.append(l).append('\n');
            }
            p.waitFor();
            int sent = Stats.parseSent(out.toString());
            if (sent > 0) return new Stats(Stats.parseTimes(out.toString()), sent);
        } catch (Exception ignored) { }
        // shortcut: TCP connect time reads a little higher than real ping; only used on ROMs that block ICMP
        List<Double> times = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            long start = System.nanoTime();
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, 443), 1000);
                times.add((System.nanoTime() - start) / 1e6);
            } catch (Exception ignored) { }
            try { Thread.sleep(200); } catch (InterruptedException e) { break; }
        }
        return new Stats(times, count);
    }

    private String gateway() {
        DhcpInfo d = wifi().getDhcpInfo();
        int ip = d == null ? 0 : d.gateway;
        if (ip == 0) return null;
        return (ip & 0xff) + "." + (ip >> 8 & 0xff) + "." + (ip >> 16 & 0xff) + "." + (ip >> 24 & 0xff);
    }

    private void buildGraphicsCard() {
        LinearLayout g = card("Better graphics & FPS");
        int max = Math.round(refreshRates()[1]);
        StringBuilder tips = new StringBuilder();
        if (max > 61) {
            tips.append("• Your screen can run at ").append(max).append(" Hz. Set it to the highest option in Display settings, ")
                .append("then pick the matching frame rate in your game (e.g. 90 or 120 FPS).\n\n");
        }
        tips.append("• Clearest picture: tap ✨ Clearest Graphics on the game, and set the game's own Graphics to the highest it allows.\n\n")
            .append("• In the game's own settings, pick the highest frame rate first, then raise graphics only while it stays smooth. ")
            .append("Steady FPS looks better than high detail that stutters.\n\n")
            .append("• If Temperature says Warm or Hot, drop graphics one step — a hot device throttles and loses FPS. ")
            .append("Remove thick cases and avoid playing while charging.\n\n")
            .append("• Red Magic: press the Magic Key for GameSpace — Rise Mode for full power, and Frame Rate Boost where offered.\n\n")
            .append("• Other phones: turn on the built-in game mode — Game Booster (Samsung), Game Dashboard (Pixel), Game Turbo (Xiaomi).");
        g.addView(text(tips.toString(), 13.5f, TEXT, false));
        g.addView(button("Open Display settings", true, v -> open(Settings.ACTION_DISPLAY_SETTINGS)));
        g.addView(button("Open Developer options", false, v -> {
            if (Settings.Global.getInt(getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 0) {
                toast("Turn on Developer options first: Settings › About phone › tap Build number 7 times");
            } else {
                open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS);
            }
        }));
    }

    // ------------------------------------------------------------------ Settings

    private void buildSettings() {
        root.addView(pageTitle("Settings", "General, game detection, alerts, overlay, account."));

        LinearLayout general = card("General");
        option(general, "Start Game Mode automatically after the tablet restarts", "boot_start", true);
        general.addView(text("Theme: Zino dark · Language: English (more coming)", 12, MUTED, false));

        LinearLayout detect = card("Game detection");
        detect.addView(text("The FPS arrow shows in every game Zino knows about. Add any game it misses, "
                + "or exclude apps that aren't games.", 13, MUTED, false));
        option(detect, "Detect games automatically (apps marked as games)", "auto_detect", true);
        detect.addView(button("Add games manually", false, v -> pickApps("Add games", "games_add")));
        detect.addView(button("Excluded apps", false, v -> pickApps("Never show the arrow in", "exclude")));

        LinearLayout notes = card("Notifications");
        option(notes, "Temperature warnings when the device gets hot", "n_temp", true);
        option(notes, "Battery low alert (15%) while playing", "n_batt", true);
        option(notes, "FPS drop alerts (under 30 FPS)", "n_fps", false);

        LinearLayout arrow = card("FPS arrow & overlay");
        arrow.addView(text("Green ▲ 60+ FPS · Yellow ▼ 45–59 · Red ▼ under 45 or too hot · Purple ▲ Boost on or 144+ FPS. "
                + "Tap it for FPS limit, Boost, Clarity mode and Low latency.", 13, MUTED, false));
        arrow.addView(row(new String[]{"Auto", "Always show", "Off"}, arrowModes, i -> setArrowMode(new String[]{"auto", "always", "off"}[i])));
        usageNote = text("", 12, WARN, false);
        usageNote.setPadding(0, dp(8), 0, 0);
        arrow.addView(usageNote);
        usageButton = button("Allow Usage access", false, v -> {
            open(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            toast("Find Zino in the list and turn it on");
        });
        arrow.addView(usageButton);
        arrow.addView(section("Arrow size"));
        arrow.addView(row(new String[]{"Small", "Medium", "Large"}, sizeChips, i -> {
            prefs.edit().putFloat("ov_size", new float[]{0.8f, 1f, 1.3f}[i]).apply();
            updateArrowModes();
            restartOverlay();
        }));
        TextView alphaLabel = section("Opacity");
        arrow.addView(alphaLabel);
        SeekBar alpha = new SeekBar(this);
        alpha.setMax(60); // 40–100 %
        alpha.setProgress(prefs.getInt("ov_alpha", 90) - 40);
        alpha.setProgressTintList(ColorStateList.valueOf(BRAND));
        alpha.setThumbTintList(ColorStateList.valueOf(BRAND));
        alpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) { prefs.edit().putInt("ov_alpha", v + 40).apply(); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { restartOverlay(); }
        });
        arrow.addView(alpha, spaced());
        CheckBox lock = check("Drag lock — keep the arrow where it is", prefs.getBoolean("ov_lock", false));
        lock.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean("ov_lock", on).apply());
        arrow.addView(lock, spaced());
        arrow.addView(button("Reset arrow position", false, v -> {
            SharedPreferences.Editor ed = prefs.edit().remove("bubble_x").remove("bubble_y");
            for (String k : prefs.getAll().keySet()) if (k.startsWith("bx_") || k.startsWith("by_")) ed.remove(k);
            ed.apply();
            restartOverlay();
            toast("The arrow goes back to the top-left");
        }));

        LinearLayout gm = card("Game Mode options");
        gm.addView(text("Turned on while you play and put back afterwards. Per-game choices in Tune win over these.", 13, MUTED, false));
        option(gm, "Block calls, messages and pop-up notifications (game sound and alarms still play)", "gm_quiet", true);
        option(gm, "Pause account syncing in the background", "gm_sync", true);
        option(gm, "Boost — steady CPU and GPU speed, switched off automatically if it gets hot (Shizuku)", "gm_perf", true);
        option(gm, "Low latency — keep the screen at its top refresh rate (Shizuku)", "gm_latency", true);
        option(gm, "Lock brightness so the screen doesn't dim mid-game (Shizuku)", "gm_bright", true);
        gm.addView(text("Clear RAM in the arrow menu closes every background app when Shizuku is running. "
                + "Android doesn't let apps block navigation gestures or the pull-down shade without root.", 12, MUTED, false));

        LinearLayout sz = card("Shizuku connection");
        sz.addView(text("Shizuku gives Zino ADB-level access without root — needed for live FPS, Clarity modes, Boost, "
                + "Low latency and screenshots. Start it with Wireless debugging after every restart.", 13, MUTED, false));
        nfStatus = text("", 15, TEXT, true);
        nfStatus.setPadding(0, dp(10), 0, 0);
        sz.addView(nfStatus);
        nfConnect = button("Connect Shizuku", true, v -> connectShizuku());
        sz.addView(nfConnect);

        LinearLayout acct = card("Account");
        acct.addView(text("✓ Continue without account", 15, GOOD, true));
        acct.addView(text("Zino works fully without signing in. Your profiles stay on this device.", 12, MUTED, false));
        acct.addView(button("Sign in with Google or email", false, v -> comingSoon("Sign in",
                "Cloud saves and synced game profiles need Zino's online account service, which isn't live yet. "
                        + "Until then everything is saved on this device.")));
        acct.addView(button("Zino Pro", true, v -> comingSoon("Zino Pro",
                "Zino Pro isn't available yet. Everything in this version is free.")));

        LinearLayout about = card("About");
        about.addView(text("Zino Game Space " + versionName() + "\nNo root · no ads · no tracking\n"
                + "Uses Shizuku by RikkaApps for no-root access.", 13, TEXT, false));
        about.addView(button("Privacy policy", false, v -> comingSoon("Privacy policy",
                "Zino doesn't collect, send or sell any data. There's no account, analytics or tracking. "
                        + "Game profiles and settings stay on this device. The ad blocker checks ad addresses on the device "
                        + "itself; your traffic isn't sent anywhere else. The ping test contacts only the servers you list.")));
    }

    private interface Pick { void at(int i); }

    /** A row of equal chips; tapping one calls pick with its index. */
    private View row(String[] names, Button[] keep, Pick pick) {
        LinearLayout r = new LinearLayout(this);
        for (int i = 0; i < names.length; i++) {
            int idx = i;
            Button b = chip(names[i], v -> pick.at(idx));
            keep[i] = b;
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1);
            p.rightMargin = dp(6);
            p.topMargin = dp(10);
            r.addView(b, p);
        }
        return r;
    }

    /** Pick apps for a comma-separated list in preferences (manual games, exclusions). */
    private void pickApps(String title, String key) {
        bg.execute(() -> {
            PackageManager pm = getPackageManager();
            TreeMap<String, String> apps = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo r : pm.queryIntentActivities(launcher, 0)) {
                String pkg = r.activityInfo.packageName;
                if (!pkg.equals(getPackageName())) apps.put(r.loadLabel(pm).toString(), pkg);
            }
            String[] labels = apps.keySet().toArray(new String[0]);
            String[] pkgs = apps.values().toArray(new String[0]);
            String current = "," + prefs.getString(key, "") + ",";
            boolean[] checked = new boolean[pkgs.length];
            for (int i = 0; i < pkgs.length; i++) checked[i] = current.contains("," + pkgs[i] + ",");
            ui.post(() -> new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMultiChoiceItems(labels, checked, (d, i, on) -> checked[i] = on)
                    .setPositiveButton("Save", (d, w) -> {
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < pkgs.length; i++) if (checked[i]) sb.append(sb.length() > 0 ? "," : "").append(pkgs[i]);
                        prefs.edit().putString(key, sb.toString()).apply();
                        restartOverlay(); // so the arrow picks up the new list
                        loadGames();
                    })
                    .setNegativeButton("Cancel", null)
                    .show());
        });
    }

    /** Applies overlay changes by restarting Game Mode if it's running. */
    private void restartOverlay() {
        if (!OverlayService.running) return;
        stopService(new Intent(this, OverlayService.class));
        ui.postDelayed(() -> OverlayService.start(this), 300);
    }

    private void setArrowMode(String key) {
        prefs.edit().putString("arrow", key).apply();
        if (key.equals("auto") && !OverlayService.hasUsageAccess(this)) {
            open(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            toast("Find Zino and allow Usage access — that's how it knows a game is open");
        }
        if (OverlayService.running) { // restart so the new mode takes effect
            stopService(new Intent(this, OverlayService.class));
            ui.postDelayed(() -> OverlayService.start(this), 300);
        }
        updateArrowModes();
        ui.postDelayed(this::updateGameMode, 600);
    }

    private void updateArrowModes() {
        String mode = OverlayService.arrowMode(this);
        String[] keys = {"auto", "always", "off"};
        for (int i = 0; i < 3; i++) chipOn(arrowModes[i], keys[i].equals(mode));
        float size = prefs.getFloat("ov_size", 1f);
        for (int i = 0; i < 3; i++) chipOn(sizeChips[i], Math.abs(new float[]{0.8f, 1f, 1.3f}[i] - size) < 0.01f);
        boolean usage = OverlayService.hasUsageAccess(this);
        usageNote.setText(usage ? "" : mode.equals("auto")
                ? "Auto-hide needs Usage access to see when a game opens. Until then the arrow always shows."
                : "Allow Usage access so the arrow can read FPS from the game itself.");
        usageNote.setVisibility(usage ? View.GONE : View.VISIBLE);
        usageButton.setVisibility(usage ? View.GONE : View.VISIBLE);
    }

    private void updateShizuku() {
        boolean ready = Shell.ready();
        if (ready) {
            nfStatus.setText("● Connected");
            nfStatus.setTextColor(GOOD);
        } else if (Shell.running()) {
            nfStatus.setText("Shizuku is running — tap Connect to allow Zino");
            nfStatus.setTextColor(WARN);
        } else {
            nfStatus.setText("Shizuku not running — install and start it first");
            nfStatus.setTextColor(WARN);
        }
        nfConnect.setVisibility(ready ? View.GONE : View.VISIBLE);
    }

    private void connectShizuku() {
        if (Shell.running()) { Shizuku.requestPermission(7); return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api"))); }
        catch (ActivityNotFoundException e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))); }
        toast("Install Shizuku, start it (Wireless debugging works without a PC), then come back and tap Connect");
    }

    private void comingSoon(String title, String body) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("OK", null).show();
    }

    private String versionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (PackageManager.NameNotFoundException e) { return ""; }
    }

    // ------------------------------------------------------------------ helpers

    private float[] refreshRates() {
        @SuppressWarnings("deprecation")
        Display d = getWindowManager().getDefaultDisplay();
        float max = d.getRefreshRate();
        for (Display.Mode m : d.getSupportedModes()) max = Math.max(max, m.getRefreshRate());
        return new float[]{d.getRefreshRate(), max};
    }

    private ActivityManager.MemoryInfo memInfo() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        getSystemService(ActivityManager.class).getMemoryInfo(mi);
        return mi;
    }

    private NotificationManager nm() { return getSystemService(NotificationManager.class); }
    private WifiManager wifi() { return (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE); }

    private void open(String action) {
        try { startActivity(new Intent(action)); }
        catch (ActivityNotFoundException e) { toast("This device doesn't have that settings screen"); }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private static String mb(long bytes) { return (bytes >> 20) + " MB"; }
    private static String ms(Double v) { return v == null ? "—" : String.format(Locale.US, "%.0fms", v); }
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    /** Rounded fill with an optional 1.5dp stroke (stroke 0 = none). */
    private GradientDrawable round(int color, float radiusDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (stroke != 0) d.setStroke(dp(1.5f), stroke);
        return d;
    }

    private void option(LinearLayout parent, String label, String key) { option(parent, label, key, true); }

    private void option(LinearLayout parent, String label, String key, boolean byDefault) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(TEXT);
        c.setButtonTintList(ColorStateList.valueOf(BRAND));
        c.setChecked(prefs.getBoolean(key, byDefault));
        c.setOnCheckedChangeListener((box, on) -> {
            prefs.edit().putBoolean(key, on).apply();
            if (key.equals("auto_detect")) restartOverlay();
            if (on && key.equals("gm_quiet") && !nm().isNotificationPolicyAccessGranted()) {
                toast("Allow Zino in this list so Game Mode can block calls and pop-ups");
                open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
            }
        });
        parent.addView(c, spaced());
    }

    private LinearLayout.LayoutParams spaced() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        return lp;
    }

    private View pageTitle(String title, String sub) {
        LinearLayout l = vertical();
        l.setPadding(dp(2), 0, 0, dp(14));
        l.addView(logoBar());
        TextView t = text(title, 26, TEXT, true);
        t.setPadding(0, dp(16), 0, 0);
        l.addView(t);
        l.addView(text(sub, 13, MUTED, false));
        return l;
    }

    private LinearLayout card(String title) {
        LinearLayout c = vertical();
        c.setBackground(round(CARD, 18, BORDER));
        c.setPadding(dp(18), dp(16), dp(18), dp(18));
        LinearLayout.LayoutParams lp = spaced();
        lp.topMargin = 0;
        lp.bottomMargin = dp(12);
        root.addView(c, lp);
        TextView t = text(title.toUpperCase(Locale.ROOT), 12, BRAND, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(0, 0, 0, dp(8));
        c.addView(t);
        return c;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String label, boolean primary, View.OnClickListener onClick) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(primary ? BRAND : GHOST, 26, primary ? GLOW : 0));
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setMinHeight(dp(44));
        b.setStateListAnimator(null);
        b.setOnClickListener(onClick);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private void line(String label, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(5), 0, dp(5));
        TextView l = text(label, 14, MUTED, false);
        row.addView(l, new LinearLayout.LayoutParams(dp(112), LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(text(value, 14, color, true), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        statusBox.addView(row);
    }

    private void tip(String s) {
        TextView t = text(s, 13, WARN, false);
        t.setPadding(0, dp(2), 0, dp(6));
        statusBox.addView(t);
    }
}
