package com.frameforge.mobile;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.media.MediaScannerConnection;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.DateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Zino game mode: a draggable stats bubble drawn over games, like a gaming phone's game space. */
public class OverlayService extends Service {
    static final String ACTION_STOP = "zino.stop";
    static volatile boolean running;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private LinearLayout root, panel;
    private TextView fpsView, heatView, pingView, batView, ramView, timeView, dndView, perfView;
    // what Game Mode changed, so it can put everything back when it stops
    private boolean syncChanged, syncWas, quietChanged;
    private NotificationManager.Policy policyWas;
    private int filterWas;
    private volatile String brightnessWas;
    private volatile boolean perfOn;
    private boolean hotHandled;
    private long lastCount = -1, lastAt;
    private int lastFps = -1, tick;
    private volatile int ping = -1;

    private final Runnable loop = new Runnable() {
        @Override public void run() { refresh(); ui.postDelayed(this, 1000); }
    };

    /** Start game mode, asking for "display over other apps" first if needed. Returns false if it had to ask. */
    static boolean start(Context ctx) {
        if (!Settings.canDrawOverlays(ctx)) {
            ctx.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + ctx.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            Toast.makeText(ctx, "Allow Zino to display over other apps, then start Game Mode again", Toast.LENGTH_LONG).show();
            return false;
        }
        ctx.startForegroundService(new Intent(ctx, OverlayService.class));
        return true;
    }

    /** Kills apps parked in the background (except keep) and returns bytes freed. */
    static long clearBackground(Context ctx, String keep) {
        ActivityManager am = ctx.getSystemService(ActivityManager.class);
        long before = freeRam(ctx);
        if (Shell.ready()) try { Shell.run("am kill-all"); } catch (Exception ignored) { } // stronger: every background process
        Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo r : ctx.getPackageManager().queryIntentActivities(launcher, 0)) {
            String p = r.activityInfo.packageName;
            if (!p.equals(keep) && !p.equals(ctx.getPackageName())) am.killBackgroundProcesses(p);
        }
        return Math.max(0, freeRam(ctx) - before);
    }

    static long freeRam(Context ctx) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ctx.getSystemService(ActivityManager.class).getMemoryInfo(mi);
        return mi.availMem;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        Notification n = notification();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        if (root == null && Settings.canDrawOverlays(this)) show();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        endSession();
        ui.removeCallbacks(loop);
        bg.shutdownNow();
        if (root != null) wm.removeView(root);
        super.onDestroy();
    }

    private Notification notification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("game", "Game Mode", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, "game")
                .setSmallIcon(R.drawable.ic_fg)
                .setContentTitle("Zino Game Mode is on")
                .setContentText("Tap the bubble in your game for stats and boosts")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Stop", stop).build())
                .setOngoing(true)
                .build();
    }

    // ------------------------------------------------------------------ overlay

    private void show() {
        running = true;
        wm = getSystemService(WindowManager.class);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(round(0xE60B0D12, 0xFFFF2D46));
        root.setPadding(dp(12), dp(8), dp(12), dp(8));

        fpsView = label(18, MainActivity.GOOD, true);
        fpsView.setText("Zino");
        root.addView(fpsView);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setVisibility(View.GONE);
        pingView = label(13, MainActivity.TEXT, false);
        batView = label(13, MainActivity.TEXT, false);
        ramView = label(13, MainActivity.TEXT, false);
        timeView = label(13, MainActivity.MUTED, false);
        heatView = label(13, MainActivity.TEXT, false);
        panel.addView(heatView);
        panel.addView(pingView);
        panel.addView(batView);
        panel.addView(ramView);
        panel.addView(timeView);
        panel.addView(action("⚡ Clear RAM", v -> bg.execute(() -> {
            long freed = clearBackground(this, null);
            ui.post(() -> toast("Freed " + (freed >> 20) + " MB"));
        })));
        dndView = action("", v -> toggleDnd());
        panel.addView(dndView);
        perfView = action("", v -> bg.execute(() -> setPerformance(!perfOn)));
        panel.addView(perfView);
        panel.addView(action("◉ Screenshot", v -> screenshot()));
        panel.addView(action("✕ Close Game Mode", v -> stopSelf()));
        root.addView(panel);

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(12);
        lp.y = dp(80);
        root.setOnTouchListener(new DragOrTap());
        wm.addView(root, lp);
        startSession();
        loop.run();
    }

    private void refresh() {
        tick++;
        thermalGuard();
        if (Shell.ready()) {
            bg.execute(() -> {
                long now = System.currentTimeMillis(), count = -1;
                try { count = GameTuning.parseFrameCounter(Shell.run(GameTuning.FRAME_COUNTER_CMD)); } catch (Exception ignored) { }
                int fps = GameTuning.fps(lastCount, count, now - lastAt);
                lastCount = count;
                lastAt = now;
                if (fps >= 0) {
                    String arrow = GameTuning.trend(lastFps, fps);
                    lastFps = fps;
                    ui.post(() -> {
                        fpsView.setText(fps + " FPS " + arrow);
                        fpsView.setTextColor(fps >= 55 ? MainActivity.GOOD : fps >= 30 ? MainActivity.WARN : MainActivity.BAD);
                    });
                } else if (count < 0) {
                    ui.post(() -> fpsView.setText("FPS n/a"));
                }
            });
        } else {
            fpsView.setText("Start Shizuku for FPS");
            fpsView.setTextColor(MainActivity.WARN);
        }
        // shortcut: TCP connect time to 1.1.1.1 approximates ping; reads a few ms high, swap for ICMP if it matters
        if (tick % 3 == 1) bg.execute(() -> {
            long t = System.nanoTime();
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress("1.1.1.1", 443), 1500);
                ping = (int) ((System.nanoTime() - t) / 1_000_000);
            } catch (Exception e) { ping = -1; }
        });
        if (panel.getVisibility() != View.VISIBLE) return;
        int p = ping;
        pingView.setText("Ping  " + (p < 0 ? "—" : p + " ms"));
        pingView.setTextColor(p < 0 || p > 120 ? MainActivity.BAD : p > 60 ? MainActivity.WARN : MainActivity.TEXT);
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            float c = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int lvl = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / Math.max(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
            batView.setText("Battery  " + lvl + "% · " + c + "°C");
            batView.setTextColor(c >= 42 ? MainActivity.BAD : c >= 38 ? MainActivity.WARN : MainActivity.TEXT);
        }
        ramView.setText("Free RAM  " + (freeRam(this) >> 20) + " MB");
        timeView.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date()));
        NotificationManager nm = getSystemService(NotificationManager.class);
        boolean on = nm.getCurrentInterruptionFilter() > NotificationManager.INTERRUPTION_FILTER_ALL;
        dndView.setText(on ? "🔕 Calls & alerts blocked" : "🔔 Calls & alerts allowed");
        perfView.setText(perfOn ? "🚀 Performance mode: On" : "🚀 Performance mode: Off");
    }

    private void toggleDnd() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (!nm.isNotificationPolicyAccessGranted()) { toast("Allow Zino under Do Not Disturb access first (in the app)"); return; }
        boolean on = nm.getCurrentInterruptionFilter() > NotificationManager.INTERRUPTION_FILTER_ALL;
        nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_ALL : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        refresh();
    }

    // ------------------------------------------------------------------ game session

    /** Turns on the Game Mode options the user picked in the app. */
    private void startSession() {
        SharedPreferences prefs = getSharedPreferences("MainActivity", MODE_PRIVATE); // the app screen's preferences
        if (prefs.getBoolean("gm_sync", true)) {
            syncWas = ContentResolver.getMasterSyncAutomatically();
            ContentResolver.setMasterSyncAutomatically(false);
            syncChanged = true;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (prefs.getBoolean("gm_quiet", true) && nm.isNotificationPolicyAccessGranted()) {
            policyWas = nm.getNotificationPolicy();
            filterWas = nm.getCurrentInterruptionFilter();
            nm.setNotificationPolicy(gamePolicy());
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            quietChanged = true;
        }
        boolean perf = prefs.getBoolean("gm_perf", true), bright = prefs.getBoolean("gm_bright", true);
        if (!Shell.ready()) return;
        bg.execute(() -> {
            if (perf) setPerformance(true);
            if (bright) try {
                brightnessWas = Shell.run("settings get system screen_brightness_mode").trim();
                Shell.run("settings put system screen_brightness_mode 0"); // 0 = manual, so the screen doesn't dim mid-fight
            } catch (Exception ignored) { }
        });
    }

    /** Puts back everything startSession changed. */
    private void endSession() {
        if (syncChanged) ContentResolver.setMasterSyncAutomatically(syncWas);
        if (quietChanged) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm.isNotificationPolicyAccessGranted()) {
                nm.setNotificationPolicy(policyWas);
                nm.setInterruptionFilter(filterWas == NotificationManager.INTERRUPTION_FILTER_UNKNOWN ? NotificationManager.INTERRUPTION_FILTER_ALL : filterWas);
            }
        }
        boolean perf = perfOn;
        String bright = brightnessWas;
        if (!perf && bright == null) return;
        new Thread(() -> { // bg is shutting down
            try { if (perf) Shell.run("cmd power set-fixed-performance-mode-enabled false"); } catch (Exception ignored) { }
            try { if (bright != null && bright.matches("[01]")) Shell.run("settings put system screen_brightness_mode " + bright); } catch (Exception ignored) { }
        }).start();
    }

    /** Blocks calls, messages and notifications but keeps game sound, media and alarms. */
    private static NotificationManager.Policy gamePolicy() {
        if (Build.VERSION.SDK_INT >= 28) {
            return new NotificationManager.Policy(NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS
                    | NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA | NotificationManager.Policy.PRIORITY_CATEGORY_SYSTEM, 0, 0);
        }
        return new NotificationManager.Policy(0, 0, 0);
    }

    /** Asks Android to hold CPU/GPU clocks steady (Android 12+). Runs on a background thread. */
    private void setPerformance(boolean on) {
        if (!Shell.ready()) { ui.post(() -> toast("Start Shizuku to use performance mode")); return; }
        try {
            Shell.run("cmd power set-fixed-performance-mode-enabled " + on);
            perfOn = on;
        } catch (Exception e) {
            ui.post(() -> toast("This tablet doesn't allow performance mode"));
        }
        ui.post(this::refresh);
    }

    /** When the phone gets hot, drop performance mode before Android throttles hard. */
    private void thermalGuard() {
        if (Build.VERSION.SDK_INT < 29) return;
        int t = getSystemService(PowerManager.class).getCurrentThermalStatus();
        String[] names = {"Cool", "Warm", "Warm", "HOT", "Very hot", "Critical", "Shutting down"};
        heatView.setText("Heat  " + names[Math.min(t, 6)]);
        heatView.setTextColor(t <= 1 ? MainActivity.GOOD : t == 2 ? MainActivity.WARN : MainActivity.BAD);
        if (t >= PowerManager.THERMAL_STATUS_SEVERE && perfOn && !hotHandled) {
            hotHandled = true;
            bg.execute(() -> setPerformance(false));
            toast("Tablet is hot — Zino turned performance mode off to stop heavy throttling");
        } else if (t < PowerManager.THERMAL_STATUS_MODERATE) {
            hotHandled = false;
        }
    }

    private void screenshot() {
        if (!Shell.ready()) { toast("Start Shizuku to take screenshots from the bubble"); return; }
        panel.setVisibility(View.GONE);
        root.setVisibility(View.INVISIBLE); // keep the bubble out of the picture
        String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                + "/Zino_" + System.currentTimeMillis() + ".png";
        ui.postDelayed(() -> bg.execute(() -> {
            boolean ok;
            try { Shell.run("screencap -p " + path); ok = true; } catch (Exception e) { ok = false; }
            boolean saved = ok;
            if (saved) MediaScannerConnection.scanFile(this, new String[]{path}, null, null);
            ui.post(() -> { root.setVisibility(View.VISIBLE); toast(saved ? "Screenshot saved to Pictures" : "Couldn't take screenshot"); });
        }), 250);
    }

    /** Drag to move; a tap without moving opens or closes the panel. */
    private class DragOrTap implements View.OnTouchListener {
        float downX, downY;
        int startX, startY;
        boolean moved;

        @Override public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX(); downY = e.getRawY(); startX = lp.x; startY = lp.y; moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (e.getRawX() - downX), dy = (int) (e.getRawY() - downY);
                    if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                    lp.x = startX + dx; lp.y = startY + dy;
                    wm.updateViewLayout(root, lp);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        panel.setVisibility(panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                        refresh();
                    }
                    return true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------------ helpers

    private TextView label(float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(3), 0, dp(3));
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView action(String s, View.OnClickListener click) {
        TextView t = label(13, MainActivity.TEXT, true);
        t.setText(s);
        t.setBackground(round(0xFF1E232B, 0));
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        t.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }

    private GradientDrawable round(int fill, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(14));
        if (stroke != 0) d.setStroke(dp(1.5f), stroke);
        return d;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
