package com.frameforge.mobile;

import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaScannerConnection;
import android.net.VpnService;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Zino Game Mode: watches for games, shows the colour FPS arrow over them, and runs the
 * Game Mode options (block calls, pause sync, Boost, low latency, brightness, clarity) while you play.
 */
public class OverlayService extends Service {
    static final String ACTION_STOP = "zino.stop", ACTION_BOOST = "zino.boost", ACTION_LATENCY = "zino.latency";
    static final String PREFS = "MainActivity"; // the app screen's preferences file
    static final int PURPLE = 0xFFB36BFF;
    static volatile boolean running;
    static volatile int liveFps = -1;
    static volatile String liveGame;
    static volatile String pilotNote; // Smart Auto Pilot's latest decision, shown on Home and in the arrow menu

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final Map<String, Boolean> gameCache = new HashMap<>();
    private SharedPreferences prefs;
    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private LinearLayout root, panel;
    private TextView arrowView, fpsView, heatView, pingView, batView, ramView, timeView, dndView, perfView, latencyView, capView, modeView, pilotView;
    private FpsGraph graph;
    private final int[] fpsHistory = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1}; // last 10 seconds
    private final float[] tempHistory = new float[10];
    private boolean adsStarted, steppedDown;
    private long lastHotAlert, lastFpsAlert;
    private boolean batteryAlerted;
    private int tick, lastFps = -1;
    private volatile int ping = -1;
    private volatile String foreground;
    private String sessionGame, hiddenGame, layer;
    private boolean sessionOn, hot;
    private long lastNewest, lastCount = -1, lastAt;

    // what the session changed, so it can be put back
    private boolean syncChanged, syncWas, quietChanged;
    private NotificationManager.Policy policyWas;
    private int filterWas;
    private volatile String brightnessWas, minRefreshWas;
    private volatile boolean perfOn, latencyOn, vibranceOn;
    private boolean hotHandled;

    private final Runnable loop = new Runnable() {
        @Override public void run() { tick(); ui.postDelayed(this, 1000); }
    };

    // ------------------------------------------------------------------ starting

    /** Start Game Mode, asking for "display over other apps" first if needed. Returns false if it had to ask. */
    static boolean start(Context ctx) {
        if (!Settings.canDrawOverlays(ctx)) {
            ctx.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + ctx.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            Toast.makeText(ctx, "Allow Zino to display over other apps, then start Game Mode again", Toast.LENGTH_LONG).show();
            return false;
        }
        ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("gm_enabled", true).apply();
        ctx.startForegroundService(new Intent(ctx, OverlayService.class));
        return true;
    }

    static void stop(Context ctx) {
        ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("gm_enabled", false).apply();
        ctx.stopService(new Intent(ctx, OverlayService.class));
    }

    static String arrowMode(Context ctx) { return ctx.getSharedPreferences(PREFS, MODE_PRIVATE).getString("arrow", "auto"); }

    /** Usage access lets Zino see which app is on screen, so the arrow can appear only in games. */
    static boolean hasUsageAccess(Context ctx) {
        AppOpsManager ops = ctx.getSystemService(AppOpsManager.class);
        int mode = Build.VERSION.SDK_INT >= 29
                ? ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.getPackageName())
                : ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    /** Kills apps parked in the background (except keep) and returns bytes freed. */
    static long clearBackground(Context ctx, String keep) {
        ActivityManager am = ctx.getSystemService(ActivityManager.class);
        long before = freeRam(ctx);
        if (Shell.ready()) try { Shell.run("am kill-all"); } catch (Exception ignored) { } // stronger: every background process
        Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo r : ctx.getPackageManager().queryIntentActivities(launcher, 0)) {
            String p = r.activityInfo.packageName;
            if (!p.equals(keep) && !p.equals(ctx.getPackageName())) am.killBackgroundProcesses(p);
        }
        return Math.max(0, freeRam(ctx) - before);
    }

    static long freeRam(Context ctx) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ctx.getSystemService(ActivityManager.class).getMemoryInfo(mi);
        return mi.availMem;
    }

    /** Adds a game to the front of the recent list shown on Home. */
    static void addRecent(Context ctx, String pkg) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, MODE_PRIVATE);
        StringBuilder sb = new StringBuilder(pkg);
        int n = 1;
        for (String s : p.getString("recent", "").split(",")) {
            if (s.isEmpty() || s.equals(pkg) || n >= 6) continue;
            sb.append(',').append(s);
            n++;
        }
        p.edit().putString("recent", sb.toString()).putLong("lp_" + pkg, System.currentTimeMillis()).apply();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) { stop(this); return START_NOT_STICKY; }
        if (running && (ACTION_BOOST.equals(action) || ACTION_LATENCY.equals(action))) {
            boolean on = intent.getBooleanExtra("on", false);
            // switched live only while a game session runs; otherwise the saved choice applies at the next one
            if (sessionOn) bg.execute(() -> { if (ACTION_BOOST.equals(action)) setPerformance(on); else setLowLatency(on); });
            return START_STICKY;
        }
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Notification n = notification();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        if (!running) {
            running = true;
            wm = getSystemService(WindowManager.class);
            buildBubble();
            if (!autoMode()) startSession(null); // Always / Off: Game Mode options run until you stop it
            loop.run();
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        liveFps = -1;
        liveGame = null;
        ui.removeCallbacks(loop);
        endSession();
        bg.shutdownNow();
        if (root != null && root.isAttachedToWindow()) wm.removeView(root);
        super.onDestroy();
    }

    private boolean autoMode() { return "auto".equals(prefs.getString("arrow", "auto")) && hasUsageAccess(this); }

    private Notification notification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("game", "Game Mode", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        String mode = prefs.getString("arrow", "auto");
        String text = !mode.equals("auto") ? "FPS arrow and Game Mode options are on"
                : hasUsageAccess(this) ? "The FPS arrow appears when you open a game"
                : "Allow Usage access in Zino so the arrow appears only in games";
        return new Notification.Builder(this, "game")
                .setSmallIcon(R.drawable.ic_fg)
                .setContentTitle("Zino Game Mode is on")
                .setContentText(text)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Stop", stop).build())
                .setOngoing(true)
                .build();
    }

    // ------------------------------------------------------------------ the loop

    private void tick() {
        tick++;
        if (hasUsageAccess(this)) bg.execute(() -> foreground = readForeground(foreground));
        String fg = foreground;
        boolean inGame = fg != null && isGame(fg);
        String mode = prefs.getString("arrow", "auto");

        if (autoMode()) {
            if (inGame && !fg.equals(sessionGame)) { endSession(); startSession(fg); } // game opened (or switched)
            else if (!inGame && sessionOn && fg != null) endSession();                  // game closed: arrow goes away
        } else if (inGame && !fg.equals(liveGame)) {
            liveGame = fg;
            addRecent(this, fg);
            layer = null;
        }
        boolean show = !mode.equals("off") && !(autoMode() && !sessionOn) && !(fg != null && fg.equals(hiddenGame));
        if (hiddenGame != null && fg != null && !fg.equals(hiddenGame)) hiddenGame = null; // hidden only until you leave that game
        setBubbleVisible(show);

        thermalGuard();
        if (sessionOn && tick % 5 == 0) { autoPilot(); alerts(); }
        if (!root.isAttachedToWindow()) return; // nothing on screen: skip the FPS and ping work
        readFps(inGame ? fg : null);
        if (tick % 3 == 1) bg.execute(this::measurePing);
        if (panel.getVisibility() == View.VISIBLE) refreshPanel();
    }

    /** Last app moved to the foreground, from usage events (needs Usage access). */
    private String readForeground(String previous) {
        long now = System.currentTimeMillis();
        UsageEvents events = getSystemService(UsageStatsManager.class).queryEvents(now - 10_000, now);
        UsageEvents.Event e = new UsageEvents.Event();
        String fg = previous;
        while (events.hasNextEvent()) {
            events.getNextEvent(e);
            @SuppressWarnings("deprecation") int resumed = UsageEvents.Event.MOVE_TO_FOREGROUND; // = ACTIVITY_RESUMED, also on Android 8-9
            if (e.getEventType() == resumed) fg = e.getPackageName();
        }
        return fg;
    }

    private boolean isGame(String pkg) {
        Boolean cached = gameCache.get(pkg);
        if (cached != null) return cached;
        if (listed("exclude", pkg) || pkg.equals(getPackageName())) { gameCache.put(pkg, false); return false; }
        boolean game = listed("games_add", pkg) || prefs.contains("nf_" + pkg) || prefs.contains("cl_" + pkg) || listed("recent", pkg);
        if (!game && prefs.getBoolean("auto_detect", true)) try {
            ApplicationInfo a = getPackageManager().getApplicationInfo(pkg, 0);
            @SuppressWarnings("deprecation")
            boolean flagged = a.category == ApplicationInfo.CATEGORY_GAME || (a.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
            game |= flagged;
        } catch (Exception ignored) { }
        gameCache.put(pkg, game);
        return game;
    }

    private boolean listed(String key, String pkg) { return ("," + prefs.getString(key, "") + ",").contains("," + pkg + ","); }

    // ------------------------------------------------------------------ FPS

    /** Reads FPS from the game's own frames; falls back to the whole-screen counter. Updates the arrow. */
    private void readFps(String game) {
        if (!Shell.ready()) {
            showFps(-1, "Start Shizuku for FPS");
            return;
        }
        bg.execute(() -> {
            int fps = -1;
            if (game != null && GameTuning.validPackage(game)) {
                try {
                    if (layer == null || !layer.contains(game) || tick % 10 == 0) {
                        layer = GameTuning.pickLayer(Shell.run("dumpsys SurfaceFlinger --list"), game);
                    }
                    if (layer != null) {
                        long[] t = GameTuning.presentTimes(Shell.run("dumpsys SurfaceFlinger --latency '" + layer + "'"));
                        if (t.length >= 2) {
                            long newest = t[t.length - 1];
                            fps = newest == lastNewest ? 0 : GameTuning.fpsFromPresentTimes(t); // no new frames = paused
                            lastNewest = newest;
                        } else {
                            layer = null; // layer changed (e.g. rotation); find it again next second
                        }
                    }
                } catch (Exception ignored) { }
            }
            if (fps < 0) { // fallback: every screen update, not only the game's
                long now = System.currentTimeMillis(), count = -1;
                try { count = GameTuning.parseFrameCounter(Shell.run(GameTuning.FRAME_COUNTER_CMD)); } catch (Exception ignored) { }
                fps = GameTuning.fps(lastCount, count, now - lastAt);
                lastCount = count;
                lastAt = now;
            }
            int f = fps;
            ui.post(() -> showFps(f, f < 0 ? "FPS —" : null));
        });
    }

    private void showFps(int fps, String message) {
        liveFps = fps;
        int c = GameTuning.arrowColor(fps, hot, perfOn);
        int color = c == GameTuning.RED ? MainActivity.BAD : c == GameTuning.PURPLE ? PURPLE
                : c == GameTuning.YELLOW ? MainActivity.WARN : MainActivity.GOOD;
        arrowView.setText(GameTuning.arrowGlyph(c));
        arrowView.setTextColor(message != null ? MainActivity.MUTED : color);
        System.arraycopy(fpsHistory, 1, fpsHistory, 0, fpsHistory.length - 1);
        fpsHistory[fpsHistory.length - 1] = fps;
        if (graph != null) { graph.color = color; graph.invalidate(); }
        fpsView.setText(message != null ? message : fps + " FPS");
        fpsView.setTextColor(message != null ? MainActivity.MUTED : MainActivity.TEXT);
        ((GradientDrawable) root.getBackground()).setStroke(dp(1.5f), message != null ? MainActivity.BORDER : color);
        if (fps >= 0) lastFps = fps;
    }

    // shortcut: TCP connect time to 1.1.1.1 approximates ping; reads a few ms high, swap for ICMP if it matters
    private void measurePing() {
        long t = System.nanoTime();
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress("1.1.1.1", 443), 1500);
            ping = (int) ((System.nanoTime() - t) / 1_000_000);
        } catch (Exception e) { ping = -1; }
    }

    // ------------------------------------------------------------------ bubble

    private void buildBubble() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(round(0xD90B0D12, MainActivity.BORDER));
        root.setAlpha(prefs.getInt("ov_alpha", 90) / 100f);
        float size = prefs.getFloat("ov_size", 1f);
        root.setPadding(dp(10), dp(6), dp(12), dp(6));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        arrowView = label(20 * size, MainActivity.GOOD, true);
        arrowView.setText("▲");
        fpsView = label(14 * size, MainActivity.TEXT, true);
        fpsView.setText("Zino");
        fpsView.setPadding(dp(6), 0, 0, 0);
        head.addView(arrowView);
        head.addView(fpsView);
        root.addView(head);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setVisibility(View.GONE);
        heatView = label(13, MainActivity.TEXT, false);
        pingView = label(13, MainActivity.TEXT, false);
        batView = label(13, MainActivity.TEXT, false);
        ramView = label(13, MainActivity.TEXT, false);
        timeView = label(13, MainActivity.MUTED, false);
        pilotView = label(12, MainActivity.WARN, false);
        graph = new FpsGraph();
        panel.addView(graph, new LinearLayout.LayoutParams(dp(200), dp(48)));
        for (TextView t : new TextView[]{pilotView, heatView, pingView, batView, ramView, timeView}) panel.addView(t);
        capView = action("", v -> cycleFpsCap());
        modeView = action("", v -> cycleClarityMode());
        perfView = action("", v -> bg.execute(() -> setPerformance(!perfOn)));
        latencyView = action("", v -> bg.execute(() -> setLowLatency(!latencyOn)));
        dndView = action("", v -> toggleDnd());
        panel.addView(capView);
        panel.addView(modeView);
        panel.addView(perfView);
        panel.addView(latencyView);
        panel.addView(dndView);
        panel.addView(action("⚡ Clear RAM", v -> bg.execute(() -> {
            long freed = clearBackground(this, foreground);
            ui.post(() -> toast("Freed " + (freed >> 20) + " MB"));
        })));
        panel.addView(action("◉ Screenshot", v -> screenshot()));
        panel.addView(action("👁 Hide arrow until I leave this game", v -> { hiddenGame = foreground; panel.setVisibility(View.GONE); }));
        panel.addView(action("✕ Stop Game Mode", v -> stop(this)));
        root.addView(panel);

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = prefs.getInt("bubble_x", dp(12));
        lp.y = prefs.getInt("bubble_y", dp(80));
        root.setOnTouchListener(new DragOrTap());
    }

    private void setBubbleVisible(boolean show) {
        if (!Settings.canDrawOverlays(this)) return;
        if (show && !root.isAttachedToWindow()) wm.addView(root, lp);
        else if (!show && root.isAttachedToWindow()) { panel.setVisibility(View.GONE); wm.removeView(root); }
    }

    private void refreshPanel() {
        int p = ping;
        String vpn = RegionTunnel.activeCountry;
        pingView.setText("Ping  " + (p < 0 ? "—" : p + " ms") + (vpn != null ? "  ·  " + GameTuning.flag(vpn) + " " + GameTuning.countryName(vpn) : ""));
        pingView.setTextColor(p < 0 || p > 120 ? MainActivity.BAD : p > 60 ? MainActivity.WARN : MainActivity.TEXT);
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            float c = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int lvl = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / Math.max(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
            batView.setText("Battery  " + lvl + "% · " + c + "°C");
            batView.setTextColor(c >= 42 ? MainActivity.BAD : c >= 38 ? MainActivity.WARN : MainActivity.TEXT);
        }
        ramView.setText("Free RAM  " + (freeRam(this) >> 20) + " MB");
        String note = pilotNote;
        pilotView.setText(prefs.getBoolean("autopilot", true) && note != null ? "🤖 " + note : "");
        pilotView.setVisibility(pilotView.getText().length() == 0 ? View.GONE : View.VISIBLE);
        long ua = getSystemService(BatteryManager.class).getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
        if (bat != null && Math.abs(ua) > 1000) batView.append("  ·  " + Math.abs(ua) / 1000 + " mA");
        timeView.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date()));
        boolean quiet = getSystemService(NotificationManager.class).getCurrentInterruptionFilter() > NotificationManager.INTERRUPTION_FILTER_ALL;
        dndView.setText(quiet ? "🔕 Calls & alerts: blocked" : "🔔 Calls & alerts: allowed");
        perfView.setText(perfOn ? "🟣 Boost: On" : "🟣 Boost: Off");
        latencyView.setText(latencyOn ? "⏱ Low latency: On (" + maxRefresh() + " Hz)" : "⏱ Low latency: Off");
        String g = foreground;
        int cap = g != null && isGame(g) ? GameTuning.savedFps(prefs.getString("nf_" + g, null)) : -1;
        capView.setText(cap < 0 ? "🎯 FPS limit: open a game first" : "🎯 FPS limit: " + (cap == 0 ? "none" : cap) + "  (tap to change)");
        String saved = g != null ? prefs.getString("nf_" + g, null) : null;
        modeView.setText(cap < 0 ? "✨ Clarity mode: open a game first" : "✨ Clarity mode: " + GameTuning.describe(saved).split(" · ")[0] + "  (tap to change)");
    }

    /** Steps through FPS caps for the current game; Android applies it next time the game opens. */
    private void cycleFpsCap() {
        String g = foreground;
        if (g == null || !isGame(g) || !GameTuning.validPackage(g)) { toast("Open a game first"); return; }
        if (!Shell.ready()) { toast("Start Shizuku to change the FPS cap"); return; }
        String saved = prefs.getString("nf_" + g, null);
        float scale = GameTuning.savedScale(saved);
        int cur = GameTuning.savedFps(saved), next = 0, max = maxRefresh();
        for (int f : GameTuning.FPS) if (f > cur && f <= max + 1) { next = f; break; }
        int fps = next;
        bg.execute(() -> {
            try {
                for (String c : GameTuning.commandsNoRestart(g, scale < 0 ? 1f : scale, fps)) Shell.run(c);
                prefs.edit().putString("nf_" + g, GameTuning.save(scale, fps)).apply();
                ui.post(() -> { toast("FPS cap " + (fps == 0 ? "off" : fps) + " — applies next time you open the game"); refreshPanel(); });
            } catch (Exception e) {
                ui.post(() -> toast("Couldn't change the FPS cap"));
            }
        });
    }

    // ------------------------------------------------------------------ game session

    /** Turns on the Game Mode options the user picked; game is null when not tied to one game. */
    private void startSession(String game) {
        sessionOn = true;
        sessionGame = game;
        steppedDown = false;
        batteryAlerted = false;
        java.util.Arrays.fill(fpsHistory, -1);
        if (game != null && prefs.contains("bx_" + game)) {
            lp.x = prefs.getInt("bx_" + game, lp.x);
            lp.y = prefs.getInt("by_" + game, lp.y);
            if (root.isAttachedToWindow()) wm.updateViewLayout(root, lp);
        }
        String region = game == null ? null : prefs.getString("rg_" + game, null);
        if (region != null && RegionTunnel.serverConfig(prefs, region) != null && VpnService.prepare(this) == null) {
            String g = game; // connect the game's Server Region (permission was given in the app)
            bg.execute(() -> {
                try { RegionTunnel.connect(this, g, region); }
                catch (Exception e) { ui.post(() -> toast("Couldn't connect to " + GameTuning.countryName(region) + " — playing without VPN")); }
            });
        }
        if (region == null && game != null && prefs.getBoolean("ads_" + game, false) && !AdBlockService.running && VpnService.prepare(this) == null) {
            startService(new Intent(this, AdBlockService.class)); // per-game ad blocker (Android already said yes once)
            adsStarted = true;
        }
        liveGame = game;
        layer = null;
        if (game != null) addRecent(this, game);
        if (prefs.getBoolean("gm_sync", true)) {
            syncWas = ContentResolver.getMasterSyncAutomatically();
            ContentResolver.setMasterSyncAutomatically(false);
            syncChanged = true;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (prefs.getBoolean("gm_quiet", true) && nm.isNotificationPolicyAccessGranted()) {
            policyWas = nm.getNotificationPolicy();
            filterWas = nm.getCurrentInterruptionFilter();
            nm.setNotificationPolicy(gamePolicy());
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            quietChanged = true;
        }
        if (!Shell.ready()) return;
        boolean perf = prefs.getBoolean("gm_perf", true),
                bright = game != null && prefs.contains("gm_bright_" + game) ? prefs.getBoolean("gm_bright_" + game, true) : prefs.getBoolean("gm_bright", true),
                latency = game != null && prefs.contains("gm_latency_" + game) ? prefs.getBoolean("gm_latency_" + game, true) : prefs.getBoolean("gm_latency", true);
        String clarity = game == null ? null : prefs.getString("cl_" + game,
                prefs.getInt("vib_default", 0) > 0 ? GameTuning.saveClarity(false, 1f + prefs.getInt("vib_default", 0) / 100f) : null);
        bg.execute(() -> {
            if (perf) setPerformance(true);
            if (latency) setLowLatency(true);
            if (bright) try {
                brightnessWas = Shell.run("settings get system screen_brightness_mode").trim();
                Shell.run("settings put system screen_brightness_mode 0"); // 0 = manual, so the screen doesn't dim mid-fight
            } catch (Exception ignored) { }
            if (clarity != null) try {
                float vib = Float.parseFloat(clarity.split(",")[1]);
                if (vib > 1.01f) { Shell.run(GameTuning.clarityCommands(prefs.getBoolean("msaa", false), vib)[1]); vibranceOn = true; }
            } catch (Exception ignored) { }
        });
    }

    /** Puts back everything startSession changed. */
    private void endSession() {
        if (!sessionOn) return;
        String ended = sessionGame;
        sessionOn = false;
        sessionGame = null;
        if (ended != null && ended.equals(RegionTunnel.activeGame)) new Thread(() -> RegionTunnel.disconnect(this)).start();
        pilotNote = null;
        if (adsStarted) { startService(new Intent(this, AdBlockService.class).setAction(AdBlockService.ACTION_STOP)); adsStarted = false; }
        if (syncChanged) { ContentResolver.setMasterSyncAutomatically(syncWas); syncChanged = false; }
        if (quietChanged) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm.isNotificationPolicyAccessGranted()) {
                nm.setNotificationPolicy(policyWas);
                nm.setInterruptionFilter(filterWas == NotificationManager.INTERRUPTION_FILTER_UNKNOWN ? NotificationManager.INTERRUPTION_FILTER_ALL : filterWas);
            }
            quietChanged = false;
        }
        boolean perf = perfOn, latency = latencyOn, vib = vibranceOn;
        String bright = brightnessWas, minWas = minRefreshWas;
        perfOn = false; latencyOn = false; vibranceOn = false; brightnessWas = null; minRefreshWas = null;
        if (!perf && !latency && !vib && bright == null) return;
        new Thread(() -> { // bg may be shutting down
            try { if (perf) Shell.run("cmd power set-fixed-performance-mode-enabled false"); } catch (Exception ignored) { }
            try { if (latency) Shell.run(minWas == null || !minWas.matches("[0-9.]+") ? "settings delete system min_refresh_rate"
                    : "settings put system min_refresh_rate " + minWas); } catch (Exception ignored) { }
            try { if (vib) Shell.run("service call SurfaceFlinger 1022 f 1.0"); } catch (Exception ignored) { }
            try { if (bright != null && bright.matches("[01]")) Shell.run("settings put system screen_brightness_mode " + bright); } catch (Exception ignored) { }
        }).start();
    }

    /** Blocks calls, messages and notifications but keeps game sound, media and alarms. */
    private static NotificationManager.Policy gamePolicy() {
        if (Build.VERSION.SDK_INT >= 28) {
            return new NotificationManager.Policy(NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS
                    | NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA | NotificationManager.Policy.PRIORITY_CATEGORY_SYSTEM, 0, 0);
        }
        return new NotificationManager.Policy(0, 0, 0);
    }

    /** Boost: asks Android to hold CPU/GPU clocks steady (Android 12+). Runs on a background thread. */
    private void setPerformance(boolean on) {
        if (!Shell.ready()) { ui.post(() -> toast("Start Shizuku to use Boost")); return; }
        try {
            Shell.run("cmd power set-fixed-performance-mode-enabled " + on);
            perfOn = on;
        } catch (Exception e) {
            ui.post(() -> toast("This tablet doesn't allow Boost (performance mode)"));
        }
        ui.post(this::refreshPanel);
    }

    /** Low latency: keeps the screen at its top refresh rate so touches and frames show sooner. Background thread. */
    private void setLowLatency(boolean on) {
        if (!Shell.ready()) { ui.post(() -> toast("Start Shizuku to use Low latency")); return; }
        try {
            if (on) {
                if (minRefreshWas == null) minRefreshWas = Shell.run("settings get system min_refresh_rate").trim();
                Shell.run("settings put system min_refresh_rate " + maxRefresh());
            } else {
                String was = minRefreshWas;
                Shell.run(was == null || !was.matches("[0-9.]+") ? "settings delete system min_refresh_rate"
                        : "settings put system min_refresh_rate " + was);
                minRefreshWas = null;
            }
            latencyOn = on;
        } catch (Exception e) {
            ui.post(() -> toast("This tablet doesn't allow locking the refresh rate"));
        }
        ui.post(this::refreshPanel);
    }

    private int maxRefresh() {
        Display d = wm.getDefaultDisplay();
        float max = d.getRefreshRate();
        for (Display.Mode m : d.getSupportedModes()) max = Math.max(max, m.getRefreshRate());
        return Math.round(max);
    }

    /** When the tablet gets hot, drop Boost before Android throttles hard; the arrow turns red. */
    private void thermalGuard() {
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null && tick % 3 == 0) { // 30 s of history at one reading every 3 s
            System.arraycopy(tempHistory, 1, tempHistory, 0, tempHistory.length - 1);
            tempHistory[tempHistory.length - 1] = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
        }
        if (Build.VERSION.SDK_INT < 29) return;
        int t = getSystemService(PowerManager.class).getCurrentThermalStatus();
        hot = t >= PowerManager.THERMAL_STATUS_SEVERE;
        String[] names = {"Cool", "Warm", "Warm", "HOT", "Very hot", "Critical", "Shutting down"};
        float t0 = tempHistory[0], t1 = tempHistory[tempHistory.length - 1];
        String trend = t0 <= 0 ? "" : t1 - t0 > 0.4f ? "  ↗ rising" : t0 - t1 > 0.4f ? "  ↘ cooling" : "  → steady";
        heatView.setText("Heat  " + names[Math.min(t, 6)] + trend);
        heatView.setTextColor(t <= 1 ? MainActivity.GOOD : t == 2 ? MainActivity.WARN : MainActivity.BAD);
        if (hot && perfOn && !hotHandled) {
            hotHandled = true;
            bg.execute(() -> setPerformance(false));
            toast("Tablet is hot — Zino turned Boost off to stop heavy throttling");
        } else if (t < PowerManager.THERMAL_STATUS_MODERATE) {
            hotHandled = false;
        }
    }

    private void toggleDnd() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (!nm.isNotificationPolicyAccessGranted()) { toast("Allow Zino under Do Not Disturb access first (in the app)"); return; }
        boolean on = nm.getCurrentInterruptionFilter() > NotificationManager.INTERRUPTION_FILTER_ALL;
        if (!on) nm.setNotificationPolicy(gamePolicy());
        nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_ALL : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        refreshPanel();
    }

    private void screenshot() {
        if (!Shell.ready()) { toast("Start Shizuku to take screenshots from the arrow"); return; }
        panel.setVisibility(View.GONE);
        root.setVisibility(View.INVISIBLE); // keep the arrow out of the picture
        String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                + "/Zino_" + System.currentTimeMillis() + ".png";
        ui.postDelayed(() -> bg.execute(() -> {
            boolean ok;
            try { Shell.run("screencap -p " + path); ok = true; } catch (Exception e) { ok = false; }
            boolean saved = ok;
            if (saved) MediaScannerConnection.scanFile(this, new String[]{path}, null, null);
            ui.post(() -> { root.setVisibility(View.VISIBLE); toast(saved ? "Screenshot saved to Pictures" : "Couldn't take screenshot"); });
        }), 250);
    }

    /** Steps through Image Boost modes for the current game; Android applies it next time the game opens. */
    private void cycleClarityMode() {
        String g = foreground;
        if (g == null || !isGame(g) || !GameTuning.validPackage(g)) { toast("Open a game first"); return; }
        String saved = prefs.getString("nf_" + g, null);
        int cur = GameTuning.presetFor(GameTuning.savedScale(saved)), fps = GameTuning.savedFps(saved);
        int next = cur < 0 ? 0 : (cur + 1) % GameTuning.BOOST_NAMES.length;
        float scale = GameTuning.BOOST_SCALES[next];
        prefs.edit().putString("nf_" + g, GameTuning.save(scale, fps)).apply();
        if (scale > 0 && Shell.ready() && Build.VERSION.SDK_INT >= 33) bg.execute(() -> {
            try { for (String c : GameTuning.commandsNoRestart(g, scale, fps)) Shell.run(c); } catch (Exception ignored) { }
        });
        toast(GameTuning.BOOST_NAMES[next] + " — applies next time you open the game");
        refreshPanel();
    }

    /** Smart Auto Pilot: every 5 s, set Boost / Low latency from heat, battery and FPS stability. */
    private void autoPilot() {
        if (!prefs.getBoolean("autopilot", true)) { pilotNote = null; return; }
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat == null) return;
        float c = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
        int lvl = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / Math.max(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
        boolean charging = bat.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
        int thermal = Build.VERSION.SDK_INT >= 29 ? getSystemService(PowerManager.class).getCurrentThermalStatus() : 0;
        double[] ms = GameTuning.meanAndSpread(fpsHistory);
        GameTuning.Pilot p = GameTuning.autoPilot(thermal, c, lvl, charging, ms[0], ms[1]);
        boolean changed = !p.reason.equals(pilotNote);
        pilotNote = p.reason;
        boolean wantBoost = p.boost && prefs.getBoolean("gm_perf", true), wantLatency = p.latency && prefs.getBoolean("gm_latency", true);
        if (Shell.ready()) bg.execute(() -> {
            if (perfOn != wantBoost) setPerformance(wantBoost);
            if (latencyOn != wantLatency) setLowLatency(wantLatency);
        });
        String g = sessionGame;
        if (p.stepDown && !steppedDown && g != null && GameTuning.validPackage(g)) {
            steppedDown = true; // once per session
            String saved = prefs.getString("nf_" + g, null);
            float lighter = GameTuning.lighter(GameTuning.savedScale(saved));
            int fps = GameTuning.savedFps(saved);
            prefs.edit().putString("nf_" + g, GameTuning.save(lighter, fps)).apply();
            if (Shell.ready() && Build.VERSION.SDK_INT >= 33) bg.execute(() -> {
                try { for (String cmd : GameTuning.commandsNoRestart(g, lighter, fps)) Shell.run(cmd); } catch (Exception ignored) { }
            });
        }
        if (changed && !p.reason.startsWith("All good")) toast("Auto Pilot: " + p.reason);
    }

    /** Optional heads-up alerts: heat, low battery, FPS drops. Each has a cooldown so it never nags. */
    private void alerts() {
        long now = System.currentTimeMillis();
        if (prefs.getBoolean("n_temp", true) && hot && now - lastHotAlert > 10 * 60_000) {
            lastHotAlert = now;
            alert(2, "Device is hot", "Zino turned Boost off. Lower graphics a step or take a short break.");
        }
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null && prefs.getBoolean("n_batt", true) && !batteryAlerted) {
            int lvl = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / Math.max(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100));
            if (lvl <= 15 && bat.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) == 0) {
                batteryAlerted = true;
                alert(3, "Battery low — " + lvl + "%", "Plug in soon, or switch the game to Performance mode to save power.");
            }
        }
        double mean = GameTuning.meanAndSpread(fpsHistory)[0];
        if (prefs.getBoolean("n_fps", false) && mean >= 0 && mean < 30 && now - lastFpsAlert > 5 * 60_000) {
            lastFpsAlert = now;
            alert(4, "FPS dropped to " + Math.round(mean), "Try a lighter Clarity mode from the arrow menu.");
        }
    }

    private void alert(int id, String title, String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("alerts", "Game alerts", NotificationManager.IMPORTANCE_DEFAULT));
        nm.notify(id, new Notification.Builder(this, "alerts").setSmallIcon(R.drawable.ic_fg)
                .setContentTitle(title).setContentText(text).setAutoCancel(true).build());
    }

    /** The last 10 seconds of FPS as a small line in the arrow menu. */
    private class FpsGraph extends View {
        int color = MainActivity.GOOD;
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), grid = new Paint();
        private final Path path = new Path();

        FpsGraph() {
            super(OverlayService.this);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(2));
            line.setStrokeJoin(Paint.Join.ROUND);
            grid.setColor(MainActivity.BORDER);
            grid.setStrokeWidth(dp(1));
        }

        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            float top = 0;
            for (int f : fpsHistory) top = Math.max(top, f);
            top = Math.max(60, top * 1.15f);
            float y60 = h - h * 60 / top;
            c.drawLine(0, y60, w, y60, grid); // 60 FPS guide
            path.reset();
            boolean started = false;
            for (int i = 0; i < fpsHistory.length; i++) {
                if (fpsHistory[i] < 0) continue;
                float x = w * i / (float) (fpsHistory.length - 1), y = h - h * fpsHistory[i] / top;
                if (started) path.lineTo(x, y); else { path.moveTo(x, y); started = true; }
            }
            line.setColor(color);
            c.drawPath(path, line);
        }
    }

    /** Drag to move (position is remembered); a tap without moving opens or closes the quick menu. */
    private class DragOrTap implements View.OnTouchListener {
        float downX, downY;
        int startX, startY;
        boolean moved;

        @Override public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX(); downY = e.getRawY(); startX = lp.x; startY = lp.y; moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (prefs.getBoolean("ov_lock", false)) return true; // drag lock: taps still open the menu
                    int dx = (int) (e.getRawX() - downX), dy = (int) (e.getRawY() - downY);
                    if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                    lp.x = Math.max(0, startX + dx);
                    lp.y = Math.max(0, startY + dy);
                    if (root.isAttachedToWindow()) wm.updateViewLayout(root, lp);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (moved) { // remembered per game, plus as the default for new games
                        String g = sessionGame != null ? sessionGame : liveGame;
                        SharedPreferences.Editor ed = prefs.edit().putInt("bubble_x", lp.x).putInt("bubble_y", lp.y);
                        if (g != null) ed.putInt("bx_" + g, lp.x).putInt("by_" + g, lp.y);
                        ed.apply();
                    }
                    else {
                        panel.setVisibility(panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                        if (panel.getVisibility() == View.VISIBLE) refreshPanel();
                    }
                    return true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------------ helpers

    private TextView label(float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(3), 0, dp(3));
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView action(String s, View.OnClickListener click) {
        TextView t = label(13, MainActivity.TEXT, true);
        t.setText(s);
        t.setBackground(round(0xFF1E232B, 0));
        t.setPadding(dp(10), dp(8), dp(10), dp(8));
        t.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }

    private GradientDrawable round(int fill, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(14));
        if (stroke != 0) d.setStroke(dp(1.5f), stroke);
        return d;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
