package com.frameforge.mobile;

import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/** Runs commands as Android's shell user through the Shizuku app — ADB-level access without root. */
final class Shell {
    private Shell() { }

    static boolean running() {
        try { return Shizuku.pingBinder() && !Shizuku.isPreV11(); } catch (Throwable t) { return false; }
    }

    static boolean ready() {
        try { return running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }

    // shortcut: Shizuku 13 made newProcess private; reflection works today, move to a Shizuku UserService if it breaks
    static String run(String cmd) throws Exception {
        Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        Process p = (Process) m.invoke(null, new String[]{"sh", "-c", cmd + " 2>&1"}, null, null);
        StringBuilder out = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            for (String l; (l = r.readLine()) != null; ) out.append(l).append('\n');
        }
        if (p.waitFor() != 0) throw new IOException(out.toString().trim());
        return out.toString();
    }
}
