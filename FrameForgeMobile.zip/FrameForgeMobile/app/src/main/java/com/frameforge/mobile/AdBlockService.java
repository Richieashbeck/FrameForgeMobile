package com.frameforge.mobile;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Local DNS filter. Only DNS traffic is routed into this "VPN" (nothing else leaves the
 * normal path, nothing is sent to any server of ours): ad domains get "no such domain",
 * everything else is forwarded to Cloudflare DNS.
 */
public class AdBlockService extends VpnService implements Runnable {
    static final String ACTION_STOP = "com.frameforge.mobile.STOP_ADBLOCK";
    static final AtomicInteger blocked = new AtomicInteger();
    static volatile boolean running;

    private static final String TUN_ADDR = "10.111.222.1", FAKE_DNS = "10.111.222.2", UPSTREAM = "1.1.1.1";
    private ParcelFileDescriptor tun;
    private Thread loop;
    private ExecutorService pool;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stop();
            return START_NOT_STICKY;
        }
        if (loop == null) {
            // shortcut: IPv4 DNS only; apps with hard-coded DNS-over-HTTPS bypass the filter
            tun = new Builder()
                    .setSession("Zino Ad Blocker")
                    .addAddress(TUN_ADDR, 32)
                    .addDnsServer(FAKE_DNS)
                    .addRoute(FAKE_DNS, 32)
                    .setBlocking(true)
                    .establish();
            if (tun == null) { stopSelf(); return START_NOT_STICKY; }
            pool = Executors.newFixedThreadPool(4);
            loop = new Thread(this, "adblock");
            loop.start();
            running = true;
        }
        return START_STICKY;
    }

    @Override public void run() {
        try (FileInputStream in = new FileInputStream(tun.getFileDescriptor());
             FileOutputStream out = new FileOutputStream(tun.getFileDescriptor())) {
            byte[] buf = new byte[32767];
            while (!Thread.interrupted()) {
                int n = in.read(buf);
                if (n <= 0) continue;
                byte[] pkt = Arrays.copyOf(buf, n);
                pool.execute(() -> handle(pkt, out));
            }
        } catch (Exception ignored) {
            // tunnel closed: blocker stopped or permission revoked
        }
    }

    private void handle(byte[] pkt, FileOutputStream out) {
        byte[] query = Dns.extractQuery(pkt);
        if (query == null) return;
        String name = Dns.queryName(query);
        byte[] reply;
        if (name != null && Blocklist.isBlocked(name)) {
            blocked.incrementAndGet();
            reply = Dns.nxdomain(query);
        } else {
            reply = forward(query);
            if (reply == null) return; // client will retry
        }
        try {
            synchronized (out) { out.write(Dns.wrapReply(pkt, reply)); }
        } catch (IOException ignored) { }
    }

    private byte[] forward(byte[] query) {
        try (DatagramSocket s = new DatagramSocket()) {
            protect(s); // keep our own lookup out of the tunnel
            s.setSoTimeout(3000);
            s.send(new DatagramPacket(query, query.length, InetAddress.getByName(UPSTREAM), 53));
            byte[] b = new byte[4096];
            DatagramPacket p = new DatagramPacket(b, b.length);
            s.receive(p);
            return Arrays.copyOf(b, p.getLength());
        } catch (IOException e) {
            return null;
        }
    }

    private synchronized void stop() {
        running = false;
        if (loop != null) { loop.interrupt(); loop = null; }
        if (pool != null) { pool.shutdownNow(); pool = null; }
        if (tun != null) { try { tun.close(); } catch (IOException ignored) { } tun = null; }
        stopSelf();
    }

    @Override public void onRevoke() { stop(); super.onRevoke(); }
    @Override public void onDestroy() { stop(); super.onDestroy(); }
}
