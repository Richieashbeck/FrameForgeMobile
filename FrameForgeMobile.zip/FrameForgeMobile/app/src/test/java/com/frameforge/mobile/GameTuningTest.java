package com.frameforge.mobile;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class GameTuningTest {
    @Test public void buildsCommands() {
        assertArrayEquals(new String[]{
                "cmd game set --mode 2 --downscale 0.7 --fps 60 com.dts.freefireth",
                "cmd game mode 2 com.dts.freefireth",
                "am force-stop com.dts.freefireth"}, GameTuning.commands("com.dts.freefireth", 0.7f, 60));
        assertEquals("cmd game set --mode 2 --downscale 0.5 --fps disable a.b", GameTuning.commands("a.b", 0.5f, 0)[0]);
        assertEquals("cmd game set --mode 2 --downscale disable --fps 90 a.b", GameTuning.commands("a.b", 1f, 90)[0]);
        assertEquals("cmd game reset a.b", GameTuning.commands("a.b", 1f, 0)[0]); // native + no cap = reset
    }

    @Test public void rejectsShellInjection() {
        assertTrue(GameTuning.validPackage("com.gameloft.android.ANMP.GloftA9HM"));
        assertFalse(GameTuning.validPackage("com.x; rm -rf /"));
        assertFalse(GameTuning.validPackage("nodots"));
        assertFalse(GameTuning.validPackage(null));
        try { GameTuning.commands("a.b && reboot", 0.7f, 0); throw new AssertionError("should reject"); }
        catch (IllegalArgumentException expected) { }
    }

    @Test public void readsFrameCounter() {
        assertEquals(0x4b3a2, GameTuning.parseFrameCounter("Result: Parcel(0004b3a2    '....')"));
        assertEquals(-1, GameTuning.parseFrameCounter("service: Service SurfaceFlinger does not exist"));
        assertEquals(-1, GameTuning.parseFrameCounter(null));
        assertEquals(120, GameTuning.fps(1000, 1120, 1000));
        assertEquals(-1, GameTuning.fps(-1, 50, 1000));
        assertEquals("▲", GameTuning.trend(60, 90));
        assertEquals("▼", GameTuning.trend(90, 60));
        assertEquals("•", GameTuning.trend(60, 61));
    }

    @Test public void describesProfiles() {
        assertEquals("Default", GameTuning.describe(null));
        assertEquals("Balanced (70%) · 60 FPS cap", GameTuning.describe(GameTuning.save(0.7f, 60)));
        assertEquals("Native (100%)", GameTuning.describe(GameTuning.save(1f, 0)));
    }
}
