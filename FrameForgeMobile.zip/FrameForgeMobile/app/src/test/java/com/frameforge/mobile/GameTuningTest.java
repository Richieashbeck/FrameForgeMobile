package com.frameforge.mobile;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class GameTuningTest {
    @Test public void buildsCommands() {
        assertArrayEquals(new String[]{
                "cmd game set --mode 2 --downscale 0.7 --fps 60 com.dts.freefireth",
                "cmd game mode 2 com.dts.freefireth",
                "am force-stop com.dts.freefireth"}, GameTuning.commands("com.dts.freefireth", 0.7f, 60));
        assertEquals("cmd game set --mode 2 --downscale 0.5 --fps disable a.b", GameTuning.commands("a.b", 0.5f, 0)[0]);
        assertEquals("cmd game set --mode 2 --downscale disable --fps 90 a.b", GameTuning.commands("a.b", 1f, 90)[0]);
        assertEquals("cmd game reset a.b", GameTuning.commands("a.b", 1f, 0)[0]); // native + no cap = reset
        assertArrayEquals(new String[]{"cmd game set --mode 2 --downscale 0.8 --fps 60 a.b", "cmd game mode 2 a.b"},
                GameTuning.commandsNoRestart("a.b", 0.8f, 60));
    }

    @Test public void rejectsShellInjection() {
        assertTrue(GameTuning.validPackage("com.gameloft.android.ANMP.GloftA9HM"));
        assertFalse(GameTuning.validPackage("com.x; rm -rf /"));
        assertFalse(GameTuning.validPackage("nodots"));
        assertFalse(GameTuning.validPackage(null));
        try { GameTuning.commands("a.b && reboot", 0.7f, 0); throw new AssertionError("should reject"); }
        catch (IllegalArgumentException expected) { }
    }

    @Test public void presets() {
        assertEquals(0, GameTuning.autoPreset(0));
        assertEquals(1, GameTuning.autoPreset(1));
        assertEquals(3, GameTuning.autoPreset(5));
        assertEquals(1, GameTuning.presetFor(0.8f));
        assertEquals(GameTuning.AUTO, GameTuning.presetFor(-1f));
        assertEquals("Default", GameTuning.describe(null));
        assertEquals("⚡ Balanced · 60 FPS cap", GameTuning.describe(GameTuning.save(0.8f, 60)));
        assertEquals("🤖 Auto", GameTuning.describe(GameTuning.save(-1f, 0)));
        assertEquals("90% resolution", GameTuning.describe("0.9,0")); // older saved value
    }

    @Test public void clarity() {
        assertArrayEquals(new String[]{"setprop debug.egl.force_msaa true", "service call SurfaceFlinger 1022 f 1.30"},
                GameTuning.clarityCommands(true, 1.3f));
        assertEquals("service call SurfaceFlinger 1022 f 1.60", GameTuning.clarityCommands(false, 9f)[1]); // clamped
    }

    @Test public void picksGameLayer() {
        String list = "Background for SurfaceView[com.game/com.unity3d.player.UnityPlayerActivity]#12\n"
                + "com.game/com.unity3d.player.UnityPlayerActivity#10\n"
                + "SurfaceView[com.game/com.unity3d.player.UnityPlayerActivity]#11\n"
                + "SurfaceView[com.game/com.unity3d.player.UnityPlayerActivity](BLAST)#13\n"
                + "StatusBar#3\n";
        assertEquals("SurfaceView[com.game/com.unity3d.player.UnityPlayerActivity](BLAST)#13", GameTuning.pickLayer(list, "com.game"));
        assertEquals("com.other/Main#4", GameTuning.pickLayer("com.other/Main#4\n", "com.other"));
        assertNull(GameTuning.pickLayer("StatusBar#3\n", "com.game"));
        assertNull(GameTuning.pickLayer("com.game/'evil#1\n", "com.game")); // never put a quote into the shell
    }

    @Test public void readsFpsFromLatency() {
        StringBuilder out = new StringBuilder("16666666\n");
        long t0 = 5_000_000_000L;
        for (int i = 0; i < 100; i++) { long t = t0 + i * 16_666_667L; out.append(t).append('\t').append(t).append('\t').append(t).append('\n'); }
        out.append("0\t9223372036854775807\t0\n"); // pending frame line is ignored
        long[] times = GameTuning.presentTimes(out.toString());
        assertEquals(100, times.length);
        assertEquals(60, GameTuning.fpsFromPresentTimes(times));
        long[] fast = new long[128]; // 128-frame history at 165 FPS spans less than a second
        for (int i = 0; i < fast.length; i++) fast[i] = t0 + i * 6_060_606L;
        assertEquals(165, GameTuning.fpsFromPresentTimes(fast));
        assertEquals(-1, GameTuning.fpsFromPresentTimes(new long[]{1}));
    }

    @Test public void readsFrameCounter() {
        assertEquals(0x4b3a2, GameTuning.parseFrameCounter("Result: Parcel(0004b3a2    '....')"));
        assertEquals(-1, GameTuning.parseFrameCounter("service: Service SurfaceFlinger does not exist"));
        assertEquals(120, GameTuning.fps(1000, 1120, 1000));
        assertEquals(-1, GameTuning.fps(-1, 50, 1000));
    }

    @Test public void arrow() {
        assertEquals("▲", GameTuning.trend(60, 90));
        assertEquals("▼", GameTuning.trend(90, 60));
        assertEquals(GameTuning.GREEN, GameTuning.arrowColor(120, false, false));
        assertEquals(GameTuning.YELLOW, GameTuning.arrowColor(50, false, false));
        assertEquals(GameTuning.RED, GameTuning.arrowColor(30, false, true));
        assertEquals(GameTuning.RED, GameTuning.arrowColor(120, true, false));
        assertEquals(GameTuning.PURPLE, GameTuning.arrowColor(120, false, true));
        assertEquals(GameTuning.PURPLE, GameTuning.arrowColor(150, false, false)); // 144+ is purple too
        assertEquals("▲", GameTuning.arrowGlyph(GameTuning.GREEN));
        assertEquals("▼", GameTuning.arrowGlyph(GameTuning.YELLOW));
        assertEquals("▼", GameTuning.arrowGlyph(GameTuning.RED));
        assertEquals("▲", GameTuning.arrowGlyph(GameTuning.PURPLE));
    }

    @Test public void fpsStats() {
        double[] s = GameTuning.meanAndSpread(new int[]{60, 60, 60, -1});
        assertEquals(60.0, s[0], 0.001);
        assertEquals(0.0, s[1], 0.001);
        assertEquals(10.0, GameTuning.meanAndSpread(new int[]{50, 70})[1], 0.001);
        assertEquals(-1.0, GameTuning.meanAndSpread(new int[]{-1})[0], 0.001);
    }

    @Test public void autoPilot() {
        GameTuning.Pilot hot = GameTuning.autoPilot(3, 35, 80, false, 120, 2);
        assertFalse(hot.boost); assertFalse(hot.latency); assertTrue(hot.stepDown);
        assertFalse(GameTuning.autoPilot(0, 44, 80, false, 120, 2).boost);          // hot battery counts too
        GameTuning.Pilot low = GameTuning.autoPilot(0, 30, 15, false, 120, 2);
        assertFalse(low.boost); assertFalse(low.stepDown);
        assertTrue(GameTuning.autoPilot(0, 30, 15, true, 120, 2).boost);            // charging: not "low"
        GameTuning.Pilot warm = GameTuning.autoPilot(2, 35, 80, false, 120, 2);
        assertFalse(warm.boost); assertTrue(warm.latency);
        assertEquals("FPS unstable — Boost on", GameTuning.autoPilot(0, 30, 80, false, 60, 20).reason);
        assertTrue(GameTuning.autoPilot(0, 30, 80, false, 120, 2).boost);
        assertEquals(0.8f, GameTuning.lighter(1f), 0.001);
        assertEquals(0.5f, GameTuning.lighter(0.5f), 0.001);
        assertEquals(0.8f, GameTuning.lighter(-1f), 0.001);                         // Auto steps from Ultra Quality
    }

    @Test public void labels() {
        assertEquals(300, GameTuning.minutesLeft(5_000_000, -1_000_000, false));    // 5000 mAh at 1 A = 5 h
        assertEquals(-1, GameTuning.minutesLeft(5_000_000, 1_000_000, true));
        assertEquals(-1, GameTuning.minutesLeft(5_000_000, 0, false));
        assertEquals("5 h 0 min", GameTuning.duration(300));
        assertEquals("45 min", GameTuning.duration(45));
        assertEquals("Never played", GameTuning.ago(0, 1000));
        assertEquals("Played 5 min ago", GameTuning.ago(0 + 1, 1 + 5 * 60_000));
        assertEquals("Played 3 h ago", GameTuning.ago(1, 1 + 3 * 3_600_000L));
        assertEquals("Played 2 d ago", GameTuning.ago(1, 1 + 2 * 86_400_000L));
    }
}
