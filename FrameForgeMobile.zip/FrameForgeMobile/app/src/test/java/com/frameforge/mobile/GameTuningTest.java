package com.frameforge.mobile;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class GameTuningTest {
    @Test public void buildsCommands() {
        assertArrayEquals(new String[]{
                "device_config put game_overlay com.dts.freefireth mode=2,downscaleFactor=0.7,fps=60:mode=3,downscaleFactor=0.7,fps=60",
                "cmd game mode performance com.dts.freefireth",
                "am force-stop com.dts.freefireth"}, GameTuning.commands("com.dts.freefireth", 0.7f, 60));
        assertEquals("device_config put game_overlay a.b mode=2,downscaleFactor=0.5:mode=3,downscaleFactor=0.5",
                GameTuning.commands("a.b", 0.5f, 0)[0]);
        assertEquals("device_config delete game_overlay a.b", GameTuning.commands("a.b", 1f, 0)[0]); // native + no cap = reset
    }

    @Test public void rejectsShellInjection() {
        assertTrue(GameTuning.validPackage("com.gameloft.android.ANMP.GloftA9HM"));
        assertFalse(GameTuning.validPackage("com.x; rm -rf /"));
        assertFalse(GameTuning.validPackage("nodots"));
        assertFalse(GameTuning.validPackage(null));
        try { GameTuning.commands("a.b && reboot", 0.7f, 0); throw new AssertionError("should reject"); }
        catch (IllegalArgumentException expected) { }
    }

    @Test public void describesProfiles() {
        assertEquals("Default", GameTuning.describe(null));
        assertEquals("Balanced (70%) · 60 FPS cap", GameTuning.describe(GameTuning.save(0.7f, 60)));
        assertEquals("Native (100%)", GameTuning.describe(GameTuning.save(1f, 0)));
    }
}
