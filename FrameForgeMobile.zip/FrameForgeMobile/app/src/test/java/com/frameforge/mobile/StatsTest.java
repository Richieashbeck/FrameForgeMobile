package com.frameforge.mobile;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Arrays;
import java.util.Collections;
import org.junit.Test;

public class StatsTest {
    static final String OUT =
            "PING 1.1.1.1 (1.1.1.1) 56(84) bytes of data.\n"
          + "64 bytes from 1.1.1.1: icmp_seq=1 ttl=57 time=12.0 ms\n"
          + "64 bytes from 1.1.1.1: icmp_seq=2 ttl=57 time=16.0 ms\n"
          + "64 bytes from 1.1.1.1: icmp_seq=4 ttl=57 time=14.0 ms\n"
          + "\n--- 1.1.1.1 ping statistics ---\n"
          + "4 packets transmitted, 3 received, 25% packet loss, time 603ms\n";

    @Test public void parsesPingOutput() {
        assertEquals(Arrays.asList(12.0, 16.0, 14.0), Stats.parseTimes(OUT));
        assertEquals(4, Stats.parseSent(OUT));
        assertEquals(-1, Stats.parseSent("ping: unknown host"));
        assertEquals(Collections.singletonList(1.0), Stats.parseTimes("64 bytes from 192.168.1.1: time<1 ms"));
    }

    @Test public void computesStats() {
        Stats s = new Stats(Stats.parseTimes(OUT), 4);
        assertEquals(14.0, s.avg, 0.01);
        assertEquals(12.0, s.min, 0.01);
        assertEquals(16.0, s.max, 0.01);
        assertEquals(3.0, s.jitter, 0.01);   // |16-12| + |14-16| over 2
        assertEquals(25.0, s.loss, 0.01);
        Stats none = new Stats(Collections.emptyList(), 5);
        assertNull(none.avg);
        assertEquals(100.0, none.loss, 0.01);
    }

    @Test public void diagnoses() {
        Stats goodRouter = new Stats(Arrays.asList(3.0, 4.0, 3.0), 3);
        Stats badRouter  = new Stats(Arrays.asList(3.0, 60.0, 4.0, 80.0), 4);
        Stats goodNet    = new Stats(Arrays.asList(20.0, 21.0, 20.0), 3);
        Stats badNet     = new Stats(Arrays.asList(20.0, 90.0, 20.0, 95.0), 4);
        Stats silent     = new Stats(Collections.emptyList(), 3);
        assertEquals(Stats.HOME_NETWORK, Stats.diagnose(badRouter, Arrays.asList(goodNet)));
        assertEquals(Stats.ISP, Stats.diagnose(goodRouter, Arrays.asList(badNet)));
        assertEquals(Stats.HEALTHY, Stats.diagnose(goodRouter, Arrays.asList(goodNet)));
        assertEquals(Stats.HEALTHY, Stats.diagnose(silent, Arrays.asList(goodNet))); // router ignoring ping isn't a fault
        assertEquals(Stats.NO_REPLY, Stats.diagnose(null, Arrays.asList(silent)));
    }
}
