package com.frameforge.mobile;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class DnsTest {
    /** IPv4/UDP packet 10.0.0.5:40000 -> 10.111.222.2:53 asking for an A record of {@code name}. */
    static byte[] queryPacket(String name) {
        java.io.ByteArrayOutputStream q = new java.io.ByteArrayOutputStream();
        q.write(0x12); q.write(0x34); q.write(0x01); q.write(0x00); // id, RD
        q.write(0); q.write(1); for (int i = 0; i < 6; i++) q.write(0); // qdcount 1
        for (String label : name.split("\\.")) { q.write(label.length()); q.writeBytes(label.getBytes()); }
        q.write(0); q.write(0); q.write(1); q.write(0); q.write(1); // end, A, IN
        byte[] dns = q.toByteArray();
        byte[] p = new byte[28 + dns.length];
        p[0] = 0x45; Dns.put16(p, 2, p.length); p[8] = 64; p[9] = 17;
        p[12] = 10; p[15] = 5;                                // src 10.0.0.5
        p[16] = 10; p[17] = 111; p[18] = (byte) 222; p[19] = 2; // dst 10.111.222.2
        Dns.put16(p, 20, 40000); Dns.put16(p, 22, 53); Dns.put16(p, 24, 8 + dns.length);
        System.arraycopy(dns, 0, p, 28, dns.length);
        return p;
    }

    @Test public void readsQueryName() {
        byte[] pkt = queryPacket("Auction.UnityAds.unity3d.com");
        assertEquals("auction.unityads.unity3d.com", Dns.queryName(Dns.extractQuery(pkt)));
        byte[] tcp = pkt.clone(); tcp[9] = 6;
        assertNull(Dns.extractQuery(tcp));
        byte[] other = pkt.clone(); Dns.put16(other, 22, 443);
        assertNull(Dns.extractQuery(other));
    }

    @Test public void buildsBlockedReply() {
        byte[] pkt = queryPacket("ads.doubleclick.net");
        byte[] q = Dns.extractQuery(pkt);
        byte[] nx = Dns.nxdomain(q);
        assertEquals(q.length, nx.length);         // header + question, nothing else
        assertEquals(0x12, nx[0] & 0xFF);          // same id
        assertEquals(0x81, nx[2] & 0xFF);          // response + RD
        assertEquals(3, nx[3] & 0x0F);             // NXDOMAIN

        byte[] r = Dns.wrapReply(pkt, nx);
        assertEquals(0, Dns.checksum(r, 0, 20));   // valid IP header checksum
        assertEquals(10, r[16]); assertEquals(5, r[19]);   // back to the client
        assertEquals(53, Dns.u16(r, 20));
        assertEquals(40000, Dns.u16(r, 22));
        assertEquals("ads.doubleclick.net", Dns.queryName(Dns.extractQuery(swapToQuery(r))));
    }

    @Test public void blocklistMatchesWholeLabelsOnly() {
        assertEquals(true, Blocklist.isBlocked("auction.unityads.unity3d.com"));
        assertEquals(true, Blocklist.isBlocked("doubleclick.net"));
        assertEquals(false, Blocklist.isBlocked("unity3d.com"));
        assertEquals(false, Blocklist.isBlocked("notadmob.com"));
        assertEquals(false, Blocklist.isBlocked("supercell.com"));
    }

    /** Reply packets go to port 40000; flip the port so extractQuery will parse it. */
    private static byte[] swapToQuery(byte[] r) {
        byte[] c = r.clone(); Dns.put16(c, 22, 53); return c;
    }
}
