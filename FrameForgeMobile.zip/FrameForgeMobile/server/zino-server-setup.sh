#!/usr/bin/env bash
# Zino Game VPN — one-command WireGuard server for Ubuntu/Debian.
# Rent a small server (VPS) in the country you want (e.g. Lagos, Accra, Abidjan), log in as root, then run:
#   bash zino-server-setup.sh
# It prints a client config. Save it as e.g. nigeria.conf and import it in Zino › Tools › Game VPN servers.
# Run it again to make one more client config (one per device).
set -euo pipefail

[ "$(id -u)" -eq 0 ] || { echo "Run as root (sudo bash $0)"; exit 1; }
PORT=51820
DIR=/etc/wireguard
SUBNET=10.66.66

apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq wireguard iptables curl >/dev/null

PUBLIC_IP=$(curl -4 -fsS https://api.ipify.org || hostname -I | awk '{print $1}')
NIC=$(ip -4 route show default | awk '{print $5; exit}')
umask 077
mkdir -p "$DIR"

if [ ! -f "$DIR/wg0.conf" ]; then
  wg genkey | tee "$DIR/server.key" | wg pubkey > "$DIR/server.pub"
  cat > "$DIR/wg0.conf" <<EOF
[Interface]
Address = $SUBNET.1/24
ListenPort = $PORT
PrivateKey = $(cat "$DIR/server.key")
PostUp = iptables -t nat -A POSTROUTING -o $NIC -j MASQUERADE; iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT
PostDown = iptables -t nat -D POSTROUTING -o $NIC -j MASQUERADE; iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT
EOF
  echo 'net.ipv4.ip_forward=1' > /etc/sysctl.d/99-zino.conf
  sysctl -q -p /etc/sysctl.d/99-zino.conf
  systemctl enable -q --now wg-quick@wg0
fi

# next free client address: .2, .3, ...
N=$(( $(grep -c '^\[Peer\]' "$DIR/wg0.conf" || true) + 2 ))
[ "$N" -le 254 ] || { echo "No free addresses left"; exit 1; }
CLIENT_KEY=$(wg genkey)
CLIENT_PUB=$(echo "$CLIENT_KEY" | wg pubkey)
cat >> "$DIR/wg0.conf" <<EOF

[Peer]
PublicKey = $CLIENT_PUB
AllowedIPs = $SUBNET.$N/32
EOF
wg set wg0 peer "$CLIENT_PUB" allowed-ips "$SUBNET.$N/32"

CLIENT="$DIR/zino-client-$N.conf"
cat > "$CLIENT" <<EOF
[Interface]
PrivateKey = $CLIENT_KEY
Address = $SUBNET.$N/32
DNS = 1.1.1.1

[Peer]
PublicKey = $(cat "$DIR/server.pub")
Endpoint = $PUBLIC_IP:$PORT
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
EOF

echo
echo "=== Zino client config (also saved to $CLIENT) ==="
cat "$CLIENT"
echo "=== Make sure UDP port $PORT is open in your server provider's firewall. ==="
